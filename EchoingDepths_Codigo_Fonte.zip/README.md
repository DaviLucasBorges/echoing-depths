# The Echoing Depths 🌌

> **Um mod completo de expansão dimensional para Minecraft 1.20.1 (Forge + GeckoLib 4)**  
> **Autor:** Davi Lucas  
> **Mod ID:** `echoingdepths`  
> **Versão:** `1.0.0`  

---

## 📖 Visão Geral do Mod

**The Echoing Depths** abre o portal misterioso de *Reinforced Deepslate* (Ardósia Reforçada) encontrado no centro das Cidades Ancestrais (*Ancient Cities*), revelando uma dimensão subterrânea profunda, dominada por energias de sculk, cristais de ressonância, fogo de almas e criaturas ancestrais.

---

## 🌀 Como Acessar a Dimensão

1. **Localize ou Construa o Portal:**
   - Encontre o portal gigante no centro da **Ancient City** (feito de `Reinforced Deepslate`) ou construa uma moldura retangular (estilo portal do Nether) usando Ardósia Reforçada.
2. **Obtenha a Bola de Fogo Azul (*Blue Fireball*):**
   - **Drop:** 5% de chance ao derrotar um Warden.
   - **Crafting:** 1 *Fire Charge* + 1 *Echo Shard* + 1 *Soul Sand*.
3. **Ativação:**
   - Clique com o botão direito na base interior do portal com a **Blue Fireball** para acender o vórtice dimensional com efeitos sonoros e partículas etéreas exclusivas.

---

## 🏞️ Biomas Exclusivos

1. **Abyssal Depths:** O coração sombrio da dimensão, repleto de sculk vivo e estruturas de pedra de eco.
2. **Crystal Hollows:** Cavernas iluminadas por geodos de cristais ressonantes e formações de ametista e quartzo de eco.
3. **Echo Plains:** Planícies subterrâneas de grama e musgo de eco, onde vagam os *Echo Stalkers*.
4. **Soulfire Wastes:** Desertos áridos queimando com fogo de almas eterno e névoa azul, lar do temível *Soulfire Wraith*.
5. **Whispering Forest:** Floresta densa de árvores *Gloomwood* e cogumelos luminosos (*Glowcaps*), habitada por *Soul Wisps*.

---

## 👾 Entidades e Bosses (Totalmente Animados com GeckoLib 4)

| Entidade | Tipo | Descrição & Habilidades | Drops Principais |
| :--- | :--- | :--- | :--- |
| **Echo Stalker** | Hostil / Predador | Predador quadrúpede esguio com gait de emboscada e salto rápido nas sombras. | *Stalker Fang*, *Echo Shards* |
| **Sculk Crawler** | Hostil / Insetoide | Artrópode ágil que se move pelas paredes e inflije cegueira e efeito de ressonância. | *Gloom Spores*, *Sculk* |
| **Soul Wisp** | Neutro / Voador | Fogo-fátuo flutuante que emite luz suave e foge de ataques rápidos. | *Wisp Essence*, *Soul Fireball* |
| **Soulfire Wraith** | Mini-Boss | Espectro encapuzado voador que invoca esferas de fogo azul e ceifa com foice espectral. | *Wraith Heart*, *Soulfire Dust*, *Soulfire Staff* |
| **Echo Colossus** | Boss Titânico | Guardião colossal de pedra de eco; desfere pisadas sísmicas e pulsos sônicos em área. | *Colossus Core*, *Abyssal Greatsword*, *Resonite Gems* |

---

## ⚔️ Equipamentos & Progressão

1. **Tier Echorite (Ferro Avançado):**
   - Minério fundido em lingotes para criar ferramentas e armaduras duráveis com resistência natural a dano sônico.
2. **Tier Resonite (End-Game / Superior a Netherite):**
   - Obtido através da **Bancada de Ferraria (*Smithing Table*)** combinando peças de Echorite + *Resonite Gem* + *Resonite Upgrade Smithing Template*.
   - A armadura completa concede imunidade à lentidão, redução de 50% em dano mágico e aumento na velocidade de ataque.
3. **Armas Lendárias & Focos Mágicos:**
   - **Abyssal Greatsword:** Espada de duas mãos com alto dano de corte e ricochete sônico.
   - **Sonic Scepter:** Cetro mágico que dispara projéteis de choque sônico perfurante.
   - **Soulfire Staff:** Cajado que conjura rajadas contínuas de chamas de almas azuis.

---

## 🧪 Alquimia e Poções Novas

Utilizando o Suporte de Poções (*Brewing Stand*):
- **Poção de Visão de Eco (*Echo Sight*):** Permite enxergar no escuro total e destacar entidades próximas.
- **Poção de Queimadura de Almas (*Soul Burn*):** Incendeia inimigos com chamas azuis que ignoram armadura.
- **Poção de Ressonância (*Resonance*):** Amplifica ataques físicos gerando ondas de choque secundárias.
- **Poção de Proteção de Sculk (*Sculk Ward*):** Reduz o som emitido pelo jogador e anula detecção de sensores sculk.

---

## 🪵 Conjunto de Construção Gloomwood & Echo Stone

- **Gloomwood:** Madeira escura e profunda com tábuas, troncos sem casca, escadas, lajes, cercas, portões, portas, alçapões, botões e placas de pressão.
- **Echo Stone:** Variações completas de pedra lisa, tijolos entalhados (*chiseled*), rachados, tijolos de eco, mosaicos (*tiles*), muros e escadas.
- **Iluminação & Utilitários:**
  - *Echo Lantern* e *Resonant Lamp* (fontes de luz viva com partículas).
  - *Resonant Altar* (bloco decorativo e focalizador de rituais).
  - *Glowcap* (cogumelo luminoso comensurável em ensopados).

---

## 🛠️ Como Compilar o Arquivo .JAR

Para gerar o binário oficial do mod para instalação em clientes e servidores Minecraft:

```bash
# Executa a limpeza e compilação do pacote Forge
./gradlew build --offline
```

O arquivo final `.jar` gerado se localiza em:
📁 `build/libs/echoingdepths-1.0.0.jar`

Basta copiar esse arquivo para a pasta `.minecraft/mods` com o **Minecraft Forge 1.20.1 (47.4.10+)** e o **GeckoLib 4.8.4+** instalados!
