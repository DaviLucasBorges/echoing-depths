package com.davilucas.echoingdepths;

import com.davilucas.echoingdepths.init.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.bernie.geckolib.GeckoLib;

@Mod(EchoingDepths.MODID)
public class EchoingDepths {
    public static final String MODID = "echoingdepths";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    public EchoingDepths() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Register registries
        ModBlocks.register(modEventBus);
        ModItems.register(modEventBus);
        ModEntities.register(modEventBus);
        ModParticles.register(modEventBus);
        ModSounds.register(modEventBus);
        ModEffects.register(modEventBus);
        ModPotions.register(modEventBus);
        ModEnchantments.register(modEventBus);
        ModCreativeTabs.register(modEventBus);

        // Initialize GeckoLib
        GeckoLib.initialize();

        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("The Echoing Depths mod initialized successfully!");
    }
}
