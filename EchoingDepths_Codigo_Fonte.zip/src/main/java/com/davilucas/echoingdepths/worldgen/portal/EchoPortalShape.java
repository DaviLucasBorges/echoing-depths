package com.davilucas.echoingdepths.worldgen.portal;

import com.davilucas.echoingdepths.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import java.util.ArrayList;
import java.util.List;

public class EchoPortalShape {
    public static boolean trySpawnPortal(LevelAccessor level, BlockPos pos) {
        // Try along X axis then Z axis
        return trySpawnAxis(level, pos, Direction.Axis.X) || trySpawnAxis(level, pos, Direction.Axis.Z);
    }

    private static boolean trySpawnAxis(LevelAccessor level, BlockPos pos, Direction.Axis axis) {
        Direction dirRight = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
        Direction dirLeft = dirRight.getOpposite();

        // Find floor of the potential portal
        BlockPos.MutableBlockPos cursor = pos.mutable();
        while (cursor.getY() > level.getMinBuildHeight() && isPortalOrAir(level, cursor)) {
            cursor.move(Direction.DOWN);
        }

        if (!isFrameBlock(level, cursor)) {
            return false;
        }

        BlockPos bottomFrame = cursor.immutable();
        BlockPos portalBottom = bottomFrame.above();

        // Scan left frame bound
        cursor.set(portalBottom);
        int leftDist = 0;
        while (leftDist < 25 && isPortalOrAir(level, cursor)) {
            cursor.move(dirLeft);
            leftDist++;
        }
        if (!isFrameBlock(level, cursor)) return false;
        int minOffset = -leftDist + 1;

        // Scan right frame bound
        cursor.set(portalBottom);
        int rightDist = 0;
        while (rightDist < 25 && isPortalOrAir(level, cursor)) {
            cursor.move(dirRight);
            rightDist++;
        }
        if (!isFrameBlock(level, cursor)) return false;
        int maxOffset = rightDist - 1;

        int width = (maxOffset - minOffset) + 1;
        if (width < 2 || width > 22) return false;

        // Scan height
        cursor.set(portalBottom);
        int height = 0;
        while (height < 25 && isPortalOrAir(level, cursor)) {
            cursor.move(Direction.UP);
            height++;
        }
        if (!isFrameBlock(level, cursor)) return false;
        if (height < 3 || height > 22) return false;

        // Verify bottom and top frame
        for (int i = minOffset; i <= maxOffset; i++) {
            BlockPos b = portalBottom.relative(dirRight, i).below();
            BlockPos t = portalBottom.relative(dirRight, i).above(height);
            if (!isFrameBlock(level, b) || !isFrameBlock(level, t)) {
                return false;
            }
        }

        // Verify side frames and collect interior air blocks
        List<BlockPos> interior = new ArrayList<>();
        for (int y = 0; y < height; y++) {
            BlockPos leftSide = portalBottom.relative(dirRight, minOffset - 1).above(y);
            BlockPos rightSide = portalBottom.relative(dirRight, maxOffset + 1).above(y);
            if (!isFrameBlock(level, leftSide) || !isFrameBlock(level, rightSide)) {
                return false;
            }
            for (int i = minOffset; i <= maxOffset; i++) {
                BlockPos p = portalBottom.relative(dirRight, i).above(y);
                if (!isPortalOrAir(level, p)) {
                    return false;
                }
                interior.add(p);
            }
        }

        // Success! Fill the interior with EchoPortalBlock
        BlockState portalState = ModBlocks.ECHO_PORTAL.get().defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_AXIS, axis);

        for (BlockPos p : interior) {
            level.setBlock(p, portalState, 3);
        }

        return true;
    }

    private static boolean isPortalOrAir(LevelAccessor level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.isAir() || state.is(ModBlocks.ECHO_PORTAL.get()) || state.canBeReplaced();
    }

    private static boolean isFrameBlock(LevelAccessor level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.is(Blocks.REINFORCED_DEEPSLATE);
    }
}
