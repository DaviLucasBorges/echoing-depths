package com.davilucas.echoingdepths.worldgen.portal;

import com.davilucas.echoingdepths.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraftforge.common.util.ITeleporter;

import java.util.function.Function;

public class EchoTeleporter implements ITeleporter {
    private final ServerLevel level;
    private final BlockPos sourcePos;

    public EchoTeleporter(ServerLevel level, BlockPos sourcePos) {
        this.level = level;
        this.sourcePos = sourcePos;
    }

    @Override
    public Entity placeEntity(Entity entity, ServerLevel currentWorld, ServerLevel destWorld, float yaw, Function<Boolean, Entity> repositionEntity) {
        Entity teleportedEntity = repositionEntity.apply(false);
        if (teleportedEntity == null) return null;

        BlockPos targetPos = findOrCreatePortal(destWorld, this.sourcePos);
        teleportedEntity.teleportTo(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5);

        return teleportedEntity;
    }

    private BlockPos findOrCreatePortal(ServerLevel destWorld, BlockPos src) {
        // Search for an existing echo portal within 64 blocks
        int searchRadius = 48;
        BlockPos.MutableBlockPos checkPos = new BlockPos.MutableBlockPos();

        int targetY = Math.max(32, Math.min(destWorld.getHeight() - 32, src.getY()));

        for (int dx = -searchRadius; dx <= searchRadius; dx += 2) {
            for (int dz = -searchRadius; dz <= searchRadius; dz += 2) {
                for (int dy = -16; dy <= 16; dy += 2) {
                    checkPos.set(src.getX() + dx, targetY + dy, src.getZ() + dz);
                    if (destWorld.getBlockState(checkPos).is(ModBlocks.ECHO_PORTAL.get())) {
                        return checkPos.immutable();
                    }
                }
            }
        }

        // If not found, build a safe portal structure
        BlockPos buildPos = new BlockPos(src.getX(), targetY, src.getZ());
        buildPortalFrame(destWorld, buildPos);
        return buildPos.above();
    }

    public static void buildPortalFrame(ServerLevel level, BlockPos base) {
        // 4x5 portal frame of reinforced deepslate filled with echo_portal
        BlockState frame = Blocks.REINFORCED_DEEPSLATE.defaultBlockState();
        BlockState portal = ModBlocks.ECHO_PORTAL.get().defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_AXIS, Direction.Axis.X);

        // Platform underneath
        for (int x = -2; x <= 3; x++) {
            for (int z = -2; z <= 2; z++) {
                level.setBlockAndUpdate(base.offset(x, -1, z), Blocks.POLISHED_DEEPSLATE.defaultBlockState());
                // Clear air above
                for (int y = 0; y <= 5; y++) {
                    level.setBlockAndUpdate(base.offset(x, y, z), Blocks.AIR.defaultBlockState());
                }
            }
        }

        // Frame
        for (int x = -1; x <= 2; x++) {
            level.setBlockAndUpdate(base.offset(x, 0, 0), frame);
            level.setBlockAndUpdate(base.offset(x, 4, 0), frame);
        }
        for (int y = 1; y <= 3; y++) {
            level.setBlockAndUpdate(base.offset(-1, y, 0), frame);
            level.setBlockAndUpdate(base.offset(2, y, 0), frame);
            // Inside portal blocks
            level.setBlockAndUpdate(base.offset(0, y, 0), portal);
            level.setBlockAndUpdate(base.offset(1, y, 0), portal);
        }
    }
}
