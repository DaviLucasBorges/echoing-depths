package com.davilucas.echoingdepths.worldgen.dimension;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;

public class ModDimensions {
    public static final ResourceKey<Level> ECHOING_DEPTHS_LEVEL =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(EchoingDepths.MODID, "echoing_depths"));

    public static final ResourceKey<DimensionType> ECHOING_DEPTHS_TYPE =
            ResourceKey.create(Registries.DIMENSION_TYPE, new ResourceLocation(EchoingDepths.MODID, "echoing_depths"));
}
