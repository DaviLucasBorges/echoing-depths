package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, EchoingDepths.MODID);

    public static final RegistryObject<SimpleParticleType> ECHO_PORTAL =
            PARTICLE_TYPES.register("echo_portal", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> SOUL_EMBER =
            PARTICLE_TYPES.register("soul_ember", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> RESONANCE_SPARK =
            PARTICLE_TYPES.register("resonance_spark", () -> new SimpleParticleType(false));

    public static void register(IEventBus eventBus) {
        PARTICLE_TYPES.register(eventBus);
    }
}
