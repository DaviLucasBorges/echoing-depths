package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, EchoingDepths.MODID);

    public static final RegistryObject<SoundEvent> PORTAL_AMBIENT = register("block.echo_portal.ambient");
    public static final RegistryObject<SoundEvent> PORTAL_TRAVEL = register("block.echo_portal.travel");
    public static final RegistryObject<SoundEvent> PORTAL_IGNITE = register("item.blue_fireball.ignite");
    public static final RegistryObject<SoundEvent> SONIC_PULSE = register("item.sonic_scepter.shoot");
    public static final RegistryObject<SoundEvent> SOUL_FIREBALL = register("item.soulfire_staff.shoot");
    public static final RegistryObject<SoundEvent> COLOSSUS_ROAR = register("entity.echo_colossus.roar");
    public static final RegistryObject<SoundEvent> COLOSSUS_SLAM = register("entity.echo_colossus.slam");
    public static final RegistryObject<SoundEvent> WRAITH_SCREAM = register("entity.soulfire_wraith.scream");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(EchoingDepths.MODID, name)));
    }

    public static void register(IEventBus eventBus) {
        SOUND_EVENTS.register(eventBus);
    }
}
