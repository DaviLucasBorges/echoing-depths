package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEffects {
    public static final DeferredRegister<MobEffect> MOB_EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, EchoingDepths.MODID);

    public static final RegistryObject<MobEffect> ECHO_SIGHT = MOB_EFFECTS.register("echo_sight",
            () -> new ModMobEffect(MobEffectCategory.BENEFICIAL, 0x38E1E6));

    public static final RegistryObject<MobEffect> RESONANCE = MOB_EFFECTS.register("resonance",
            () -> new ModMobEffect(MobEffectCategory.HARMFUL, 0x8C52FF));

    public static final RegistryObject<MobEffect> SOUL_BURN = MOB_EFFECTS.register("soul_burn",
            () -> new SoulBurnEffect(MobEffectCategory.HARMFUL, 0x228BE6));

    public static final RegistryObject<MobEffect> SCULK_WARD = MOB_EFFECTS.register("sculk_ward",
            () -> new ModMobEffect(MobEffectCategory.BENEFICIAL, 0x05445E));

    public static class ModMobEffect extends MobEffect {
        public ModMobEffect(MobEffectCategory category, int color) {
            super(category, color);
        }
    }

    public static class SoulBurnEffect extends MobEffect {
        public SoulBurnEffect(MobEffectCategory category, int color) {
            super(category, color);
        }

        @Override
        public void applyEffectTick(LivingEntity entity, int amplifier) {
            entity.hurt(entity.damageSources().magic(), 1.5f + (amplifier * 0.5f));
        }

        @Override
        public boolean isDurationEffectTick(int duration, int amplifier) {
            int interval = 25 >> amplifier;
            return interval <= 0 || duration % interval == 0;
        }
    }

    public static void register(IEventBus eventBus) {
        MOB_EFFECTS.register(eventBus);
    }
}
