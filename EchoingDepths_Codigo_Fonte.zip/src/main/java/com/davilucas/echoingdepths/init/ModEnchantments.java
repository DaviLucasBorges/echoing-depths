package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS =
            DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, EchoingDepths.MODID);

    public static final RegistryObject<Enchantment> SONIC_STRIKE = ENCHANTMENTS.register("sonic_strike",
            () -> new ModEnchantment(Enchantment.Rarity.RARE, EnchantmentCategory.WEAPON, new EquipmentSlot[]{EquipmentSlot.MAINHAND}, 3));

    public static final RegistryObject<Enchantment> SOUL_SIPHON = ENCHANTMENTS.register("soul_siphon",
            () -> new ModEnchantment(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON, new EquipmentSlot[]{EquipmentSlot.MAINHAND}, 3));

    public static final RegistryObject<Enchantment> DEEP_SIGHT = ENCHANTMENTS.register("deep_sight",
            () -> new ModEnchantment(Enchantment.Rarity.RARE, EnchantmentCategory.ARMOR_HEAD, new EquipmentSlot[]{EquipmentSlot.HEAD}, 1));

    public static class ModEnchantment extends Enchantment {
        private final int maxLevel;

        public ModEnchantment(Rarity rarity, EnchantmentCategory category, EquipmentSlot[] applicableSlots, int maxLevel) {
            super(rarity, category, applicableSlots);
            this.maxLevel = maxLevel;
        }

        @Override
        public int getMaxLevel() {
            return maxLevel;
        }

        @Override
        public int getMinCost(int level) {
            return 10 + (level - 1) * 12;
        }

        @Override
        public int getMaxCost(int level) {
            return getMinCost(level) + 20;
        }
    }

    public static void register(IEventBus eventBus) {
        ENCHANTMENTS.register(eventBus);
    }
}
