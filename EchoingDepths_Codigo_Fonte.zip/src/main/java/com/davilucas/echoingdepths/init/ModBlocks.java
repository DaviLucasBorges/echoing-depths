package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.block.EchoPortalBlock;
import com.davilucas.echoingdepths.block.GlowcapBlock;
import com.davilucas.echoingdepths.block.ResonantAltarBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, EchoingDepths.MODID);

    // Stone family
    public static final RegistryObject<Block> ECHO_STONE = registerBlock("echo_stone",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE).mapColor(MapColor.COLOR_BLUE)));

    public static final RegistryObject<Block> COBBLED_ECHO_STONE = registerBlock("cobbled_echo_stone",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.COBBLED_DEEPSLATE)));

    public static final RegistryObject<Block> POLISHED_ECHO_STONE = registerBlock("polished_echo_stone",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.POLISHED_DEEPSLATE)));

    public static final RegistryObject<Block> ECHO_STONE_BRICKS = registerBlock("echo_stone_bricks",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_BRICKS)));

    public static final RegistryObject<Block> CRACKED_ECHO_STONE_BRICKS = registerBlock("cracked_echo_stone_bricks",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.CRACKED_DEEPSLATE_BRICKS)));

    public static final RegistryObject<Block> CHISELED_ECHO_STONE_BRICKS = registerBlock("chiseled_echo_stone_bricks",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.CHISELED_DEEPSLATE).lightLevel(s -> 5)));

    public static final RegistryObject<Block> ECHO_TILES = registerBlock("echo_tiles",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_TILES)));

    public static final RegistryObject<Block> ECHO_STONE_STAIRS = registerBlock("echo_stone_stairs",
            () -> new StairBlock(() -> ECHO_STONE.get().defaultBlockState(), BlockBehaviour.Properties.copy(ECHO_STONE.get())));

    public static final RegistryObject<Block> ECHO_STONE_SLAB = registerBlock("echo_stone_slab",
            () -> new SlabBlock(BlockBehaviour.Properties.copy(ECHO_STONE.get())));

    public static final RegistryObject<Block> ECHO_STONE_WALL = registerBlock("echo_stone_wall",
            () -> new WallBlock(BlockBehaviour.Properties.copy(ECHO_STONE.get())));

    public static final RegistryObject<Block> ECHO_BRICK_STAIRS = registerBlock("echo_brick_stairs",
            () -> new StairBlock(() -> ECHO_STONE_BRICKS.get().defaultBlockState(), BlockBehaviour.Properties.copy(ECHO_STONE_BRICKS.get())));

    public static final RegistryObject<Block> ECHO_BRICK_SLAB = registerBlock("echo_brick_slab",
            () -> new SlabBlock(BlockBehaviour.Properties.copy(ECHO_STONE_BRICKS.get())));

    public static final RegistryObject<Block> ECHO_BRICK_WALL = registerBlock("echo_brick_wall",
            () -> new WallBlock(BlockBehaviour.Properties.copy(ECHO_STONE_BRICKS.get())));

    // Soil & Moss
    public static final RegistryObject<Block> ECHO_SOIL = registerBlock("echo_soil",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIRT).mapColor(MapColor.COLOR_BLUE)));

    public static final RegistryObject<Block> ECHO_MOSS_BLOCK = registerBlock("echo_moss_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.MOSS_BLOCK).lightLevel(s -> 3)));

    // Ores
    public static final RegistryObject<Block> ECHORITE_ORE = registerBlock("echorite_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_IRON_ORE)));

    public static final RegistryObject<Block> RESONITE_ORE = registerBlock("resonite_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_DIAMOND_ORE).lightLevel(s -> 6)));

    public static final RegistryObject<Block> SOULFIRE_ORE = registerBlock("soulfire_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_REDSTONE_ORE).lightLevel(s -> 8)));

    // Storage blocks
    public static final RegistryObject<Block> RAW_ECHORITE_BLOCK = registerBlock("raw_echorite_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.RAW_IRON_BLOCK)));

    public static final RegistryObject<Block> ECHORITE_BLOCK = registerBlock("echorite_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));

    public static final RegistryObject<Block> RESONITE_BLOCK = registerBlock("resonite_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIAMOND_BLOCK).lightLevel(s -> 10)));

    public static final RegistryObject<Block> ECHO_CRYSTAL_BLOCK = registerBlock("echo_crystal_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.AMETHYST_BLOCK).lightLevel(s -> 8)));

    // Wood family (Gloomwood)
    public static final RegistryObject<Block> GLOOMWOOD_LOG = registerBlock("gloomwood_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LOG)));

    public static final RegistryObject<Block> STRIPPED_GLOOMWOOD_LOG = registerBlock("stripped_gloomwood_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.STRIPPED_OAK_LOG)));

    public static final RegistryObject<Block> GLOOMWOOD_WOOD = registerBlock("gloomwood_wood",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_WOOD)));

    public static final RegistryObject<Block> STRIPPED_GLOOMWOOD_WOOD = registerBlock("stripped_gloomwood_wood",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.STRIPPED_OAK_WOOD)));

    public static final RegistryObject<Block> GLOOMWOOD_PLANKS = registerBlock("gloomwood_planks",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS)));

    public static final RegistryObject<Block> GLOOMWOOD_STAIRS = registerBlock("gloomwood_stairs",
            () -> new StairBlock(() -> GLOOMWOOD_PLANKS.get().defaultBlockState(), BlockBehaviour.Properties.copy(GLOOMWOOD_PLANKS.get())));

    public static final RegistryObject<Block> GLOOMWOOD_SLAB = registerBlock("gloomwood_slab",
            () -> new SlabBlock(BlockBehaviour.Properties.copy(GLOOMWOOD_PLANKS.get())));

    public static final RegistryObject<Block> GLOOMWOOD_FENCE = registerBlock("gloomwood_fence",
            () -> new FenceBlock(BlockBehaviour.Properties.copy(GLOOMWOOD_PLANKS.get())));

    public static final RegistryObject<Block> GLOOMWOOD_FENCE_GATE = registerBlock("gloomwood_fence_gate",
            () -> new FenceGateBlock(BlockBehaviour.Properties.copy(GLOOMWOOD_PLANKS.get()), WoodType.WARPED));

    public static final RegistryObject<Block> GLOOMWOOD_DOOR = registerBlock("gloomwood_door",
            () -> new DoorBlock(BlockBehaviour.Properties.copy(Blocks.OAK_DOOR), BlockSetType.WARPED));

    public static final RegistryObject<Block> GLOOMWOOD_TRAPDOOR = registerBlock("gloomwood_trapdoor",
            () -> new TrapDoorBlock(BlockBehaviour.Properties.copy(Blocks.OAK_TRAPDOOR), BlockSetType.WARPED));

    public static final RegistryObject<Block> GLOOMWOOD_BUTTON = registerBlock("gloomwood_button",
            () -> new ButtonBlock(BlockBehaviour.Properties.copy(Blocks.OAK_BUTTON), BlockSetType.WARPED, 30, true));

    public static final RegistryObject<Block> GLOOMWOOD_PRESSURE_PLATE = registerBlock("gloomwood_pressure_plate",
            () -> new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, BlockBehaviour.Properties.copy(Blocks.OAK_PRESSURE_PLATE), BlockSetType.WARPED));

    public static final RegistryObject<Block> GLOOMWOOD_LEAVES = registerBlock("gloomwood_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LEAVES).lightLevel(s -> 4)));

    public static final RegistryObject<Block> GLOOMWOOD_SAPLING = registerBlock("gloomwood_sapling",
            () -> new SaplingBlock(new AbstractTreeGrower() {
                @Override
                protected net.minecraft.resources.ResourceKey<net.minecraft.world.level.levelgen.feature.ConfiguredFeature<?, ?>> getConfiguredFeature(net.minecraft.util.RandomSource random, boolean hasFlowers) {
                    return null;
                }
            }, BlockBehaviour.Properties.copy(Blocks.OAK_SAPLING)));

    // Vegetation & Deco
    public static final RegistryObject<Block> ECHO_GRASS = registerBlock("echo_grass",
            () -> new BushBlock(BlockBehaviour.Properties.copy(Blocks.GRASS).lightLevel(s -> 5)));

    public static final RegistryObject<Block> GLOWCAP = registerBlock("glowcap",
            () -> new GlowcapBlock(BlockBehaviour.Properties.copy(Blocks.BROWN_MUSHROOM).lightLevel(s -> 8)));

    public static final RegistryObject<Block> ECHO_CRYSTAL_CLUSTER = registerBlock("echo_crystal_cluster",
            () -> new AmethystClusterBlock(7, 3, BlockBehaviour.Properties.copy(Blocks.AMETHYST_CLUSTER).lightLevel(s -> 8)));

    public static final RegistryObject<Block> RESONANT_LAMP = registerBlock("resonant_lamp",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.SEA_LANTERN).lightLevel(s -> 15)));

    public static final RegistryObject<Block> ECHO_GLASS = registerBlock("echo_glass",
            () -> new GlassBlock(BlockBehaviour.Properties.copy(Blocks.GLASS).noOcclusion()));

    public static final RegistryObject<Block> ECHO_LANTERN = registerBlock("echo_lantern",
            () -> new LanternBlock(BlockBehaviour.Properties.copy(Blocks.LANTERN).lightLevel(s -> 15)));

    public static final RegistryObject<Block> RESONANT_ALTAR = registerBlock("resonant_altar",
            () -> new ResonantAltarBlock(BlockBehaviour.Properties.copy(Blocks.RESPAWN_ANCHOR).lightLevel(s -> 8)));

    // Portal
    public static final RegistryObject<Block> ECHO_PORTAL = BLOCKS.register("echo_portal",
            () -> new EchoPortalBlock(BlockBehaviour.Properties.copy(Blocks.NETHER_PORTAL).noCollission().strength(-1.0F).lightLevel(s -> 11)));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> blockSupplier) {
        RegistryObject<T> block = BLOCKS.register(name, blockSupplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}
