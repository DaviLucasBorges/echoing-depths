package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.EchoStalkerEntity;
import com.davilucas.echoingdepths.entity.SculkCrawlerEntity;
import com.davilucas.echoingdepths.entity.SoulWispEntity;
import com.davilucas.echoingdepths.entity.boss.EchoColossusEntity;
import com.davilucas.echoingdepths.entity.boss.SoulfireWraithEntity;
import com.davilucas.echoingdepths.entity.projectile.BlueFireballProjectile;
import com.davilucas.echoingdepths.entity.projectile.ResonantPulseProjectile;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EchoingDepths.MODID);

    public static final RegistryObject<EntityType<EchoStalkerEntity>> ECHO_STALKER =
            ENTITY_TYPES.register("echo_stalker",
                    () -> EntityType.Builder.of(EchoStalkerEntity::new, MobCategory.MONSTER)
                            .sized(1.2F, 1.1F)
                            .build(new ResourceLocation(EchoingDepths.MODID, "echo_stalker").toString()));

    public static final RegistryObject<EntityType<SculkCrawlerEntity>> SCULK_CRAWLER =
            ENTITY_TYPES.register("sculk_crawler",
                    () -> EntityType.Builder.of(SculkCrawlerEntity::new, MobCategory.MONSTER)
                            .sized(1.1F, 0.7F)
                            .build(new ResourceLocation(EchoingDepths.MODID, "sculk_crawler").toString()));

    public static final RegistryObject<EntityType<SoulWispEntity>> SOUL_WISP =
            ENTITY_TYPES.register("soul_wisp",
                    () -> EntityType.Builder.of(SoulWispEntity::new, MobCategory.AMBIENT)
                            .sized(0.6F, 0.6F)
                            .build(new ResourceLocation(EchoingDepths.MODID, "soul_wisp").toString()));

    public static final RegistryObject<EntityType<EchoColossusEntity>> ECHO_COLOSSUS =
            ENTITY_TYPES.register("echo_colossus",
                    () -> EntityType.Builder.of(EchoColossusEntity::new, MobCategory.MONSTER)
                            .sized(2.4F, 3.8F)
                            .fireImmune()
                            .build(new ResourceLocation(EchoingDepths.MODID, "echo_colossus").toString()));

    public static final RegistryObject<EntityType<SoulfireWraithEntity>> SOULFIRE_WRAITH =
            ENTITY_TYPES.register("soulfire_wraith",
                    () -> EntityType.Builder.of(SoulfireWraithEntity::new, MobCategory.MONSTER)
                            .sized(1.2F, 2.5F)
                            .fireImmune()
                            .build(new ResourceLocation(EchoingDepths.MODID, "soulfire_wraith").toString()));

    public static final RegistryObject<EntityType<BlueFireballProjectile>> BLUE_FIREBALL =
            ENTITY_TYPES.register("blue_fireball",
                    () -> EntityType.Builder.<BlueFireballProjectile>of(BlueFireballProjectile::new, MobCategory.MISC)
                            .sized(0.5F, 0.5F)
                            .clientTrackingRange(4)
                            .updateInterval(10)
                            .build(new ResourceLocation(EchoingDepths.MODID, "blue_fireball").toString()));

    public static final RegistryObject<EntityType<ResonantPulseProjectile>> RESONANT_PULSE =
            ENTITY_TYPES.register("resonant_pulse",
                    () -> EntityType.Builder.<ResonantPulseProjectile>of(ResonantPulseProjectile::new, MobCategory.MISC)
                            .sized(0.6F, 0.6F)
                            .clientTrackingRange(4)
                            .updateInterval(10)
                            .build(new ResourceLocation(EchoingDepths.MODID, "resonant_pulse").toString()));

    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}
