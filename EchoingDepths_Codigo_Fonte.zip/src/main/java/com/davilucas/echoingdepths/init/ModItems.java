package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.item.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, EchoingDepths.MODID);

    // Key Portal Activator & Weapon
    public static final RegistryObject<Item> BLUE_FIREBALL = ITEMS.register("blue_fireball",
            () -> new BlueFireballItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(16)));

    // Materials
    public static final RegistryObject<Item> RAW_ECHORITE = ITEMS.register("raw_echorite",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_INGOT = ITEMS.register("echorite_ingot",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_NUGGET = ITEMS.register("echorite_nugget",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> RESONITE_GEM = ITEMS.register("resonite_gem",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> SOULFIRE_DUST = ITEMS.register("soulfire_dust",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> ECHO_CRYSTAL_SHARD = ITEMS.register("echo_crystal_shard",
            () -> new Item(new Item.Properties()));

    // Mob & Boss drops
    public static final RegistryObject<Item> STALKER_FANG = ITEMS.register("stalker_fang",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> GLOOM_SPORE = ITEMS.register("gloom_spore",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> WISP_ESSENCE = ITEMS.register("wisp_essence",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> COLOSSUS_CORE = ITEMS.register("colossus_core",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> WRAITH_HEART = ITEMS.register("wraith_heart",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC)));

    // Artifacts & Sigils
    public static final RegistryObject<Item> RESONITE_UPGRADE_SMITHING_TEMPLATE = ITEMS.register("resonite_upgrade_smithing_template",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> RESONANT_SIGIL = ITEMS.register("resonant_sigil",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> SOULFIRE_SIGIL = ITEMS.register("soulfire_sigil",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> ECHO_ORB = ITEMS.register("echo_orb",
            () -> new Item(new Item.Properties()));

    // Food
    public static final RegistryObject<Item> GLOWCAP_STEW = ITEMS.register("glowcap_stew",
            () -> new BowlFoodItem(new Item.Properties().stacksTo(1).food(new FoodProperties.Builder()
                    .nutrition(7).saturationMod(0.8F)
                    .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(ModEffects.ECHO_SIGHT.get(), 600, 0), 1.0F)
                    .build())));

    // Special Weapons & Staves
    public static final RegistryObject<Item> SONIC_SCEPTER = ITEMS.register("sonic_scepter",
            () -> new SonicScepterItem(new Item.Properties().durability(450).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> SOULFIRE_STAFF = ITEMS.register("soulfire_staff",
            () -> new SoulfireStaffItem(new Item.Properties().durability(500).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> ABYSSAL_GREATSWORD = ITEMS.register("abyssal_greatsword",
            () -> new AbyssalGreatswordItem(EchoTier.RESONITE, 7, -2.8F,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    // Echorite Tools
    public static final RegistryObject<Item> ECHORITE_SWORD = ITEMS.register("echorite_sword",
            () -> new SwordItem(EchoTier.ECHORITE, 3, -2.4F, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_PICKAXE = ITEMS.register("echorite_pickaxe",
            () -> new PickaxeItem(EchoTier.ECHORITE, 1, -2.8F, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_AXE = ITEMS.register("echorite_axe",
            () -> new AxeItem(EchoTier.ECHORITE, 6.0F, -3.1F, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_SHOVEL = ITEMS.register("echorite_shovel",
            () -> new ShovelItem(EchoTier.ECHORITE, 1.5F, -3.0F, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_HOE = ITEMS.register("echorite_hoe",
            () -> new HoeItem(EchoTier.ECHORITE, -2, -1.0F, new Item.Properties()));

    // Resonite Tools (Tier above Netherite)
    public static final RegistryObject<Item> RESONITE_SWORD = ITEMS.register("resonite_sword",
            () -> new SwordItem(EchoTier.RESONITE, 4, -2.4F, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_PICKAXE = ITEMS.register("resonite_pickaxe",
            () -> new PickaxeItem(EchoTier.RESONITE, 1, -2.8F, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_AXE = ITEMS.register("resonite_axe",
            () -> new AxeItem(EchoTier.RESONITE, 6.0F, -3.0F, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_SHOVEL = ITEMS.register("resonite_shovel",
            () -> new ShovelItem(EchoTier.RESONITE, 1.5F, -3.0F, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_HOE = ITEMS.register("resonite_hoe",
            () -> new HoeItem(EchoTier.RESONITE, -3, 0.0F, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    // Echorite Armor
    public static final RegistryObject<Item> ECHORITE_HELMET = ITEMS.register("echorite_helmet",
            () -> new ModArmorItem(ModArmorMaterials.ECHORITE, ArmorItem.Type.HELMET, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_CHESTPLATE = ITEMS.register("echorite_chestplate",
            () -> new ModArmorItem(ModArmorMaterials.ECHORITE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_LEGGINGS = ITEMS.register("echorite_leggings",
            () -> new ModArmorItem(ModArmorMaterials.ECHORITE, ArmorItem.Type.LEGGINGS, new Item.Properties()));

    public static final RegistryObject<Item> ECHORITE_BOOTS = ITEMS.register("echorite_boots",
            () -> new ModArmorItem(ModArmorMaterials.ECHORITE, ArmorItem.Type.BOOTS, new Item.Properties()));

    // Resonite Armor
    public static final RegistryObject<Item> RESONITE_HELMET = ITEMS.register("resonite_helmet",
            () -> new ModArmorItem(ModArmorMaterials.RESONITE, ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_CHESTPLATE = ITEMS.register("resonite_chestplate",
            () -> new ModArmorItem(ModArmorMaterials.RESONITE, ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_LEGGINGS = ITEMS.register("resonite_leggings",
            () -> new ModArmorItem(ModArmorMaterials.RESONITE, ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    public static final RegistryObject<Item> RESONITE_BOOTS = ITEMS.register("resonite_boots",
            () -> new ModArmorItem(ModArmorMaterials.RESONITE, ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.RARE).fireResistant()));

    // Spawn Eggs
    public static final RegistryObject<Item> ECHO_STALKER_SPAWN_EGG = ITEMS.register("echo_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ECHO_STALKER, 0x0E141C, 0x40E0D0, new Item.Properties()));

    public static final RegistryObject<Item> SCULK_CRAWLER_SPAWN_EGG = ITEMS.register("sculk_crawler_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SCULK_CRAWLER, 0x0A1016, 0x28E6D2, new Item.Properties()));

    public static final RegistryObject<Item> SOUL_WISP_SPAWN_EGG = ITEMS.register("soul_wisp_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SOUL_WISP, 0x145ADC, 0xDCFAFF, new Item.Properties()));

    public static final RegistryObject<Item> ECHO_COLOSSUS_SPAWN_EGG = ITEMS.register("echo_colossus_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ECHO_COLOSSUS, 0x10161C, 0x32DCF0, new Item.Properties()));

    public static final RegistryObject<Item> SOULFIRE_WRAITH_SPAWN_EGG = ITEMS.register("soulfire_wraith_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SOULFIRE_WRAITH, 0x0C0E16, 0x2896FF, new Item.Properties()));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
