package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModPotions {
    public static final DeferredRegister<Potion> POTIONS =
            DeferredRegister.create(ForgeRegistries.POTIONS, EchoingDepths.MODID);

    public static final RegistryObject<Potion> ECHO_SIGHT = POTIONS.register("echo_sight",
            () -> new Potion(new MobEffectInstance(ModEffects.ECHO_SIGHT.get(), 3600)));

    public static final RegistryObject<Potion> LONG_ECHO_SIGHT = POTIONS.register("long_echo_sight",
            () -> new Potion(new MobEffectInstance(ModEffects.ECHO_SIGHT.get(), 9600)));

    public static final RegistryObject<Potion> RESONANCE = POTIONS.register("resonance",
            () -> new Potion(new MobEffectInstance(ModEffects.RESONANCE.get(), 1800)));

    public static final RegistryObject<Potion> SOUL_BURN = POTIONS.register("soul_burn",
            () -> new Potion(new MobEffectInstance(ModEffects.SOUL_BURN.get(), 900)));

    public static final RegistryObject<Potion> SCULK_WARD = POTIONS.register("sculk_ward",
            () -> new Potion(new MobEffectInstance(ModEffects.SCULK_WARD.get(), 3600)));

    public static void register(IEventBus eventBus) {
        POTIONS.register(eventBus);
    }
}
