package com.davilucas.echoingdepths.init;

import com.davilucas.echoingdepths.EchoingDepths;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EchoingDepths.MODID);

    public static final RegistryObject<CreativeModeTab> ECHOING_DEPTHS_TAB = CREATIVE_MODE_TABS.register("echoing_depths_tab",
            () -> CreativeModeTab.builder()
                    .icon(() -> new ItemStack(ModItems.BLUE_FIREBALL.get()))
                    .title(Component.translatable("creativetab.echoingdepths"))
                    .displayItems((parameters, output) -> {
                        // Key items
                        output.accept(ModItems.BLUE_FIREBALL.get());
                        output.accept(ModItems.RESONANT_SIGIL.get());
                        output.accept(ModItems.SOULFIRE_SIGIL.get());
                        output.accept(ModItems.ECHO_ORB.get());
                        output.accept(ModItems.GLOWCAP_STEW.get());

                        // Weapons & Tools
                        output.accept(ModItems.SONIC_SCEPTER.get());
                        output.accept(ModItems.ABYSSAL_GREATSWORD.get());
                        output.accept(ModItems.SOULFIRE_STAFF.get());

                        output.accept(ModItems.ECHORITE_SWORD.get());
                        output.accept(ModItems.ECHORITE_PICKAXE.get());
                        output.accept(ModItems.ECHORITE_AXE.get());
                        output.accept(ModItems.ECHORITE_SHOVEL.get());
                        output.accept(ModItems.ECHORITE_HOE.get());

                        output.accept(ModItems.ECHORITE_HELMET.get());
                        output.accept(ModItems.ECHORITE_CHESTPLATE.get());
                        output.accept(ModItems.ECHORITE_LEGGINGS.get());
                        output.accept(ModItems.ECHORITE_BOOTS.get());

                        output.accept(ModItems.RESONITE_SWORD.get());
                        output.accept(ModItems.RESONITE_PICKAXE.get());
                        output.accept(ModItems.RESONITE_AXE.get());
                        output.accept(ModItems.RESONITE_SHOVEL.get());
                        output.accept(ModItems.RESONITE_HOE.get());

                        output.accept(ModItems.RESONITE_HELMET.get());
                        output.accept(ModItems.RESONITE_CHESTPLATE.get());
                        output.accept(ModItems.RESONITE_LEGGINGS.get());
                        output.accept(ModItems.RESONITE_BOOTS.get());

                        // Materials
                        output.accept(ModItems.RAW_ECHORITE.get());
                        output.accept(ModItems.ECHORITE_INGOT.get());
                        output.accept(ModItems.ECHORITE_NUGGET.get());
                        output.accept(ModItems.RESONITE_GEM.get());
                        output.accept(ModItems.SOULFIRE_DUST.get());
                        output.accept(ModItems.ECHO_CRYSTAL_SHARD.get());
                        output.accept(ModItems.STALKER_FANG.get());
                        output.accept(ModItems.GLOOM_SPORE.get());
                        output.accept(ModItems.WISP_ESSENCE.get());
                        output.accept(ModItems.COLOSSUS_CORE.get());
                        output.accept(ModItems.WRAITH_HEART.get());
                        output.accept(ModItems.RESONITE_UPGRADE_SMITHING_TEMPLATE.get());

                        // Blocks
                        output.accept(ModBlocks.ECHO_STONE.get());
                        output.accept(ModBlocks.COBBLED_ECHO_STONE.get());
                        output.accept(ModBlocks.POLISHED_ECHO_STONE.get());
                        output.accept(ModBlocks.ECHO_STONE_BRICKS.get());
                        output.accept(ModBlocks.CRACKED_ECHO_STONE_BRICKS.get());
                        output.accept(ModBlocks.CHISELED_ECHO_STONE_BRICKS.get());
                        output.accept(ModBlocks.ECHO_TILES.get());

                        output.accept(ModBlocks.ECHO_STONE_STAIRS.get());
                        output.accept(ModBlocks.ECHO_STONE_SLAB.get());
                        output.accept(ModBlocks.ECHO_STONE_WALL.get());
                        output.accept(ModBlocks.ECHO_BRICK_STAIRS.get());
                        output.accept(ModBlocks.ECHO_BRICK_SLAB.get());
                        output.accept(ModBlocks.ECHO_BRICK_WALL.get());

                        output.accept(ModBlocks.ECHO_SOIL.get());
                        output.accept(ModBlocks.ECHO_MOSS_BLOCK.get());
                        output.accept(ModBlocks.ECHO_GRASS.get());
                        output.accept(ModBlocks.GLOWCAP.get());

                        output.accept(ModBlocks.ECHORITE_ORE.get());
                        output.accept(ModBlocks.RESONITE_ORE.get());
                        output.accept(ModBlocks.SOULFIRE_ORE.get());
                        output.accept(ModBlocks.RAW_ECHORITE_BLOCK.get());
                        output.accept(ModBlocks.ECHORITE_BLOCK.get());
                        output.accept(ModBlocks.RESONITE_BLOCK.get());
                        output.accept(ModBlocks.ECHO_CRYSTAL_BLOCK.get());
                        output.accept(ModBlocks.ECHO_CRYSTAL_CLUSTER.get());

                        output.accept(ModBlocks.GLOOMWOOD_LOG.get());
                        output.accept(ModBlocks.STRIPPED_GLOOMWOOD_LOG.get());
                        output.accept(ModBlocks.GLOOMWOOD_WOOD.get());
                        output.accept(ModBlocks.STRIPPED_GLOOMWOOD_WOOD.get());
                        output.accept(ModBlocks.GLOOMWOOD_PLANKS.get());
                        output.accept(ModBlocks.GLOOMWOOD_STAIRS.get());
                        output.accept(ModBlocks.GLOOMWOOD_SLAB.get());
                        output.accept(ModBlocks.GLOOMWOOD_FENCE.get());
                        output.accept(ModBlocks.GLOOMWOOD_FENCE_GATE.get());
                        output.accept(ModBlocks.GLOOMWOOD_DOOR.get());
                        output.accept(ModBlocks.GLOOMWOOD_TRAPDOOR.get());
                        output.accept(ModBlocks.GLOOMWOOD_BUTTON.get());
                        output.accept(ModBlocks.GLOOMWOOD_PRESSURE_PLATE.get());
                        output.accept(ModBlocks.GLOOMWOOD_LEAVES.get());
                        output.accept(ModBlocks.GLOOMWOOD_SAPLING.get());

                        output.accept(ModBlocks.RESONANT_LAMP.get());
                        output.accept(ModBlocks.ECHO_GLASS.get());
                        output.accept(ModBlocks.ECHO_LANTERN.get());
                        output.accept(ModBlocks.RESONANT_ALTAR.get());

                        // Spawn Eggs
                        output.accept(ModItems.ECHO_STALKER_SPAWN_EGG.get());
                        output.accept(ModItems.SCULK_CRAWLER_SPAWN_EGG.get());
                        output.accept(ModItems.SOUL_WISP_SPAWN_EGG.get());
                        output.accept(ModItems.ECHO_COLOSSUS_SPAWN_EGG.get());
                        output.accept(ModItems.SOULFIRE_WRAITH_SPAWN_EGG.get());
                    })
                    .build());

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
