package com.davilucas.echoingdepths.block;

import com.davilucas.echoingdepths.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class GlowcapBlock extends BushBlock {
    public GlowcapBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        return state.is(ModBlocks.ECHO_SOIL.get()) ||
               state.is(ModBlocks.ECHO_MOSS_BLOCK.get()) ||
               state.is(Blocks.SCULK) ||
               state.is(Blocks.SOUL_SOIL) ||
               state.is(Blocks.SOUL_SAND) ||
               super.mayPlaceOn(state, level, pos);
    }
}
