package com.davilucas.echoingdepths.block;

import com.davilucas.echoingdepths.entity.boss.EchoColossusEntity;
import com.davilucas.echoingdepths.entity.boss.SoulfireWraithEntity;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModItems;
import com.davilucas.echoingdepths.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class ResonantAltarBlock extends Block {
    public ResonantAltarBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);

        if (held.is(ModItems.RESONANT_SIGIL.get())) {
            if (!level.isClientSide()) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }

                ServerLevel serverLevel = (ServerLevel) level;
                LightningBolt lightning = EntityType.LIGHTNING_BOLT.create(serverLevel);
                if (lightning != null) {
                    lightning.moveTo(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    lightning.setVisualOnly(true);
                    serverLevel.addFreshEntity(lightning);
                }

                EchoColossusEntity boss = ModEntities.ECHO_COLOSSUS.get().create(serverLevel);
                if (boss != null) {
                    boss.moveTo(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 0.0F, 0.0F);
                    serverLevel.addFreshEntity(boss);
                }

                level.playSound(null, pos, ModSounds.COLOSSUS_ROAR.get(), SoundSource.HOSTILE, 2.0F, 0.8F);
                player.sendSystemMessage(Component.translatable("message.echoingdepths.colossus_summoned"));
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
        }

        if (held.is(ModItems.SOULFIRE_SIGIL.get())) {
            if (!level.isClientSide()) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }

                ServerLevel serverLevel = (ServerLevel) level;
                SoulfireWraithEntity boss = ModEntities.SOULFIRE_WRAITH.get().create(serverLevel);
                if (boss != null) {
                    boss.moveTo(pos.getX() + 0.5, pos.getY() + 2.0, pos.getZ() + 0.5, 0.0F, 0.0F);
                    serverLevel.addFreshEntity(boss);
                }

                level.playSound(null, pos, ModSounds.WRAITH_SCREAM.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
                player.sendSystemMessage(Component.translatable("message.echoingdepths.wraith_summoned"));
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
        }

        return super.use(state, level, pos, player, hand, hit);
    }
}
