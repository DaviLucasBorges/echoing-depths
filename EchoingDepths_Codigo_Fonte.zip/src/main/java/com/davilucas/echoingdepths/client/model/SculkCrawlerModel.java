package com.davilucas.echoingdepths.client.model;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.SculkCrawlerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SculkCrawlerModel extends GeoModel<SculkCrawlerEntity> {
    @Override
    public ResourceLocation getModelResource(SculkCrawlerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "geo/sculk_crawler.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SculkCrawlerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "textures/entity/sculk_crawler.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SculkCrawlerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "animations/sculk_crawler.animation.json");
    }
}
