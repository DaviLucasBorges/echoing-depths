package com.davilucas.echoingdepths.client.renderer;

import com.davilucas.echoingdepths.client.model.EchoStalkerModel;
import com.davilucas.echoingdepths.entity.EchoStalkerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class EchoStalkerRenderer extends GeoEntityRenderer<EchoStalkerEntity> {
    public EchoStalkerRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new EchoStalkerModel());
        this.shadowRadius = 0.6F;
    }
}
