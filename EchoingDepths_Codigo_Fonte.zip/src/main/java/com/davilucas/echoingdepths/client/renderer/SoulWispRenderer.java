package com.davilucas.echoingdepths.client.renderer;

import com.davilucas.echoingdepths.client.model.SoulWispModel;
import com.davilucas.echoingdepths.entity.SoulWispEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SoulWispRenderer extends GeoEntityRenderer<SoulWispEntity> {
    public SoulWispRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new SoulWispModel());
        this.shadowRadius = 0.3F;
    }
}
