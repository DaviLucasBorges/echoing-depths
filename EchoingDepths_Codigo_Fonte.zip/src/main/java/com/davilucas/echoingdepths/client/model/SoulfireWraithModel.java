package com.davilucas.echoingdepths.client.model;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.boss.SoulfireWraithEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SoulfireWraithModel extends GeoModel<SoulfireWraithEntity> {
    @Override
    public ResourceLocation getModelResource(SoulfireWraithEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "geo/soulfire_wraith.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SoulfireWraithEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "textures/entity/soulfire_wraith.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SoulfireWraithEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "animations/soulfire_wraith.animation.json");
    }
}
