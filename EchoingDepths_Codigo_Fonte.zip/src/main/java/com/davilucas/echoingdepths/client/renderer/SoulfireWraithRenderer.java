package com.davilucas.echoingdepths.client.renderer;

import com.davilucas.echoingdepths.client.model.SoulfireWraithModel;
import com.davilucas.echoingdepths.entity.boss.SoulfireWraithEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SoulfireWraithRenderer extends GeoEntityRenderer<SoulfireWraithEntity> {
    public SoulfireWraithRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new SoulfireWraithModel());
        this.shadowRadius = 0.8F;
    }
}
