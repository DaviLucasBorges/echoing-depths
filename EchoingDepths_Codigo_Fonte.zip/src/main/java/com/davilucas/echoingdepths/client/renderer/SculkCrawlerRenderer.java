package com.davilucas.echoingdepths.client.renderer;

import com.davilucas.echoingdepths.client.model.SculkCrawlerModel;
import com.davilucas.echoingdepths.entity.SculkCrawlerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SculkCrawlerRenderer extends GeoEntityRenderer<SculkCrawlerEntity> {
    public SculkCrawlerRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new SculkCrawlerModel());
        this.shadowRadius = 0.5F;
    }
}
