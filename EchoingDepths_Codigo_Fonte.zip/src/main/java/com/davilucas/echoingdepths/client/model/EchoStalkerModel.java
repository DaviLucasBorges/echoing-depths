package com.davilucas.echoingdepths.client.model;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.EchoStalkerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class EchoStalkerModel extends GeoModel<EchoStalkerEntity> {
    @Override
    public ResourceLocation getModelResource(EchoStalkerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "geo/echo_stalker.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(EchoStalkerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "textures/entity/echo_stalker.png");
    }

    @Override
    public ResourceLocation getAnimationResource(EchoStalkerEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "animations/echo_stalker.animation.json");
    }
}
