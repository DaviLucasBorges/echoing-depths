package com.davilucas.echoingdepths.client.model;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.SoulWispEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SoulWispModel extends GeoModel<SoulWispEntity> {
    @Override
    public ResourceLocation getModelResource(SoulWispEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "geo/soul_wisp.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SoulWispEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "textures/entity/soul_wisp.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SoulWispEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "animations/soul_wisp.animation.json");
    }
}
