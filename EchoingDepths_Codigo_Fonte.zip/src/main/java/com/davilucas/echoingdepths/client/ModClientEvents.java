package com.davilucas.echoingdepths.client;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.client.renderer.*;
import com.davilucas.echoingdepths.init.ModBlocks;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModParticles;
import net.minecraft.client.particle.FlameParticle;
import net.minecraft.client.particle.PortalParticle;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = EchoingDepths.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModClientEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ECHO_STALKER.get(), EchoStalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.SCULK_CRAWLER.get(), SculkCrawlerRenderer::new);
        event.registerEntityRenderer(ModEntities.SOUL_WISP.get(), SoulWispRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_COLOSSUS.get(), EchoColossusRenderer::new);
        event.registerEntityRenderer(ModEntities.SOULFIRE_WRAITH.get(), SoulfireWraithRenderer::new);

        event.registerEntityRenderer(ModEntities.BLUE_FIREBALL.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.RESONANT_PULSE.get(), ThrownItemRenderer::new);
    }

    @SubscribeEvent
    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.ECHO_PORTAL.get(), PortalParticle.Provider::new);
        event.registerSpriteSet(ModParticles.SOUL_EMBER.get(), FlameParticle.Provider::new);
        event.registerSpriteSet(ModParticles.RESONANCE_SPARK.get(), PortalParticle.Provider::new);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.ECHO_PORTAL.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.ECHO_GLASS.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.GLOOMWOOD_DOOR.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.GLOOMWOOD_TRAPDOOR.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.GLOOMWOOD_SAPLING.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.GLOWCAP.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.ECHO_GRASS.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.ECHO_CRYSTAL_CLUSTER.get(), RenderType.cutout());
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.ECHO_LANTERN.get(), RenderType.cutout());
        });
    }
}
