package com.davilucas.echoingdepths.client.renderer;

import com.davilucas.echoingdepths.client.model.EchoColossusModel;
import com.davilucas.echoingdepths.entity.boss.EchoColossusEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class EchoColossusRenderer extends GeoEntityRenderer<EchoColossusEntity> {
    public EchoColossusRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new EchoColossusModel());
        this.shadowRadius = 1.4F;
    }
}
