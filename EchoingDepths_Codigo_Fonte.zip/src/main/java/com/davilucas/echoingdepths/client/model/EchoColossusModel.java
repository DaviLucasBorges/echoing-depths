package com.davilucas.echoingdepths.client.model;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.boss.EchoColossusEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class EchoColossusModel extends GeoModel<EchoColossusEntity> {
    @Override
    public ResourceLocation getModelResource(EchoColossusEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "geo/echo_colossus.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(EchoColossusEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "textures/entity/echo_colossus.png");
    }

    @Override
    public ResourceLocation getAnimationResource(EchoColossusEntity animatable) {
        return new ResourceLocation(EchoingDepths.MODID, "animations/echo_colossus.animation.json");
    }
}
