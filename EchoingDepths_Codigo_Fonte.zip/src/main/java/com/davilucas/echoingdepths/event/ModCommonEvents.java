package com.davilucas.echoingdepths.event;

import com.davilucas.echoingdepths.EchoingDepths;
import com.davilucas.echoingdepths.entity.EchoStalkerEntity;
import com.davilucas.echoingdepths.entity.SculkCrawlerEntity;
import com.davilucas.echoingdepths.entity.SoulWispEntity;
import com.davilucas.echoingdepths.entity.boss.EchoColossusEntity;
import com.davilucas.echoingdepths.entity.boss.SoulfireWraithEntity;
import com.davilucas.echoingdepths.init.ModEnchantments;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModItems;
import com.davilucas.echoingdepths.init.ModPotions;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.PotionBrewing;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
import net.minecraftforge.common.brewing.IBrewingRecipe;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod.EventBusSubscriber(modid = EchoingDepths.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ModCommonEvents {

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (event.getEntity() instanceof Warden warden) {
            // 5% chance to drop Blue Fireball from Warden
            if (warden.getRandom().nextFloat() < 0.05F) {
                ItemEntity drop = new ItemEntity(warden.level(),
                        warden.getX(), warden.getY() + 0.5, warden.getZ(),
                        new ItemStack(ModItems.BLUE_FIREBALL.get()));
                event.getDrops().add(drop);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getSource().getEntity() instanceof LivingEntity attacker) {
            int sonicLvl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.SONIC_STRIKE.get(), attacker.getMainHandItem());
            if (sonicLvl > 0) {
                event.setAmount(event.getAmount() + (sonicLvl * 1.5F));
                event.getEntity().knockback(0.4D * sonicLvl, attacker.getX() - event.getEntity().getX(), attacker.getZ() - event.getEntity().getZ());
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof Player player) {
            int siphonLvl = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.SOUL_SIPHON.get(), player.getMainHandItem());
            if (siphonLvl > 0) {
                player.heal(1.5F * siphonLvl);
            }
        }
    }

    @Mod.EventBusSubscriber(modid = EchoingDepths.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusEvents {
        @SubscribeEvent
        public static void registerAttributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.ECHO_STALKER.get(), EchoStalkerEntity.createAttributes().build());
            event.put(ModEntities.SCULK_CRAWLER.get(), SculkCrawlerEntity.createAttributes().build());
            event.put(ModEntities.SOUL_WISP.get(), SoulWispEntity.createAttributes().build());
            event.put(ModEntities.ECHO_COLOSSUS.get(), EchoColossusEntity.createAttributes().build());
            event.put(ModEntities.SOULFIRE_WRAITH.get(), SoulfireWraithEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void commonSetup(FMLCommonSetupEvent event) {
            event.enqueueWork(() -> {
                // Register brewing recipes
                BrewingRecipeRegistry.addRecipe(new SimpleBrewingRecipe(Potions.AWKWARD, ModItems.GLOOM_SPORE.get(), ModPotions.ECHO_SIGHT.get()));
                BrewingRecipeRegistry.addRecipe(new SimpleBrewingRecipe(ModPotions.ECHO_SIGHT.get(), net.minecraft.world.item.Items.REDSTONE, ModPotions.LONG_ECHO_SIGHT.get()));
                BrewingRecipeRegistry.addRecipe(new SimpleBrewingRecipe(Potions.AWKWARD, ModItems.SOULFIRE_DUST.get(), ModPotions.SOUL_BURN.get()));
                BrewingRecipeRegistry.addRecipe(new SimpleBrewingRecipe(Potions.AWKWARD, ModItems.RESONITE_GEM.get(), ModPotions.RESONANCE.get()));
                BrewingRecipeRegistry.addRecipe(new SimpleBrewingRecipe(Potions.AWKWARD, ModItems.STALKER_FANG.get(), ModPotions.SCULK_WARD.get()));
            });
        }
    }

    public static class SimpleBrewingRecipe implements IBrewingRecipe {
        private final net.minecraft.world.item.alchemy.Potion input;
        private final net.minecraft.world.item.Item ingredient;
        private final net.minecraft.world.item.alchemy.Potion output;

        public SimpleBrewingRecipe(net.minecraft.world.item.alchemy.Potion input, net.minecraft.world.item.Item ingredient, net.minecraft.world.item.alchemy.Potion output) {
            this.input = input;
            this.ingredient = ingredient;
            this.output = output;
        }

        @Override
        public boolean isInput(ItemStack input) {
            return net.minecraft.world.item.alchemy.PotionUtils.getPotion(input) == this.input;
        }

        @Override
        public boolean isIngredient(ItemStack ingredient) {
            return ingredient.is(this.ingredient);
        }

        @Override
        public ItemStack getOutput(ItemStack input, ItemStack ingredient) {
            if (isInput(input) && isIngredient(ingredient)) {
                return net.minecraft.world.item.alchemy.PotionUtils.setPotion(new ItemStack(input.getItem()), this.output);
            }
            return ItemStack.EMPTY;
        }
    }
}
