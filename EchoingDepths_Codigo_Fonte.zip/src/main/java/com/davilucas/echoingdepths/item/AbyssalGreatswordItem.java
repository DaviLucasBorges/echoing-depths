package com.davilucas.echoingdepths.item;

import com.davilucas.echoingdepths.init.ModEffects;
import com.davilucas.echoingdepths.init.ModParticles;
import com.davilucas.echoingdepths.init.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class AbyssalGreatswordItem extends SwordItem {
    public AbyssalGreatswordItem(Tier tier, int attackDamageModifier, float attackSpeedModifier, Properties properties) {
        super(tier, attackDamageModifier, attackSpeedModifier, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(ModEffects.RESONANCE.get(), 100, 1));

        if (attacker instanceof Player player && !attacker.level().isClientSide()) {
            ServerLevel serverLevel = (ServerLevel) attacker.level();
            serverLevel.playSound(null, target.getX(), target.getY(), target.getZ(),
                    ModSounds.SONIC_PULSE.get(), SoundSource.PLAYERS, 1.0F, 1.4F);

            // Emit resonant burst
            serverLevel.sendParticles(ModParticles.RESONANCE_SPARK.get(),
                    target.getX(), target.getY() + 1.0, target.getZ(),
                    20, 0.6, 0.6, 0.6, 0.1);

            // AOE damage to surrounding hostile mobs
            AABB area = target.getBoundingBox().inflate(3.5);
            List<LivingEntity> enemies = serverLevel.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != player && e != target && e.isAlive() && !player.isAlliedTo(e));

            for (LivingEntity enemy : enemies) {
                enemy.hurt(attacker.damageSources().sonicBoom(player), 6.0F);
                enemy.addEffect(new MobEffectInstance(ModEffects.RESONANCE.get(), 60, 0));
            }
        }

        return super.hurtEnemy(stack, target, attacker);
    }
}
