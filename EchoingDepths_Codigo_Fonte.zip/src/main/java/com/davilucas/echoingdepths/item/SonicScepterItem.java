package com.davilucas.echoingdepths.item;

import com.davilucas.echoingdepths.entity.projectile.ResonantPulseProjectile;
import com.davilucas.echoingdepths.init.ModSounds;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SonicScepterItem extends Item {
    public SonicScepterItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.SONIC_PULSE.get(), SoundSource.PLAYERS, 1.2F, 1.0F);

        if (!level.isClientSide()) {
            ResonantPulseProjectile pulse = new ResonantPulseProjectile(level, player);
            pulse.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 2.2F, 0.5F);
            level.addFreshEntity(pulse);
        }

        player.getCooldowns().addCooldown(this, 25);
        stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
