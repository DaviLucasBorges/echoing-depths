package com.davilucas.echoingdepths.item;

import com.davilucas.echoingdepths.entity.projectile.BlueFireballProjectile;
import com.davilucas.echoingdepths.init.ModParticles;
import com.davilucas.echoingdepths.init.ModSounds;
import com.davilucas.echoingdepths.worldgen.portal.EchoPortalShape;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public class BlueFireballItem extends Item {
    public BlueFireballItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos clickedPos = context.getClickedPos();
        Direction clickedFace = context.getClickedFace();
        BlockPos targetPos = clickedPos.relative(clickedFace);

        // Try activating portal at clicked position and adjacent position
        boolean activated = false;
        if (level.getBlockState(clickedPos).is(Blocks.REINFORCED_DEEPSLATE)) {
            activated = EchoPortalShape.trySpawnPortal(level, targetPos);
        } else {
            activated = EchoPortalShape.trySpawnPortal(level, clickedPos) || EchoPortalShape.trySpawnPortal(level, targetPos);
        }

        if (activated) {
            level.playSound(context.getPlayer(), clickedPos, ModSounds.PORTAL_IGNITE.get(), SoundSource.BLOCKS, 1.2F, 1.0F);

            if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
        }

        return super.useOn(context);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.SOUL_FIREBALL.get(), SoundSource.PLAYERS, 1.0F, 1.2F);

        if (!level.isClientSide()) {
            BlueFireballProjectile fireball = new BlueFireballProjectile(level, player);
            fireball.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.6F, 1.0F);
            level.addFreshEntity(fireball);
        }

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
