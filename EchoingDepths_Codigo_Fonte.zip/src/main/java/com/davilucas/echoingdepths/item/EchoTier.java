package com.davilucas.echoingdepths.item;

import com.davilucas.echoingdepths.init.ModItems;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public enum EchoTier implements Tier {
    ECHORITE(3, 1400, 7.5F, 2.5F, 16, () -> Ingredient.of(ModItems.ECHORITE_INGOT.get())),
    RESONITE(4, 2500, 10.0F, 4.0F, 22, () -> Ingredient.of(ModItems.RESONITE_GEM.get()));

    private final int level;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantmentValue;
    private final java.util.function.Supplier<Ingredient> repairIngredient;

    EchoTier(int level, int uses, float speed, float damage, int enchantmentValue, java.util.function.Supplier<Ingredient> repairIngredient) {
        this.level = level;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantmentValue = enchantmentValue;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getUses() {
        return this.uses;
    }

    @Override
    public float getSpeed() {
        return this.speed;
    }

    @Override
    public float getAttackDamageBonus() {
        return this.damage;
    }

    @Override
    public int getLevel() {
        return this.level;
    }

    @Override
    public int getEnchantmentValue() {
        return this.enchantmentValue;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }
}
