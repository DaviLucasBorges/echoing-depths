package com.davilucas.echoingdepths.item;

import com.davilucas.echoingdepths.init.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ModArmorItem extends ArmorItem {
    public ModArmorItem(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        if (!level.isClientSide() && entity instanceof Player player && hasFullArmorSet(player)) {
            evaluateArmorEffects(player);
        }
        super.inventoryTick(stack, level, entity, slotId, isSelected);
    }

    private boolean hasFullArmorSet(Player player) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() == EquipmentSlot.Type.ARMOR) {
                ItemStack item = player.getItemBySlot(slot);
                if (item.isEmpty() || !(item.getItem() instanceof ArmorItem)) {
                    return false;
                }
            }
        }
        return true;
    }

    private void evaluateArmorEffects(Player player) {
        ArmorItem boot = (ArmorItem) player.getItemBySlot(EquipmentSlot.FEET).getItem();
        ArmorItem legs = (ArmorItem) player.getItemBySlot(EquipmentSlot.LEGS).getItem();
        ArmorItem chest = (ArmorItem) player.getItemBySlot(EquipmentSlot.CHEST).getItem();
        ArmorItem helmet = (ArmorItem) player.getItemBySlot(EquipmentSlot.HEAD).getItem();

        ArmorMaterial mat = boot.getMaterial();
        if (legs.getMaterial() == mat && chest.getMaterial() == mat && helmet.getMaterial() == mat) {
            if (mat == ModArmorMaterials.ECHORITE) {
                if (player.hasEffect(MobEffects.DARKNESS)) {
                    player.removeEffect(MobEffects.DARKNESS);
                }
                player.addEffect(new MobEffectInstance(ModEffects.SCULK_WARD.get(), 40, 0, false, false, true));
            } else if (mat == ModArmorMaterials.RESONITE) {
                if (player.hasEffect(MobEffects.DARKNESS)) {
                    player.removeEffect(MobEffects.DARKNESS);
                }
                if (player.hasEffect(MobEffects.BLINDNESS)) {
                    player.removeEffect(MobEffects.BLINDNESS);
                }
                player.addEffect(new MobEffectInstance(ModEffects.ECHO_SIGHT.get(), 40, 0, false, false, true));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 0, false, false, true));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false, true));
            }
        }
    }
}
