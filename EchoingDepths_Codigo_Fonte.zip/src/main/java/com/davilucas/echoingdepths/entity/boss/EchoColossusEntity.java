package com.davilucas.echoingdepths.entity.boss;

import com.davilucas.echoingdepths.entity.SculkCrawlerEntity;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModParticles;
import com.davilucas.echoingdepths.init.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

public class EchoColossusEntity extends Monster implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = (ServerBossEvent) (new ServerBossEvent(
            Component.translatable("entity.echoingdepths.echo_colossus"),
            BossEvent.BossBarColor.BLUE,
            BossEvent.BossBarOverlay.NOTCHED_10)).setDarkenScreen(true);

    private static final RawAnimation IDLE_ANIM = RawAnimation.begin().thenLoop("animation.echo_colossus.idle");
    private static final RawAnimation WALK_ANIM = RawAnimation.begin().thenLoop("animation.echo_colossus.walk");
    private static final RawAnimation SLAM_ANIM = RawAnimation.begin().thenPlay("animation.echo_colossus.slam");

    private int slamCooldown = 60;
    private boolean didSummonMinions = false;

    public EchoColossusEntity(EntityType<? extends Monster> entityType, Level level) {
        super(entityType, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 350.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 16.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        if (!this.level().isClientSide()) {
            if (this.slamCooldown > 0) {
                this.slamCooldown--;
            }

            LivingEntity target = this.getTarget();
            if (target != null && this.slamCooldown <= 0 && this.distanceToSqr(target) < 40.0D) {
                performSeismicSlam();
                this.slamCooldown = 120;
            }

            if (!this.didSummonMinions && this.getHealth() < this.getMaxHealth() * 0.5F) {
                this.didSummonMinions = true;
                summonMinions();
            }
        }
    }

    private void performSeismicSlam() {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.COLOSSUS_SLAM.get(), SoundSource.HOSTILE, 2.5F, 0.8F);

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ModParticles.RESONANCE_SPARK.get(),
                    this.getX(), this.getY() + 0.2, this.getZ(),
                    60, 2.0, 0.2, 2.0, 0.15);

            AABB area = this.getBoundingBox().inflate(6.0, 2.0, 6.0);
            List<LivingEntity> enemies = serverLevel.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e != this && e.isAlive() && !(e instanceof SculkCrawlerEntity));

            for (LivingEntity enemy : enemies) {
                enemy.hurt(this.damageSources().mobAttack(this), 14.0F);
                enemy.knockback(1.8, this.getX() - enemy.getX(), this.getZ() - enemy.getZ());
            }
        }
    }

    private void summonMinions() {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                ModSounds.COLOSSUS_ROAR.get(), SoundSource.HOSTILE, 3.0F, 0.8F);

        if (this.level() instanceof ServerLevel serverLevel) {
            for (int i = 0; i < 3; i++) {
                SculkCrawlerEntity crawler = ModEntities.SCULK_CRAWLER.get().create(serverLevel);
                if (crawler != null) {
                    crawler.moveTo(this.getX() + (i - 1) * 2.0, this.getY(), this.getZ() + (i % 2) * 2.0, 0, 0);
                    serverLevel.addFreshEntity(crawler);
                }
            }
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getDisplayName());
        }
        this.didSummonMinions = tag.getBoolean("DidSummonMinions");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("DidSummonMinions", this.didSummonMinions);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 5, state -> {
            if (this.slamCooldown > 100) {
                return state.setAndContinue(SLAM_ANIM);
            }
            if (state.isMoving()) {
                return state.setAndContinue(WALK_ANIM);
            }
            return state.setAndContinue(IDLE_ANIM);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
