package com.davilucas.echoingdepths.entity.boss;

import com.davilucas.echoingdepths.entity.projectile.BlueFireballProjectile;
import com.davilucas.echoingdepths.init.ModParticles;
import com.davilucas.echoingdepths.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.FlyingMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;

public class SoulfireWraithEntity extends FlyingMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = (ServerBossEvent) (new ServerBossEvent(
            Component.translatable("entity.echoingdepths.soulfire_wraith"),
            BossEvent.BossBarColor.PURPLE,
            BossEvent.BossBarOverlay.NOTCHED_10)).setDarkenScreen(true);

    private static final RawAnimation IDLE_ANIM = RawAnimation.begin().thenLoop("animation.soulfire_wraith.idle");
    private static final RawAnimation CAST_ANIM = RawAnimation.begin().thenPlay("animation.soulfire_wraith.cast");

    private int attackTimer = 0;

    public SoulfireWraithEntity(EntityType<? extends FlyingMob> entityType, Level level) {
        super(entityType, level);
        this.moveControl = new FlyingMoveControl(this, 15, true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.FLYING_SPEED, 0.35D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new WraithAttackGoal(this));
        this.goalSelector.addGoal(2, new WraithHoverGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        if (this.level().isClientSide()) {
            this.level().addParticle(ModParticles.SOUL_EMBER.get(),
                    this.getX() + (this.random.nextDouble() - 0.5),
                    this.getY() + this.random.nextDouble() * 2.0,
                    this.getZ() + (this.random.nextDouble() - 0.5),
                    0.0, 0.05, 0.0);
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getDisplayName());
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 5, state -> {
            if (this.attackTimer > 0) {
                return state.setAndContinue(CAST_ANIM);
            }
            return state.setAndContinue(IDLE_ANIM);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    static class WraithAttackGoal extends Goal {
        private final SoulfireWraithEntity wraith;
        private int shootCooldown = 30;

        public WraithAttackGoal(SoulfireWraithEntity wraith) {
            this.wraith = wraith;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return this.wraith.getTarget() != null && this.wraith.getTarget().isAlive();
        }

        @Override
        public void tick() {
            LivingEntity target = this.wraith.getTarget();
            if (target == null) return;

            this.wraith.getLookControl().setLookAt(target, 30.0F, 30.0F);

            double distSq = this.wraith.distanceToSqr(target);
            if (distSq < 900.0D) {
                this.shootCooldown--;
                if (this.shootCooldown <= 0) {
                    this.shootCooldown = 40;
                    this.wraith.attackTimer = 15;

                    this.wraith.level().playSound(null, this.wraith.getX(), this.wraith.getY(), this.wraith.getZ(),
                            ModSounds.SOUL_FIREBALL.get(), SoundSource.HOSTILE, 2.0F, 1.0F);

                    if (!this.wraith.level().isClientSide()) {
                        Vec3 view = this.wraith.getViewVector(1.0F);
                        BlueFireballProjectile fireball = new BlueFireballProjectile(this.wraith.level(), this.wraith);
                        fireball.setPos(this.wraith.getX() + view.x * 1.5, this.wraith.getY() + 1.2, this.wraith.getZ() + view.z * 1.5);
                        fireball.shoot(view.x, view.y, view.z, 1.4F, 1.0F);
                        this.wraith.level().addFreshEntity(fireball);
                    }
                }
            }
        }
    }

    static class WraithHoverGoal extends Goal {
        private final SoulfireWraithEntity wraith;

        public WraithHoverGoal(SoulfireWraithEntity wraith) {
            this.wraith = wraith;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return !this.wraith.getMoveControl().hasWanted() && this.wraith.random.nextInt(5) == 0;
        }

        @Override
        public void start() {
            RandomSource r = this.wraith.getRandom();
            double x = this.wraith.getX() + (r.nextFloat() * 2.0F - 1.0F) * 12.0F;
            double y = Math.max(30.0, this.wraith.getY() + (r.nextFloat() * 2.0F - 1.0F) * 6.0F);
            double z = this.wraith.getZ() + (r.nextFloat() * 2.0F - 1.0F) * 12.0F;
            this.wraith.getMoveControl().setWantedPosition(x, y, z, 0.7D);
        }
    }
}
