package com.davilucas.echoingdepths.entity.projectile;

import com.davilucas.echoingdepths.init.ModEffects;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModItems;
import com.davilucas.echoingdepths.init.ModParticles;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

public class BlueFireballProjectile extends ThrowableItemProjectile {
    public BlueFireballProjectile(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public BlueFireballProjectile(Level level, LivingEntity shooter) {
        super(ModEntities.BLUE_FIREBALL.get(), shooter, level);
    }

    public BlueFireballProjectile(Level level, double x, double y, double z) {
        super(ModEntities.BLUE_FIREBALL.get(), x, y, z, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.BLUE_FIREBALL.get();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            this.level().addParticle(ModParticles.SOUL_EMBER.get(),
                    this.getX(), this.getY(), this.getZ(),
                    0.0D, 0.05D, 0.0D);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        Entity owner = this.getOwner();

        if (target instanceof LivingEntity living) {
            living.hurt(this.damageSources().indirectMagic(this, owner), 9.0F);
            living.setSecondsOnFire(5);
            living.addEffect(new MobEffectInstance(ModEffects.SOUL_BURN.get(), 100, 1));
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }
}
