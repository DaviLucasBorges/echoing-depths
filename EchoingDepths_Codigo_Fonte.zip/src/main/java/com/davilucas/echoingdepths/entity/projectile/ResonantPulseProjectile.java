package com.davilucas.echoingdepths.entity.projectile;

import com.davilucas.echoingdepths.init.ModEffects;
import com.davilucas.echoingdepths.init.ModEntities;
import com.davilucas.echoingdepths.init.ModItems;
import com.davilucas.echoingdepths.init.ModParticles;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

public class ResonantPulseProjectile extends ThrowableItemProjectile {
    public ResonantPulseProjectile(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public ResonantPulseProjectile(Level level, LivingEntity shooter) {
        super(ModEntities.RESONANT_PULSE.get(), shooter, level);
    }

    public ResonantPulseProjectile(Level level, double x, double y, double z) {
        super(ModEntities.RESONANT_PULSE.get(), x, y, z, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.ECHO_ORB.get();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            this.level().addParticle(ModParticles.RESONANCE_SPARK.get(),
                    this.getX(), this.getY(), this.getZ(),
                    0.0D, 0.0D, 0.0D);
        }

        if (this.tickCount > 40 && !this.level().isClientSide()) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        Entity owner = this.getOwner();

        if (target instanceof LivingEntity living) {
            living.hurt(this.damageSources().sonicBoom(owner != null ? owner : this), 12.0F);
            living.knockback(1.5, -this.getDeltaMovement().x, -this.getDeltaMovement().z);
            living.addEffect(new MobEffectInstance(ModEffects.RESONANCE.get(), 80, 1));
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }
}
