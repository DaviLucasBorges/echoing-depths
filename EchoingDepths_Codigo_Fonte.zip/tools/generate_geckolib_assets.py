"""
Generates GeckoLib 4 geometry (.geo.json) and animation (.animation.json) files for all 5 entities:
1. echo_stalker
2. sculk_crawler
3. soul_wisp
4. echo_colossus
5. soulfire_wraith
"""
import os
import json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO = os.path.join(ROOT, "src", "main", "resources", "assets", "echoingdepths", "geo")
ANIM = os.path.join(ROOT, "src", "main", "resources", "assets", "echoingdepths", "animations")
os.makedirs(GEO, exist_ok=True)
os.makedirs(ANIM, exist_ok=True)

# -----------------------------------------------------------------------------
# 1. Echo Stalker (quadruped predator, stalking gait, leaps)
# -----------------------------------------------------------------------------
stalker_geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.echo_stalker",
            "texture_width": 64,
            "texture_height": 64,
            "visible_bounds_width": 3,
            "visible_bounds_height": 2,
            "visible_bounds_offset": [0, 1, 0]
        },
        "bones": [
            {"name": "root", "pivot": [0, 0, 0]},
            {"name": "body", "parent": "root", "pivot": [0, 12, 0], "cubes": [
                {"origin": [-4, 8, -8], "size": [8, 8, 16], "uv": [16, 16]}
            ]},
            {"name": "head", "parent": "body", "pivot": [0, 14, -8], "cubes": [
                {"origin": [-3.5, 11, -15], "size": [7, 6, 7], "uv": [0, 0]},
                {"origin": [-2.5, 17, -13], "size": [2, 3, 1], "uv": [0, 13]}, # ear L
                {"origin": [0.5, 17, -13], "size": [2, 3, 1], "uv": [6, 13]}   # ear R
            ]},
            {"name": "leg_front_left", "parent": "root", "pivot": [3.5, 12, -5], "cubes": [
                {"origin": [2, 0, -6.5], "size": [3, 12, 3], "uv": [0, 16]}
            ]},
            {"name": "leg_front_right", "parent": "root", "pivot": [-3.5, 12, -5], "cubes": [
                {"origin": [-5, 0, -6.5], "size": [3, 12, 3], "uv": [0, 16]}
            ]},
            {"name": "leg_back_left", "parent": "root", "pivot": [3.5, 12, 5], "cubes": [
                {"origin": [2, 0, 3.5], "size": [3, 12, 3], "uv": [48, 16]}
            ]},
            {"name": "leg_back_right", "parent": "root", "pivot": [-3.5, 12, 5], "cubes": [
                {"origin": [-5, 0, 3.5], "size": [3, 12, 3], "uv": [48, 16]}
            ]},
            {"name": "tail", "parent": "body", "pivot": [0, 14, 8], "cubes": [
                {"origin": [-1, 10, 8], "size": [2, 2, 10], "uv": [24, 36]}
            ]}
        ]
    }]
}

stalker_anim = {
    "format_version": "1.8.0",
    "animations": {
        "animation.echo_stalker.idle": {
            "loop": True,
            "animation_length": 2.0,
            "bones": {
                "body": {"position": {"0.0": [0, 0, 0], "1.0": [0, -0.5, 0], "2.0": [0, 0, 0]}},
                "head": {"rotation": {"0.0": [0, 0, 0], "1.0": [2, 0, 0], "2.0": [0, 0, 0]}},
                "tail": {"rotation": {"0.0": [-10, 0, 0], "0.5": [-10, 8, 0], "1.5": [-10, -8, 0], "2.0": [-10, 0, 0]}}
            }
        },
        "animation.echo_stalker.walk": {
            "loop": True,
            "animation_length": 0.8,
            "bones": {
                "leg_front_left": {"rotation": {"0.0": [-25, 0, 0], "0.4": [25, 0, 0], "0.8": [-25, 0, 0]}},
                "leg_front_right": {"rotation": {"0.0": [25, 0, 0], "0.4": [-25, 0, 0], "0.8": [25, 0, 0]}},
                "leg_back_left": {"rotation": {"0.0": [25, 0, 0], "0.4": [-25, 0, 0], "0.8": [25, 0, 0]}},
                "leg_back_right": {"rotation": {"0.0": [-25, 0, 0], "0.4": [25, 0, 0], "0.8": [-25, 0, 0]}},
                "tail": {"rotation": {"0.0": [-5, 12, 0], "0.4": [-5, -12, 0], "0.8": [-5, 12, 0]}}
            }
        },
        "animation.echo_stalker.attack": {
            "animation_length": 0.5,
            "bones": {
                "head": {"rotation": {"0.0": [-20, 0, 0], "0.2": [30, 0, 0], "0.5": [0, 0, 0]}},
                "body": {"rotation": {"0.0": [10, 0, 0], "0.2": [-25, 0, 0], "0.5": [0, 0, 0]}}
            }
        }
    }
}

# -----------------------------------------------------------------------------
# 2. Sculk Crawler (spider-insectoid crawler)
# -----------------------------------------------------------------------------
crawler_geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.sculk_crawler",
            "texture_width": 64,
            "texture_height": 64,
            "visible_bounds_width": 2.5,
            "visible_bounds_height": 1.5,
            "visible_bounds_offset": [0, 0.75, 0]
        },
        "bones": [
            {"name": "root", "pivot": [0, 0, 0]},
            {"name": "head", "parent": "root", "pivot": [0, 6, -3], "cubes": [
                {"origin": [-3, 3, -8], "size": [6, 5, 5], "uv": [0, 0]}
            ]},
            {"name": "body", "parent": "root", "pivot": [0, 6, 0], "cubes": [
                {"origin": [-4, 2, -3], "size": [8, 6, 10], "uv": [0, 32]}
            ]},
            {"name": "leg1", "parent": "root", "pivot": [4, 5, -2], "cubes": [
                {"origin": [4, 3, -3], "size": [8, 2, 2], "uv": [32, 0]}
            ]},
            {"name": "leg2", "parent": "root", "pivot": [-4, 5, -2], "cubes": [
                {"origin": [-12, 3, -3], "size": [8, 2, 2], "uv": [32, 0]}
            ]},
            {"name": "leg3", "parent": "root", "pivot": [4, 5, 1], "cubes": [
                {"origin": [4, 3, 0], "size": [8, 2, 2], "uv": [32, 8]}
            ]},
            {"name": "leg4", "parent": "root", "pivot": [-4, 5, 1], "cubes": [
                {"origin": [-12, 3, 0], "size": [8, 2, 2], "uv": [32, 8]}
            ]},
            {"name": "leg5", "parent": "root", "pivot": [4, 5, 4], "cubes": [
                {"origin": [4, 3, 3], "size": [8, 2, 2], "uv": [32, 16]}
            ]},
            {"name": "leg6", "parent": "root", "pivot": [-4, 5, 4], "cubes": [
                {"origin": [-12, 3, 3], "size": [8, 2, 2], "uv": [32, 16]}
            ]}
        ]
    }]
}

crawler_anim = {
    "format_version": "1.8.0",
    "animations": {
        "animation.sculk_crawler.idle": {
            "loop": True,
            "animation_length": 1.5,
            "bones": {
                "body": {"position": {"0.0": [0, 0, 0], "0.75": [0, -0.3, 0], "1.5": [0, 0, 0]}},
                "head": {"rotation": {"0.0": [0, 0, 0], "0.75": [2, 0, 0], "1.5": [0, 0, 0]}}
            }
        },
        "animation.sculk_crawler.walk": {
            "loop": True,
            "animation_length": 0.5,
            "bones": {
                "leg1": {"rotation": {"0.0": [0, 15, -10], "0.25": [0, -15, 10], "0.5": [0, 15, -10]}},
                "leg2": {"rotation": {"0.0": [0, -15, 10], "0.25": [0, 15, -10], "0.5": [0, -15, 10]}},
                "leg3": {"rotation": {"0.0": [0, -15, 10], "0.25": [0, 15, -10], "0.5": [0, -15, 10]}},
                "leg4": {"rotation": {"0.0": [0, 15, -10], "0.25": [0, -15, 10], "0.5": [0, 15, -10]}},
                "leg5": {"rotation": {"0.0": [0, 15, -10], "0.25": [0, -15, 10], "0.5": [0, 15, -10]}},
                "leg6": {"rotation": {"0.0": [0, -15, 10], "0.25": [0, 15, -10], "0.5": [0, -15, 10]}}
            }
        }
    }
}

# -----------------------------------------------------------------------------
# 3. Soul Wisp (floating ethereal spirit orb)
# -----------------------------------------------------------------------------
wisp_geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.soul_wisp",
            "texture_width": 32,
            "texture_height": 32,
            "visible_bounds_width": 1.5,
            "visible_bounds_height": 1.5,
            "visible_bounds_offset": [0, 0.75, 0]
        },
        "bones": [
            {"name": "root", "pivot": [0, 8, 0], "cubes": [
                {"origin": [-3, 5, -3], "size": [6, 6, 6], "uv": [0, 0]}
            ]},
            {"name": "outer_shell", "parent": "root", "pivot": [0, 8, 0], "cubes": [
                {"origin": [-4, 4, -4], "size": [8, 8, 8], "uv": [0, 16], "inflate": 0.2}
            ]}
        ]
    }]
}

wisp_anim = {
    "format_version": "1.8.0",
    "animations": {
        "animation.soul_wisp.idle": {
            "loop": True,
            "animation_length": 2.0,
            "bones": {
                "root": {
                    "position": {"0.0": [0, 0, 0], "1.0": [0, 2.5, 0], "2.0": [0, 0, 0]},
                    "rotation": {"0.0": [0, 0, 0], "1.0": [0, 180, 0], "2.0": [0, 360, 0]}
                },
                "outer_shell": {
                    "scale": {"0.0": [1, 1, 1], "1.0": [1.15, 1.15, 1.15], "2.0": [1, 1, 1]}
                }
            }
        }
    }
}

# -----------------------------------------------------------------------------
# 4. Echo Colossus (Giant Boss)
# -----------------------------------------------------------------------------
colossus_geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.echo_colossus",
            "texture_width": 128,
            "texture_height": 128,
            "visible_bounds_width": 5,
            "visible_bounds_height": 5,
            "visible_bounds_offset": [0, 2.5, 0]
        },
        "bones": [
            {"name": "root", "pivot": [0, 0, 0]},
            {"name": "waist", "parent": "root", "pivot": [0, 18, 0], "cubes": [
                {"origin": [-8, 14, -5], "size": [16, 8, 10], "uv": [0, 64]}
            ]},
            {"name": "torso", "parent": "waist", "pivot": [0, 22, 0], "cubes": [
                {"origin": [-12, 22, -7], "size": [24, 18, 14], "uv": [64, 0]}
            ]},
            {"name": "head", "parent": "torso", "pivot": [0, 40, 0], "cubes": [
                {"origin": [-7, 40, -6], "size": [14, 12, 12], "uv": [0, 0]},
                {"origin": [-14, 46, -1], "size": [7, 6, 2], "uv": [0, 24]}, # horn L
                {"origin": [7, 46, -1], "size": [7, 6, 2], "uv": [18, 24]}   # horn R
            ]},
            {"name": "arm_left", "parent": "torso", "pivot": [15, 36, 0], "cubes": [
                {"origin": [12, 8, -5], "size": [8, 30, 10], "uv": [64, 64]}
            ]},
            {"name": "arm_right", "parent": "torso", "pivot": [-15, 36, 0], "cubes": [
                {"origin": [-20, 8, -5], "size": [8, 30, 10], "uv": [64, 64]}
            ]},
            {"name": "leg_left", "parent": "root", "pivot": [5, 14, 0], "cubes": [
                {"origin": [2, 0, -4], "size": [6, 14, 8], "uv": [0, 82]}
            ]},
            {"name": "leg_right", "parent": "root", "pivot": [-5, 14, 0], "cubes": [
                {"origin": [-8, 0, -4], "size": [6, 14, 8], "uv": [0, 82]}
            ]}
        ]
    }]
}

colossus_anim = {
    "format_version": "1.8.0",
    "animations": {
        "animation.echo_colossus.idle": {
            "loop": True,
            "animation_length": 2.5,
            "bones": {
                "torso": {"position": {"0.0": [0, 0, 0], "1.25": [0, -1, 0], "2.5": [0, 0, 0]}},
                "head": {"rotation": {"0.0": [0, 0, 0], "1.25": [3, 0, 0], "2.5": [0, 0, 0]}},
                "arm_left": {"rotation": {"0.0": [0, 0, 5], "1.25": [0, 0, 8], "2.5": [0, 0, 5]}},
                "arm_right": {"rotation": {"0.0": [0, 0, -5], "1.25": [0, 0, -8], "2.5": [0, 0, -5]}}
            }
        },
        "animation.echo_colossus.walk": {
            "loop": True,
            "animation_length": 1.4,
            "bones": {
                "leg_left": {"rotation": {"0.0": [-20, 0, 0], "0.7": [20, 0, 0], "1.4": [-20, 0, 0]}},
                "leg_right": {"rotation": {"0.0": [20, 0, 0], "0.7": [-20, 0, 0], "1.4": [20, 0, 0]}},
                "arm_left": {"rotation": {"0.0": [25, 0, 0], "0.7": [-25, 0, 0], "1.4": [25, 0, 0]}},
                "arm_right": {"rotation": {"0.0": [-25, 0, 0], "0.7": [25, 0, 0], "1.4": [-25, 0, 0]}}
            }
        },
        "animation.echo_colossus.slam": {
            "animation_length": 1.2,
            "bones": {
                "torso": {"rotation": {"0.0": [0, 0, 0], "0.5": [-30, 0, 0], "0.8": [20, 0, 0], "1.2": [0, 0, 0]}},
                "arm_left": {"rotation": {"0.0": [0, 0, 0], "0.5": [-120, 0, 0], "0.8": [30, 0, 0], "1.2": [0, 0, 0]}},
                "arm_right": {"rotation": {"0.0": [0, 0, 0], "0.5": [-120, 0, 0], "0.8": [30, 0, 0], "1.2": [0, 0, 0]}}
            }
        }
    }
}

# -----------------------------------------------------------------------------
# 5. Soulfire Wraith (Hovering Boss)
# -----------------------------------------------------------------------------
wraith_geo = {
    "format_version": "1.12.0",
    "minecraft:geometry": [{
        "description": {
            "identifier": "geometry.soulfire_wraith",
            "texture_width": 64,
            "texture_height": 64,
            "visible_bounds_width": 3,
            "visible_bounds_height": 3.5,
            "visible_bounds_offset": [0, 1.75, 0]
        },
        "bones": [
            {"name": "root", "pivot": [0, 16, 0]},
            {"name": "body", "parent": "root", "pivot": [0, 18, 0], "cubes": [
                {"origin": [-5, 6, -3], "size": [10, 14, 6], "uv": [0, 24]}
            ]},
            {"name": "head", "parent": "body", "pivot": [0, 20, 0], "cubes": [
                {"origin": [-4, 20, -4], "size": [8, 8, 8], "uv": [0, 0]}
            ]},
            {"name": "robe_bottom", "parent": "body", "pivot": [0, 6, 0], "cubes": [
                {"origin": [-6, -4, -4], "size": [12, 10, 8], "uv": [0, 44]}
            ]},
            {"name": "arm_left", "parent": "body", "pivot": [6, 18, 0], "cubes": [
                {"origin": [5, 4, -2], "size": [3, 16, 4], "uv": [32, 0]}
            ]},
            {"name": "arm_right", "parent": "body", "pivot": [-6, 18, 0], "cubes": [
                {"origin": [-8, 4, -2], "size": [3, 16, 4], "uv": [32, 0]}
            ]}
        ]
    }]
}

wraith_anim = {
    "format_version": "1.8.0",
    "animations": {
        "animation.soulfire_wraith.idle": {
            "loop": True,
            "animation_length": 2.0,
            "bones": {
                "root": {
                    "position": {"0.0": [0, 0, 0], "1.0": [0, 2.5, 0], "2.0": [0, 0, 0]}
                },
                "robe_bottom": {
                    "rotation": {"0.0": [5, 0, 0], "1.0": [-5, 0, 0], "2.0": [5, 0, 0]}
                },
                "arm_left": {
                    "rotation": {"0.0": [-10, 0, 15], "1.0": [10, 0, 25], "2.0": [-10, 0, 15]}
                },
                "arm_right": {
                    "rotation": {"0.0": [-10, 0, -15], "1.0": [10, 0, -25], "2.0": [-10, 0, -15]}
                }
            }
        },
        "animation.soulfire_wraith.cast": {
            "animation_length": 0.8,
            "bones": {
                "arm_left": {"rotation": {"0.0": [0, 0, 0], "0.3": [-90, -30, 0], "0.8": [0, 0, 0]}},
                "arm_right": {"rotation": {"0.0": [0, 0, 0], "0.3": [-90, 30, 0], "0.8": [0, 0, 0]}},
                "head": {"rotation": {"0.0": [0, 0, 0], "0.3": [-20, 0, 0], "0.8": [0, 0, 0]}}
            }
        }
    }
}

for name, geo, anim in [
    ("echo_stalker", stalker_geo, stalker_anim),
    ("sculk_crawler", crawler_geo, crawler_anim),
    ("soul_wisp", wisp_geo, wisp_anim),
    ("echo_colossus", colossus_geo, colossus_anim),
    ("soulfire_wraith", wraith_geo, wraith_anim)
]:
    with open(os.path.join(GEO, f"{name}.geo.json"), "w") as f:
        json.dump(geo, f, indent=2)
    with open(os.path.join(ANIM, f"{name}.animation.json"), "w") as f:
        json.dump(anim, f, indent=2)
    print(f"Generated geo & anim for {name}")

print("All GeckoLib models and animations generated!")
