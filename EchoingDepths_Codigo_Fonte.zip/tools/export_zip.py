import os
import zipfile

src = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out_dir = r"C:\Users\Davi Lucas\Documents\EchoingDepths"
os.makedirs(out_dir, exist_ok=True)
zip_path = os.path.join(out_dir, "EchoingDepths_Codigo_Fonte.zip")

print("Zipping project...")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(src):
        # Ignore .gradle, build, and .git folders
        dirs[:] = [d for d in dirs if d not in [".gradle", "build", ".git"]]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, src)
            z.write(full, rel)

print(f"Zip created at {zip_path} ({os.path.getsize(zip_path)} bytes)")
