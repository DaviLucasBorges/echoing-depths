"""
Texture pipeline for The Echoing Depths.

Turns the AI-generated sprite sheets in tools/art/ into 16x16 Minecraft textures and
procedurally generates the textures that need precise layouts (animated portal,
glass, particles, armor layers, lantern).

Run:  python tools/textures.py
"""
import math
import os
import random

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ART = os.path.join(ROOT, "tools", "art")
TEX = os.path.join(ROOT, "src", "main", "resources", "assets", "echoingdepths", "textures")
BLOCK = os.path.join(TEX, "block")
ITEM = os.path.join(TEX, "item")
PARTICLE = os.path.join(TEX, "particle")
ARMOR = os.path.join(TEX, "models", "armor")

for d in (BLOCK, ITEM, PARTICLE, ARMOR, os.path.join(TEX, "entity")):
    os.makedirs(d, exist_ok=True)

rng = random.Random(1337)


# ----------------------------------------------------------------------------- helpers
def load(name):
    return Image.open(os.path.join(ART, name)).convert("RGB")


def quantize(img, colors=16):
    """Crisp up a downscaled image by reducing it to a small palette (keeps alpha)."""
    img = img.convert("RGBA")
    alpha = img.getchannel("A")
    q = img.convert("RGB").quantize(colors=colors, method=Image.Quantize.MEDIANCUT).convert("RGB")
    q.putalpha(alpha)
    return q


def cell_box(img, r, c, grid=4, inset=12):
    w, h = img.size
    cw, ch = w / grid, h / grid
    return (int(c * cw + inset), int(r * ch + inset), int((c + 1) * cw - inset), int((r + 1) * ch - inset))


def block_tile(img, r, c, colors=16):
    t = img.crop(cell_box(img, r, c)).resize((16, 16), Image.BOX)
    return quantize(t, colors)


def item_sprite(img, r, c, colors=16, margin=0.5):
    """Extract a sprite on magenta background, auto-crop, downscale to 16x16 with alpha."""
    crop = img.crop(cell_box(img, r, c, inset=8))
    a = np.asarray(crop).astype(np.float32)
    R, G, B = a[..., 0], a[..., 1], a[..., 2]
    background = ((R - G) > 60) & ((B - G) > 60) & (R > 90) & (B > 90)
    # thin dark grid lines that survived the inset
    fg = ~background
    ys, xs = np.nonzero(fg)
    if len(xs) == 0:
        raise ValueError(f"empty sprite at {r},{c}")
    # ignore isolated noise by using percentiles for the bbox
    x0, x1 = np.percentile(xs, [0.5, 99.5])
    y0, y1 = np.percentile(ys, [0.5, 99.5])
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    side = max(x1 - x0, y1 - y0) * (16 / (16 - 2 * margin))
    box = (cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2)

    mask = Image.fromarray((fg * 255).astype(np.uint8))
    premul = Image.fromarray((a * fg[..., None]).astype(np.uint8))
    box_i = tuple(int(round(v)) for v in box)
    m = np.asarray(mask.crop(box_i).resize((16, 16), Image.BOX)).astype(np.float32) / 255
    p = np.asarray(premul.crop(box_i).resize((16, 16), Image.BOX)).astype(np.float32)
    rgb = np.where(m[..., None] > 0, p / np.maximum(m[..., None], 1e-3), 0)
    alpha = (m > 0.42).astype(np.uint8) * 255
    out = np.dstack([np.clip(rgb, 0, 255).astype(np.uint8), alpha])
    return quantize(Image.fromarray(out, "RGBA"), colors)


def save(img, folder, name):
    img.save(os.path.join(folder, name + ".png"))


def palette_of(img, n=5):
    """Return n colors sorted dark->light from an image."""
    q = img.convert("RGB").quantize(colors=n, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()[: n * 3]
    cols = [tuple(pal[i:i + 3]) for i in range(0, n * 3, 3)]
    return sorted(cols, key=lambda c: 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2])


def value_noise(size, scale, seed):
    r = np.random.default_rng(seed)
    g = r.random((size // scale + 2, size // scale + 2))
    img = Image.fromarray((g * 255).astype(np.uint8)).resize((size + scale * 2, size + scale * 2), Image.BILINEAR)
    return np.asarray(img).astype(np.float32)[:size, :size] / 255


def map_palette(values, pal):
    idx = np.clip((values * len(pal)).astype(int), 0, len(pal) - 1)
    arr = np.array(pal, dtype=np.uint8)[idx]
    return arr


def key_out(img, predicate):
    a = np.asarray(img.convert("RGBA")).copy()
    m = predicate(a[..., 0].astype(int), a[..., 1].astype(int), a[..., 2].astype(int))
    a[m, 3] = 0
    return Image.fromarray(a, "RGBA")


def lum(r, g, b):
    return 0.299 * r + 0.587 * g + 0.114 * b


# ----------------------------------------------------------------------------- blocks
b1, b2 = load("blocks_1.jpg"), load("blocks_2.jpg")

cobbled = block_tile(b1, 0, 0)
save(cobbled, BLOCK, "cobbled_echo_stone")
save(block_tile(b1, 0, 2), BLOCK, "polished_echo_stone")
save(block_tile(b1, 0, 3), BLOCK, "echo_stone_bricks")
save(block_tile(b1, 1, 0), BLOCK, "cracked_echo_stone_bricks")
save(block_tile(b1, 1, 1), BLOCK, "chiseled_echo_stone_bricks")
moss_top = block_tile(b1, 1, 2)
save(moss_top, BLOCK, "echo_moss_block_top")
soil = block_tile(b1, 1, 3)
save(soil, BLOCK, "echo_soil")
save(block_tile(b1, 2, 0), BLOCK, "echorite_ore")
save(block_tile(b1, 2, 1), BLOCK, "resonite_ore")
save(block_tile(b1, 2, 2), BLOCK, "soulfire_ore")
save(block_tile(b1, 2, 3), BLOCK, "raw_echorite_block")
save(block_tile(b1, 3, 0), BLOCK, "echorite_block")
save(block_tile(b1, 3, 3), BLOCK, "gloomwood_planks")

# Echo stone: smooth, vanilla-stone-like noise using the cobblestone palette
stone_pal = palette_of(cobbled, 5)[1:]
n = value_noise(16, 2, 7) * 0.6 + value_noise(16, 4, 8) * 0.4
stone = Image.fromarray(map_palette(n ** 1.1, stone_pal), "RGB")
save(stone, BLOCK, "echo_stone")

# Moss side: ragged moss on top of soil
side = np.asarray(soil.convert("RGBA")).copy()
moss = np.asarray(moss_top.convert("RGBA"))
for x in range(16):
    depth = rng.choice([2, 3, 3, 4, 4, 5])
    side[:depth, x] = moss[:depth, x]
save(Image.fromarray(side, "RGBA"), BLOCK, "echo_moss_block_side")

save(block_tile(b2, 0, 0), BLOCK, "gloomwood_log")
save(block_tile(b2, 0, 1), BLOCK, "gloomwood_log_top")
save(block_tile(b2, 0, 2), BLOCK, "stripped_gloomwood_log")
save(block_tile(b2, 0, 3), BLOCK, "stripped_gloomwood_log_top")
leaves = block_tile(b2, 1, 0)
save(key_out(leaves, lambda r, g, b: lum(r, g, b) < 28), BLOCK, "gloomwood_leaves")
save(block_tile(b2, 1, 1), BLOCK, "resonite_block")
save(block_tile(b2, 1, 2), BLOCK, "echo_crystal_block")
save(block_tile(b2, 1, 3), BLOCK, "resonant_lamp")
save(key_out(block_tile(b2, 2, 0), lambda r, g, b: lum(r, g, b) > 185), BLOCK, "gloomwood_door_top")
save(block_tile(b2, 2, 1), BLOCK, "gloomwood_door_bottom")
save(key_out(block_tile(b2, 2, 2), lambda r, g, b: lum(r, g, b) > 185), BLOCK, "gloomwood_trapdoor")
save(block_tile(b2, 3, 0), BLOCK, "resonant_altar_top")
save(block_tile(b2, 3, 1), BLOCK, "resonant_altar_side")
save(block_tile(b2, 3, 3), BLOCK, "echo_tiles")

# Echo glass: tinted cyan frame, mostly clear centre with streaks
glass = np.zeros((16, 16, 4), np.uint8)
glass[..., :3] = (120, 230, 240)
glass[..., 3] = 40
glass[0, :, 3] = glass[-1, :, 3] = glass[:, 0, 3] = glass[:, -1, 3] = 220
glass[0, :, :3] = glass[-1, :, :3] = glass[:, 0, :3] = glass[:, -1, :3] = (40, 140, 160)
for i in range(3, 7):
    glass[i, 13 - i, :3] = (220, 255, 255)
    glass[i, 13 - i, 3] = 170
for i in range(9, 12):
    glass[i, 15 - i + 1, :3] = (200, 250, 255)
    glass[i, 15 - i + 1, 3] = 140
save(Image.fromarray(glass, "RGBA"), BLOCK, "echo_glass")

# Animated portal (32 frames)
frames = 32
yy, xx = np.mgrid[0:16, 0:16].astype(np.float32)
cx = cy = 7.5
dist = np.hypot(xx - cx, yy - cy)
ang = np.arctan2(yy - cy, xx - cx)
strip = np.zeros((16 * frames, 16, 4), np.uint8)
dark, mid, light = np.array([8, 14, 48]), np.array([28, 86, 200]), np.array([110, 235, 255])
for f in range(frames):
    t = f / frames * 2 * math.pi
    v = np.sin(dist * 0.9 - t * 2 + ang * 2) * 0.5 + 0.5
    v = v * 0.7 + 0.3 * (np.sin(xx * 0.8 + t) * np.cos(yy * 0.7 - t) * 0.5 + 0.5)
    col = np.where(v[..., None] < 0.5,
                   dark + (mid - dark) * (v[..., None] * 2),
                   mid + (light - mid) * ((v[..., None] - 0.5) * 2))
    strip[f * 16:(f + 1) * 16, :, :3] = np.clip(col, 0, 255).astype(np.uint8)
    strip[f * 16:(f + 1) * 16, :, 3] = (170 + v * 70).astype(np.uint8)
save(Image.fromarray(strip, "RGBA"), BLOCK, "echo_portal")
with open(os.path.join(BLOCK, "echo_portal.png.mcmeta"), "w") as fh:
    fh.write('{\n  "animation": {\n    "frametime": 2,\n    "interpolate": true\n  }\n}\n')

# Lantern texture (custom layout used by models/block/echo_lantern*.json)
lan = np.zeros((16, 16, 4), np.uint8)
metal_d, metal_l = (34, 38, 52, 255), (70, 78, 98, 255)
flame_c, flame_l = (60, 200, 255, 255), (200, 250, 255, 255)
lan[0:2, 1:5] = metal_l                      # cap sides
lan[0:4, 7:11] = metal_d                     # cap top
lan[1:3, 8:10] = metal_l
lan[2:9, 0:6] = metal_d                      # body side frame
lan[3:8, 1:5] = flame_c                      # glowing glass
lan[4:7, 2:4] = flame_l
lan[9:15, 0:6] = metal_d                     # body top/bottom
lan[10:14, 1:5] = metal_l
lan[0:7, 12:13] = (90, 96, 112, 255)         # chain
lan[0:7:2, 12:13] = (50, 54, 66, 255)
save(Image.fromarray(lan, "RGBA"), BLOCK, "echo_lantern")

# ----------------------------------------------------------------------------- items
i1, i2, i3 = load("items_1.jpg"), load("items_2.jpg"), load("items_3.jpg")
grid1 = [["blue_fireball", "raw_echorite", "echorite_ingot", "echorite_nugget"],
         ["resonite_gem", "soulfire_dust", "echo_crystal_shard", "stalker_fang"],
         ["gloom_spore", "wisp_essence", "colossus_core", "wraith_heart"],
         ["resonite_upgrade_smithing_template", "resonant_sigil", "soulfire_sigil", "glowcap_stew"]]
grid2 = [["@gloomwood_sapling", "@echo_grass", "@glowcap", "@echo_crystal_cluster"],
         ["sonic_scepter", "abyssal_greatsword", "soulfire_staff", "gloomwood_door"],
         ["echorite_sword", "echorite_pickaxe", "echorite_axe", "echorite_shovel"],
         ["echorite_hoe", "echorite_helmet", "echorite_chestplate", "echorite_leggings"]]
grid3 = [["echorite_boots", "resonite_sword", "resonite_pickaxe", "resonite_axe"],
         ["resonite_shovel", "resonite_hoe", "resonite_helmet", "resonite_chestplate"],
         ["resonite_leggings", "resonite_boots", "echo_lantern", None],
         [None, "echo_orb", None, None]]
for sheet, grid in ((i1, grid1), (i2, grid2), (i3, grid3)):
    for r, row in enumerate(grid):
        for c, name in enumerate(row):
            if not name:
                continue
            spr = item_sprite(sheet, r, c)
            if name.startswith("@"):        # plants: block texture (cross model)
                save(spr, BLOCK, name[1:])
            else:
                save(spr, ITEM, name)

# ----------------------------------------------------------------------------- particles
def particle_frames(name, colors, shapes):
    for i, shape in enumerate(shapes):
        a = np.zeros((8, 8, 4), np.uint8)
        for y, row in enumerate(shape):
            for x, ch in enumerate(row):
                if ch != ".":
                    a[y, x] = colors[ch]
        save(Image.fromarray(a, "RGBA"), PARTICLE, f"{name}_{i}")


cyan = {"o": (70, 210, 255, 255), "x": (200, 250, 255, 255), "d": (30, 100, 200, 255)}
particle_frames("echo_portal", cyan, [
    ["........", "...o....", "..oxo...", ".oxxxo..", "..oxo...", "...o....", "........", "........"],
    ["........", "........", "...o....", "..oxo...", "...o....", "........", "........", "........"],
    ["........", "........", "...d....", "..dod...", "...d....", "........", "........", "........"],
    ["........", "........", "........", "...d....", "........", "........", "........", "........"],
])
ember = {"o": (60, 140, 255, 255), "x": (170, 230, 255, 255), "d": (30, 60, 170, 255)}
particle_frames("soul_ember", ember, [
    ["........", "...x....", "..xox...", "..oxo...", "..dod...", "...d....", "........", "........"],
    ["........", "........", "...x....", "..xox...", "..dod...", "........", "........", "........"],
    ["........", "........", "...o....", "..odo...", "...d....", "........", "........", "........"],
    ["........", "........", "........", "...d....", "...d....", "........", "........", "........"],
])
spark = {"o": (160, 120, 255, 255), "x": (210, 255, 255, 255), "d": (80, 60, 200, 255)}
particle_frames("resonance_spark", spark, [
    ["...x....", "...o....", "...o....", "xooxoox.", "...o....", "...o....", "...x....", "........"],
    ["........", "...o....", "...o....", ".ooxoo..", "...o....", "...o....", "........", "........"],
    ["........", "........", "...d....", "..dod...", "...d....", "........", "........", "........"],
    ["........", "........", "........", "...d....", "........", "........", "........", "........"],
])


# ----------------------------------------------------------------------------- armor layers
def material_canvas(tile_path, w=64, h=32):
    t = Image.open(tile_path).convert("RGBA")
    c = Image.new("RGBA", (w, h))
    for y in range(0, h, 16):
        for x in range(0, w, 16):
            c.paste(t, (x, y))
    return np.asarray(c).copy()


def armor(material, accent):
    tile = os.path.join(BLOCK, f"{material}_block.png")
    base = material_canvas(tile)
    edge = np.clip(base[..., :3].astype(int) * 0.55, 0, 255).astype(np.uint8)

    def paint(dst, x0, y0, x1, y1):
        dst[y0:y1, x0:x1] = base[y0:y1, x0:x1]
        dst[y0:y1, x0, :3] = edge[y0:y1, x0]
        dst[y0:y1, x1 - 1, :3] = edge[y0:y1, x1 - 1]
        dst[y1 - 1, x0:x1, :3] = edge[y1 - 1, x0:x1]

    l1 = np.zeros((32, 64, 4), np.uint8)
    # helmet: head box (8x8x8) at uv 0,0
    paint(l1, 8, 0, 16, 8)        # top
    for x0 in (0, 16, 24):        # right, left, back faces
        paint(l1, x0, 8, x0 + 8, 16)
    paint(l1, 8, 8, 16, 11)       # front brow
    paint(l1, 8, 11, 9, 16)       # front cheeks
    paint(l1, 15, 11, 16, 16)
    l1[11, 9:15, :3] = accent     # glowing visor line
    l1[11, 9:15, 3] = 255
    # chestplate: body (8x12x4) at 16,16 and arms (4x12x4) at 40,16
    paint(l1, 20, 16, 36, 20)
    paint(l1, 16, 20, 40, 32)
    l1[24:27, 23:25, :3] = accent
    paint(l1, 44, 16, 52, 20)
    paint(l1, 40, 20, 56, 28)
    # boots: lower leg (4x12x4) at 0,16
    paint(l1, 4, 16, 12, 20)
    paint(l1, 0, 27, 16, 32)
    l1[27, 0:16, :3] = accent

    l2 = np.zeros((32, 64, 4), np.uint8)
    paint(l2, 4, 16, 12, 20)
    paint(l2, 0, 20, 16, 30)
    paint(l2, 16, 27, 40, 32)
    l2[27, 16:40, :3] = accent
    l2[27, 16:40, 3] = 255

    Image.fromarray(l1, "RGBA").save(os.path.join(ARMOR, f"{material}_layer_1.png"))
    Image.fromarray(l2, "RGBA").save(os.path.join(ARMOR, f"{material}_layer_2.png"))


armor("echorite", (90, 230, 255))
armor("resonite", (120, 255, 240))

print("textures done")
