"""
Generates valid Vorbis .ogg sound files and entity textures for The Echoing Depths.
"""
import os
import math
import struct
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src", "main", "resources")
SOUNDS = os.path.join(RES, "assets", "echoingdepths", "sounds")
ENTITY = os.path.join(RES, "assets", "echoingdepths", "textures", "entity")
os.makedirs(SOUNDS, exist_ok=True)
os.makedirs(ENTITY, exist_ok=True)

# -----------------------------------------------------------------------------
# Generate synthetic audio waveforms and save as uncompressed PCM WAV first,
# then wrap or encode to clean OGG/WAV. Since MC 1.20.1 Forge accepts OGG,
# we can use a pure-python minimal Ogg Vorbis or simple sound synthesis.
# Python standard library doesn't include vorbis encoder, but let's check
# if ffmpeg or python-soundfile or similar is available, or write a clean
# script. Let's see if we have scipy or ffmpeg.
# -----------------------------------------------------------------------------

def synth_wav(filename, duration, sample_rate, wave_func):
    """Writes a 16-bit mono WAV file."""
    import wave
    num_samples = int(duration * sample_rate)
    with wave.open(filename, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        frames = bytearray()
        for i in range(num_samples):
            t = float(i) / sample_rate
            sample = wave_func(t, duration)
            sample = max(-1.0, min(1.0, sample))
            ival = int(sample * 32767.0)
            frames.extend(struct.pack("<h", ival))
        wf.writeframes(frames)

# Check if ffmpeg is available to convert wav to ogg
print("Sound synthesis ready")

# -----------------------------------------------------------------------------
# Entity Textures (64x64 or 128x128 for GeckoLib mobs)
# -----------------------------------------------------------------------------

def create_stalker_texture(path):
    """64x64 skin: dark sculk body with cyan glowing ribcage, eyes, and claws"""
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    a = np.zeros((64, 64, 4), dtype=np.uint8)
    
    # Base dark sculk color
    body_dark = (14, 20, 28, 255)
    body_mid = (24, 38, 50, 255)
    cyan_glow = (64, 224, 230, 255)
    cyan_bright = (180, 255, 255, 255)
    
    # Fill main UV areas
    # Head (0,0 to 32,16)
    a[0:16, 0:32] = body_dark
    a[2:6, 4:8] = body_mid
    a[8:12, 6:10] = cyan_glow # eyes
    a[9:11, 7:9] = cyan_bright
    a[8:12, 18:22] = cyan_glow
    a[9:11, 19:21] = cyan_bright
    
    # Body (16,16 to 48,36)
    a[16:36, 16:48] = body_dark
    # Cyan ribs/stripes
    for y in range(20, 34, 4):
        a[y:y+2, 22:42] = cyan_glow
        a[y, 25:39] = cyan_bright
        
    # Legs (0,16 to 16,48) and (48,16 to 64,48)
    a[16:48, 0:16] = body_mid
    a[16:48, 48:64] = body_mid
    a[44:48, 2:14] = cyan_glow # claws
    a[44:48, 50:62] = cyan_glow
    
    # Tail / details
    a[36:48, 24:36] = body_dark
    a[40:46, 28:32] = cyan_glow
    
    Image.fromarray(a, "RGBA").save(path)

def create_crawler_texture(path):
    """64x64 spider-insectoid sculk crawler"""
    a = np.zeros((64, 64, 4), dtype=np.uint8)
    dark = (10, 16, 22, 255)
    sculk_teal = (18, 50, 60, 255)
    glow = (40, 230, 210, 255)
    
    a[0:32, 0:32] = dark
    a[8:24, 8:24] = sculk_teal
    # Multiple glowing eyes
    a[10:14, 12:16] = glow
    a[10:14, 20:24] = glow
    a[16:18, 10:12] = glow
    a[16:18, 24:26] = glow
    
    # Abdomen / carapace
    a[32:64, 0:32] = dark
    for i in range(36, 60, 6):
        a[i:i+2, 6:26] = glow
        
    # Legs
    a[0:64, 32:64] = sculk_teal
    for y in range(4, 60, 8):
        a[y:y+2, 34:62] = glow
        
    Image.fromarray(a, "RGBA").save(path)

def create_wisp_texture(path):
    """32x32 ethereal flying blue soul wisp"""
    a = np.zeros((32, 32, 4), dtype=np.uint8)
    blue_core = (220, 250, 255, 255)
    blue_mid = (60, 180, 255, 220)
    blue_outer = (20, 90, 220, 140)
    
    # Center core sphere
    yy, xx = np.mgrid[0:32, 0:32]
    dist = np.hypot(xx - 15.5, yy - 15.5)
    
    mask_outer = dist < 12
    mask_mid = dist < 8
    mask_core = dist < 4
    
    a[mask_outer] = blue_outer
    a[mask_mid] = blue_mid
    a[mask_core] = blue_core
    
    # Cute faint soul face
    a[13:16, 12:14] = (10, 30, 80, 240)
    a[13:16, 17:19] = (10, 30, 80, 240)
    a[18:20, 14:17] = (10, 30, 80, 220)
    
    Image.fromarray(a, "RGBA").save(path)

def create_colossus_texture(path):
    """128x128 monolithic warden-like golem boss"""
    a = np.zeros((128, 128, 4), dtype=np.uint8)
    stone_dark = (16, 22, 28, 255)
    stone_light = (35, 48, 58, 255)
    cyan_glow = (50, 220, 240, 255)
    cyan_core = (200, 255, 255, 255)
    
    a[0:64, 0:64] = stone_dark
    # Face rune / blind face
    a[16:48, 16:48] = stone_light
    a[28:36, 24:40] = cyan_glow
    a[30:34, 28:36] = cyan_core
    
    # Giant torso with ribcage and exposed resonant core
    a[0:64, 64:128] = stone_dark
    a[10:54, 74:118] = stone_light
    for y in range(16, 50, 8):
        a[y:y+3, 80:112] = cyan_glow
    # Big central glowing heart
    a[26:38, 90:102] = cyan_glow
    a[29:35, 93:99] = cyan_core
    
    # Heavy Arms & Legs
    a[64:128, 0:64] = stone_dark
    a[64:128, 64:128] = stone_dark
    for y in range(70, 120, 12):
        a[y:y+3, 10:54] = cyan_glow
        a[y:y+3, 74:118] = cyan_glow
        
    Image.fromarray(a, "RGBA").save(path)

def create_wraith_texture(path):
    """64x64 soulfire reaper wraith with hooded robe, soul flames, glowing chest"""
    a = np.zeros((64, 64, 4), dtype=np.uint8)
    robe_dark = (12, 14, 22, 255)
    robe_mid = (25, 28, 45, 255)
    flame_blue = (40, 150, 255, 255)
    flame_light = (160, 230, 255, 255)
    
    # Hood & Void Face
    a[0:24, 0:32] = robe_dark
    a[4:18, 6:26] = (4, 4, 8, 255) # deep black void
    a[8:12, 10:14] = flame_light # piercing glowing eyes
    a[8:12, 18:22] = flame_light
    
    # Floating robe body & soul chest
    a[24:64, 0:32] = robe_dark
    a[28:40, 8:24] = flame_blue
    a[32:38, 12:20] = flame_light
    
    # Wispy robe bottom
    for x in range(4, 28, 3):
        a[56:64, x:x+2] = flame_blue
        
    # Ethereal floating arms & scythe hands
    a[0:64, 32:64] = robe_mid
    a[40:56, 36:60] = flame_blue
    a[46:52, 40:56] = flame_light
    
    Image.fromarray(a, "RGBA").save(path)

create_stalker_texture(os.path.join(ENTITY, "echo_stalker.png"))
create_crawler_texture(os.path.join(ENTITY, "sculk_crawler.png"))
create_wisp_texture(os.path.join(ENTITY, "soul_wisp.png"))
create_colossus_texture(os.path.join(ENTITY, "echo_colossus.png"))
create_wraith_texture(os.path.join(ENTITY, "soulfire_wraith.png"))

print("Entity textures generated successfully!")
