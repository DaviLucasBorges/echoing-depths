import os
import re
import json
import glob

def check():
    blocks_code = open('src/main/java/com/davilucas/echoingdepths/init/ModBlocks.java', encoding='utf-8').read()
    # Match registerBlock("name", ...) or register("name", ...)
    blocks = re.findall(r'register(?:Block)?\("([^"]+)"', blocks_code)
    # Filter out helper names if any
    blocks = [b for b in blocks if b != "name"]
    print(f"Total registered blocks: {len(blocks)}")

    bs_dir = 'src/main/resources/assets/echoingdepths/blockstates'
    missing_bs = [b for b in blocks if not os.path.exists(os.path.join(bs_dir, f"{b}.json"))]
    print(f"Missing blockstates ({len(missing_bs)}): {missing_bs}")

    lt_dir = 'src/main/resources/data/echoingdepths/loot_tables/blocks'
    missing_lt = [b for b in blocks if b != "echo_portal" and not os.path.exists(os.path.join(lt_dir, f"{b}.json"))]
    print(f"Missing block loot tables ({len(missing_lt)}): {missing_lt}")

    # Check items
    items_code = open('src/main/java/com/davilucas/echoingdepths/init/ModItems.java', encoding='utf-8').read()
    items = re.findall(r'ITEMS\.register\("([^"]+)"', items_code)
    print(f"Total registered items: {len(items)}")
    im_dir = 'src/main/resources/assets/echoingdepths/models/item'
    missing_im = [i for i in items if not os.path.exists(os.path.join(im_dir, f"{i}.json"))]
    print(f"Missing item models ({len(missing_im)}): {missing_im}")

    # Check entities
    entities_code = open('src/main/java/com/davilucas/echoingdepths/init/ModEntities.java', encoding='utf-8').read()
    entities = re.findall(r'ENTITY_TYPES\.register\("([^"]+)"', entities_code)
    print(f"Total registered entities: {len(entities)}")
    
    geo_dir = 'src/main/resources/assets/echoingdepths/geo'
    anim_dir = 'src/main/resources/assets/echoingdepths/animations'
    ent_tex_dir = 'src/main/resources/assets/echoingdepths/textures/entity'
    
    for e in entities:
        geo = os.path.join(geo_dir, f"{e}.geo.json")
        anim = os.path.join(anim_dir, f"{e}.animation.json")
        tex = os.path.join(ent_tex_dir, f"{e}.png")
        if not os.path.exists(geo):
            print(f"Entity {e} missing geo: {geo}")
        if not os.path.exists(anim):
            print(f"Entity {e} missing animation: {anim}")
        if not os.path.exists(tex):
            print(f"Entity {e} missing texture: {tex}")

    # Check language files
    lang_en = json.load(open('src/main/resources/assets/echoingdepths/lang/en_us.json', encoding='utf-8'))
    lang_pt = json.load(open('src/main/resources/assets/echoingdepths/lang/pt_br.json', encoding='utf-8'))
    print(f"en_us entries: {len(lang_en)}, pt_br entries: {len(lang_pt)}")

    # Check if any block or item is missing from en_us
    missing_lang = []
    for b in blocks:
        key = f"block.echoingdepths.{b}"
        if key not in lang_en:
            missing_lang.append(key)
    for i in items:
        key = f"item.echoingdepths.{i}"
        if key not in lang_en:
            missing_lang.append(key)
    for e in entities:
        key = f"entity.echoingdepths.{e}"
        if key not in lang_en:
            missing_lang.append(key)
    print(f"Missing translations in en_us ({len(missing_lang)}): {missing_lang}")

if __name__ == '__main__':
    check()
