"""
Generates all JSON data and assets for The Echoing Depths:
- Blockstates & Block Models (all 34 blocks)
- Item Models (all blocks and items)
- Recipes (crafting, smelting, blasting, smithing)
- Loot Tables (blocks, entities, dungeons)
- Worldgen JSON (dimension, dimension_type, noise_settings, biomes, configured/placed features)
- Tags (blocks, items, biomes)
- Language files (en_us and pt_br)
"""
import os
import json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "echoingdepths")
DATA = os.path.join(RES, "data", "echoingdepths")

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p

BS_DIR = ensure_dir(os.path.join(ASSETS, "blockstates"))
BM_DIR = ensure_dir(os.path.join(ASSETS, "models", "block"))
IM_DIR = ensure_dir(os.path.join(ASSETS, "models", "item"))
LANG_DIR = ensure_dir(os.path.join(ASSETS, "lang"))

REC_DIR = ensure_dir(os.path.join(DATA, "recipes"))
LT_BLOCK = ensure_dir(os.path.join(DATA, "loot_tables", "blocks"))
LT_ENTITY = ensure_dir(os.path.join(DATA, "loot_tables", "entities"))

DIM_DIR = ensure_dir(os.path.join(DATA, "dimension"))
DIMTYPE_DIR = ensure_dir(os.path.join(DATA, "dimension_type"))
NOISE_DIR = ensure_dir(os.path.join(DATA, "worldgen", "noise_settings"))
BIOME_DIR = ensure_dir(os.path.join(DATA, "worldgen", "biome"))
CF_DIR = ensure_dir(os.path.join(DATA, "worldgen", "configured_feature"))
PF_DIR = ensure_dir(os.path.join(DATA, "worldgen", "placed_feature"))

MC_TAGS_BLOCK = ensure_dir(os.path.join(RES, "data", "minecraft", "tags", "blocks"))
MC_TAGS_ITEM = ensure_dir(os.path.join(RES, "data", "minecraft", "tags", "items"))

def dump(data, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

# =============================================================================
# 1. BLOCKSTATES & BLOCK MODELS
# =============================================================================

simple_cubes = [
    "echo_stone", "cobbled_echo_stone", "polished_echo_stone", "echo_stone_bricks",
    "cracked_echo_stone_bricks", "chiseled_echo_stone_bricks", "echo_tiles",
    "echo_soil", "echorite_ore", "resonite_ore", "soulfire_ore",
    "raw_echorite_block", "echorite_block", "resonite_block", "echo_crystal_block",
    "gloomwood_planks", "resonant_lamp"
]

for name in simple_cubes:
    # blockstate
    dump({"variants": {"": {"model": f"echoingdepths:block/{name}"}}}, os.path.join(BS_DIR, f"{name}.json"))
    # block model
    dump({"parent": "minecraft:block/cube_all", "textures": {"all": f"echoingdepths:block/{name}"}}, os.path.join(BM_DIR, f"{name}.json"))
    # item model
    dump({"parent": f"echoingdepths:block/{name}"}, os.path.join(IM_DIR, f"{name}.json"))

# Echo Glass
dump({"variants": {"": {"model": "echoingdepths:block/echo_glass"}}}, os.path.join(BS_DIR, "echo_glass.json"))
dump({"parent": "minecraft:block/cube_all", "textures": {"all": "echoingdepths:block/echo_glass"}}, os.path.join(BM_DIR, "echo_glass.json"))
dump({"parent": "echoingdepths:block/echo_glass"}, os.path.join(IM_DIR, "echo_glass.json"))

# Echo Moss Block (top, bottom, sides)
dump({"variants": {"": {"model": "echoingdepths:block/echo_moss_block"}}}, os.path.join(BS_DIR, "echo_moss_block.json"))
dump({
    "parent": "minecraft:block/cube_bottom_top",
    "textures": {
        "top": "echoingdepths:block/echo_moss_block_top",
        "bottom": "echoingdepths:block/echo_soil",
        "side": "echoingdepths:block/echo_moss_block_side"
    }
}, os.path.join(BM_DIR, "echo_moss_block.json"))
dump({"parent": "echoingdepths:block/echo_moss_block"}, os.path.join(IM_DIR, "echo_moss_block.json"))

# Resonant Altar
dump({"variants": {"": {"model": "echoingdepths:block/resonant_altar"}}}, os.path.join(BS_DIR, "resonant_altar.json"))
dump({
    "parent": "minecraft:block/cube_column",
    "textures": {
        "end": "echoingdepths:block/resonant_altar_top",
        "side": "echoingdepths:block/resonant_altar_side"
    }
}, os.path.join(BM_DIR, "resonant_altar.json"))
dump({"parent": "echoingdepths:block/resonant_altar"}, os.path.join(IM_DIR, "resonant_altar.json"))

# Logs & Wood (Rotated Pillar)
for log, top, side in [
    ("gloomwood_log", "gloomwood_log_top", "gloomwood_log"),
    ("stripped_gloomwood_log", "stripped_gloomwood_log_top", "stripped_gloomwood_log"),
    ("gloomwood_wood", "gloomwood_log", "gloomwood_log"),
    ("stripped_gloomwood_wood", "stripped_gloomwood_log", "stripped_gloomwood_log")
]:
    dump({
        "variants": {
            "axis=y": {"model": f"echoingdepths:block/{log}"},
            "axis=z": {"model": f"echoingdepths:block/{log}_horizontal", "x": 90},
            "axis=x": {"model": f"echoingdepths:block/{log}_horizontal", "x": 90, "y": 90}
        }
    }, os.path.join(BS_DIR, f"{log}.json"))
    dump({
        "parent": "minecraft:block/cube_column",
        "textures": {"end": f"echoingdepths:block/{top}", "side": f"echoingdepths:block/{side}"}
    }, os.path.join(BM_DIR, f"{log}.json"))
    dump({
        "parent": "minecraft:block/cube_column_horizontal",
        "textures": {"end": f"echoingdepths:block/{top}", "side": f"echoingdepths:block/{side}"}
    }, os.path.join(BM_DIR, f"{log}_horizontal.json"))
    dump({"parent": f"echoingdepths:block/{log}"}, os.path.join(IM_DIR, f"{log}.json"))

# Leaves
dump({"variants": {"": {"model": "echoingdepths:block/gloomwood_leaves"}}}, os.path.join(BS_DIR, "gloomwood_leaves.json"))
dump({"parent": "minecraft:block/cube_all", "textures": {"all": "echoingdepths:block/gloomwood_leaves"}}, os.path.join(BM_DIR, "gloomwood_leaves.json"))
dump({"parent": "echoingdepths:block/gloomwood_leaves"}, os.path.join(IM_DIR, "gloomwood_leaves.json"))

# Plants (cross model)
for plant in ["gloomwood_sapling", "echo_grass", "glowcap", "echo_crystal_cluster"]:
    dump({"variants": {"": {"model": f"echoingdepths:block/{plant}"}}}, os.path.join(BS_DIR, f"{plant}.json"))
    dump({
        "parent": "minecraft:block/cross",
        "textures": {"cross": f"echoingdepths:block/{plant}"}
    }, os.path.join(BM_DIR, f"{plant}.json"))
    dump({
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"echoingdepths:block/{plant}"}
    }, os.path.join(IM_DIR, f"{plant}.json"))

# Stairs helper
def make_stairs(stair_name, base_tex):
    dump({
        "variants": {
            "facing=east,half=bottom,shape=straight": {"model": f"echoingdepths:block/{stair_name}"},
            "facing=west,half=bottom,shape=straight": {"model": f"echoingdepths:block/{stair_name}", "y": 180, "uvlock": True},
            "facing=south,half=bottom,shape=straight": {"model": f"echoingdepths:block/{stair_name}", "y": 90, "uvlock": True},
            "facing=north,half=bottom,shape=straight": {"model": f"echoingdepths:block/{stair_name}", "y": 270, "uvlock": True},
            "facing=east,half=top,shape=straight": {"model": f"echoingdepths:block/{stair_name}_top", "x": 180, "uvlock": True},
            "facing=west,half=top,shape=straight": {"model": f"echoingdepths:block/{stair_name}_top", "x": 180, "y": 180, "uvlock": True},
            "facing=south,half=top,shape=straight": {"model": f"echoingdepths:block/{stair_name}_top", "x": 180, "y": 90, "uvlock": True},
            "facing=north,half=top,shape=straight": {"model": f"echoingdepths:block/{stair_name}_top", "x": 180, "y": 270, "uvlock": True}
        }
    }, os.path.join(BS_DIR, f"{stair_name}.json"))
    dump({
        "parent": "minecraft:block/stairs",
        "textures": {"bottom": f"echoingdepths:block/{base_tex}", "top": f"echoingdepths:block/{base_tex}", "side": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{stair_name}.json"))
    dump({
        "parent": "minecraft:block/stairs_top",
        "textures": {"bottom": f"echoingdepths:block/{base_tex}", "top": f"echoingdepths:block/{base_tex}", "side": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{stair_name}_top.json"))
    dump({"parent": f"echoingdepths:block/{stair_name}"}, os.path.join(IM_DIR, f"{stair_name}.json"))

make_stairs("echo_stone_stairs", "echo_stone")
make_stairs("echo_brick_stairs", "echo_stone_bricks")
make_stairs("gloomwood_stairs", "gloomwood_planks")

# Slabs helper
def make_slab(slab_name, base_tex):
    dump({
        "variants": {
            "type=bottom": {"model": f"echoingdepths:block/{slab_name}"},
            "type=top": {"model": f"echoingdepths:block/{slab_name}_top"},
            "type=double": {"model": f"echoingdepths:block/{base_tex}"}
        }
    }, os.path.join(BS_DIR, f"{slab_name}.json"))
    dump({
        "parent": "minecraft:block/slab",
        "textures": {"bottom": f"echoingdepths:block/{base_tex}", "top": f"echoingdepths:block/{base_tex}", "side": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{slab_name}.json"))
    dump({
        "parent": "minecraft:block/slab_top",
        "textures": {"bottom": f"echoingdepths:block/{base_tex}", "top": f"echoingdepths:block/{base_tex}", "side": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{slab_name}_top.json"))
    dump({"parent": f"echoingdepths:block/{slab_name}"}, os.path.join(IM_DIR, f"{slab_name}.json"))

make_slab("echo_stone_slab", "echo_stone")
make_slab("echo_brick_slab", "echo_stone_bricks")
make_slab("gloomwood_slab", "gloomwood_planks")

# Walls helper
def make_wall(wall_name, base_tex):
    dump({
        "multipart": [
            {"apply": {"model": f"echoingdepths:block/{wall_name}_post"}, "when": {"up": "true"}},
            {"apply": {"model": f"echoingdepths:block/{wall_name}_side", "uvlock": True}, "when": {"north": "low"}},
            {"apply": {"model": f"echoingdepths:block/{wall_name}_side", "y": 90, "uvlock": True}, "when": {"east": "low"}},
            {"apply": {"model": f"echoingdepths:block/{wall_name}_side", "y": 180, "uvlock": True}, "when": {"south": "low"}},
            {"apply": {"model": f"echoingdepths:block/{wall_name}_side", "y": 270, "uvlock": True}, "when": {"west": "low"}}
        ]
    }, os.path.join(BS_DIR, f"{wall_name}.json"))
    dump({
        "parent": "minecraft:block/template_wall_post",
        "textures": {"wall": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{wall_name}_post.json"))
    dump({
        "parent": "minecraft:block/template_wall_side",
        "textures": {"wall": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(BM_DIR, f"{wall_name}_side.json"))
    dump({
        "parent": "minecraft:block/wall_inventory",
        "textures": {"wall": f"echoingdepths:block/{base_tex}"}
    }, os.path.join(IM_DIR, f"{wall_name}.json"))

make_wall("echo_stone_wall", "echo_stone")
make_wall("echo_brick_wall", "echo_stone_bricks")

# Gloomwood Fence & Gate
dump({
    "multipart": [
        {"apply": {"model": "echoingdepths:block/gloomwood_fence_post"}},
        {"apply": {"model": "echoingdepths:block/gloomwood_fence_side", "uvlock": True}, "when": {"north": "true"}},
        {"apply": {"model": "echoingdepths:block/gloomwood_fence_side", "y": 90, "uvlock": True}, "when": {"east": "true"}},
        {"apply": {"model": "echoingdepths:block/gloomwood_fence_side", "y": 180, "uvlock": True}, "when": {"south": "true"}},
        {"apply": {"model": "echoingdepths:block/gloomwood_fence_side", "y": 270, "uvlock": True}, "when": {"west": "true"}}
    ]
}, os.path.join(BS_DIR, "gloomwood_fence.json"))
dump({"parent": "minecraft:block/fence_post", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_fence_post.json"))
dump({"parent": "minecraft:block/fence_side", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_fence_side.json"))
dump({"parent": "minecraft:block/fence_inventory", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(IM_DIR, "gloomwood_fence.json"))

dump({
    "variants": {
        "facing=south,in_wall=false,open=false": {"model": "echoingdepths:block/gloomwood_fence_gate"},
        "facing=west,in_wall=false,open=false": {"model": "echoingdepths:block/gloomwood_fence_gate", "y": 90, "uvlock": True},
        "facing=north,in_wall=false,open=false": {"model": "echoingdepths:block/gloomwood_fence_gate", "y": 180, "uvlock": True},
        "facing=east,in_wall=false,open=false": {"model": "echoingdepths:block/gloomwood_fence_gate", "y": 270, "uvlock": True},
        "facing=south,in_wall=false,open=true": {"model": "echoingdepths:block/gloomwood_fence_gate_open"},
        "facing=west,in_wall=false,open=true": {"model": "echoingdepths:block/gloomwood_fence_gate_open", "y": 90, "uvlock": True},
        "facing=north,in_wall=false,open=true": {"model": "echoingdepths:block/gloomwood_fence_gate_open", "y": 180, "uvlock": True},
        "facing=east,in_wall=false,open=true": {"model": "echoingdepths:block/gloomwood_fence_gate_open", "y": 270, "uvlock": True}
    }
}, os.path.join(BS_DIR, "gloomwood_fence_gate.json"))
dump({"parent": "minecraft:block/template_fence_gate", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_fence_gate.json"))
dump({"parent": "minecraft:block/template_fence_gate_open", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_fence_gate_open.json"))
dump({"parent": "echoingdepths:block/gloomwood_fence_gate"}, os.path.join(IM_DIR, "gloomwood_fence_gate.json"))

# Gloomwood Door & Trapdoor
dump({
    "variants": {
        "facing=east,half=lower,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_bottom"},
        "facing=south,half=lower,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_bottom", "y": 90},
        "facing=west,half=lower,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_bottom", "y": 180},
        "facing=north,half=lower,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_bottom", "y": 270},
        "facing=east,half=upper,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_top"},
        "facing=south,half=upper,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_top", "y": 90},
        "facing=west,half=upper,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_top", "y": 180},
        "facing=north,half=upper,hinge=left,open=false": {"model": "echoingdepths:block/gloomwood_door_top", "y": 270}
    }
}, os.path.join(BS_DIR, "gloomwood_door.json"))
dump({
    "parent": "minecraft:block/door_bottom",
    "textures": {"bottom": "echoingdepths:block/gloomwood_door_bottom", "top": "echoingdepths:block/gloomwood_door_top"}
}, os.path.join(BM_DIR, "gloomwood_door_bottom.json"))
dump({
    "parent": "minecraft:block/door_top",
    "textures": {"bottom": "echoingdepths:block/gloomwood_door_bottom", "top": "echoingdepths:block/gloomwood_door_top"}
}, os.path.join(BM_DIR, "gloomwood_door_top.json"))
dump({"parent": "minecraft:item/generated", "textures": {"layer0": "echoingdepths:item/gloomwood_door"}}, os.path.join(IM_DIR, "gloomwood_door.json"))

dump({
    "variants": {
        "facing=north,half=bottom,open=false": {"model": "echoingdepths:block/gloomwood_trapdoor_bottom"},
        "facing=south,half=bottom,open=false": {"model": "echoingdepths:block/gloomwood_trapdoor_bottom", "y": 180},
        "facing=east,half=bottom,open=false": {"model": "echoingdepths:block/gloomwood_trapdoor_bottom", "y": 90},
        "facing=west,half=bottom,open=false": {"model": "echoingdepths:block/gloomwood_trapdoor_bottom", "y": 270},
        "facing=north,half=bottom,open=true": {"model": "echoingdepths:block/gloomwood_trapdoor_open"},
        "facing=south,half=bottom,open=true": {"model": "echoingdepths:block/gloomwood_trapdoor_open", "y": 180},
        "facing=east,half=bottom,open=true": {"model": "echoingdepths:block/gloomwood_trapdoor_open", "y": 90},
        "facing=west,half=bottom,open=true": {"model": "echoingdepths:block/gloomwood_trapdoor_open", "y": 270}
    }
}, os.path.join(BS_DIR, "gloomwood_trapdoor.json"))
dump({"parent": "minecraft:block/template_trapdoor_bottom", "textures": {"texture": "echoingdepths:block/gloomwood_trapdoor"}}, os.path.join(BM_DIR, "gloomwood_trapdoor_bottom.json"))
dump({"parent": "minecraft:block/template_trapdoor_open", "textures": {"texture": "echoingdepths:block/gloomwood_trapdoor"}}, os.path.join(BM_DIR, "gloomwood_trapdoor_open.json"))
dump({"parent": "echoingdepths:block/gloomwood_trapdoor_bottom"}, os.path.join(IM_DIR, "gloomwood_trapdoor.json"))

# Button & Pressure plate
dump({
    "variants": {
        "face=floor,facing=north,powered=false": {"model": "echoingdepths:block/gloomwood_button"},
        "face=floor,facing=north,powered=true": {"model": "echoingdepths:block/gloomwood_button_pressed"}
    }
}, os.path.join(BS_DIR, "gloomwood_button.json"))
dump({"parent": "minecraft:block/button", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_button.json"))
dump({"parent": "minecraft:block/button_pressed", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_button_pressed.json"))
dump({"parent": "echoingdepths:block/gloomwood_button"}, os.path.join(IM_DIR, "gloomwood_button.json"))

dump({
    "variants": {
        "powered=false": {"model": "echoingdepths:block/gloomwood_pressure_plate"},
        "powered=true": {"model": "echoingdepths:block/gloomwood_pressure_plate_down"}
    }
}, os.path.join(BS_DIR, "gloomwood_pressure_plate.json"))
dump({"parent": "minecraft:block/pressure_plate_up", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_pressure_plate.json"))
dump({"parent": "minecraft:block/pressure_plate_down", "textures": {"texture": "echoingdepths:block/gloomwood_planks"}}, os.path.join(BM_DIR, "gloomwood_pressure_plate_down.json"))
dump({"parent": "echoingdepths:block/gloomwood_pressure_plate"}, os.path.join(IM_DIR, "gloomwood_pressure_plate.json"))

# Echo Lantern
dump({
    "variants": {
        "hanging=false": {"model": "echoingdepths:block/echo_lantern"},
        "hanging=true": {"model": "echoingdepths:block/echo_lantern_hanging"}
    }
}, os.path.join(BS_DIR, "echo_lantern.json"))
dump({"parent": "minecraft:block/template_lantern", "textures": {"lantern": "echoingdepths:block/echo_lantern"}}, os.path.join(BM_DIR, "echo_lantern.json"))
dump({"parent": "minecraft:block/template_hanging_lantern", "textures": {"lantern": "echoingdepths:block/echo_lantern"}}, os.path.join(BM_DIR, "echo_lantern_hanging.json"))
dump({"parent": "minecraft:item/generated", "textures": {"layer0": "echoingdepths:item/echo_lantern"}}, os.path.join(IM_DIR, "echo_lantern.json"))

# Echo Portal (custom portal)
dump({
    "variants": {
        "axis=x": {"model": "echoingdepths:block/echo_portal_ns"},
        "axis=z": {"model": "echoingdepths:block/echo_portal_ew"}
    }
}, os.path.join(BS_DIR, "echo_portal.json"))
dump({
    "parent": "minecraft:block/nether_portal_ns",
    "textures": {"portal": "echoingdepths:block/echo_portal", "particle": "echoingdepths:block/echo_portal"}
}, os.path.join(BM_DIR, "echo_portal_ns.json"))
dump({
    "parent": "minecraft:block/nether_portal_ew",
    "textures": {"portal": "echoingdepths:block/echo_portal", "particle": "echoingdepths:block/echo_portal"}
}, os.path.join(BM_DIR, "echo_portal_ew.json"))

# =============================================================================
# 2. ITEM MODELS
# =============================================================================

generated_items = [
    "blue_fireball", "raw_echorite", "echorite_ingot", "echorite_nugget",
    "resonite_gem", "soulfire_dust", "echo_crystal_shard", "stalker_fang",
    "gloom_spore", "wisp_essence", "colossus_core", "wraith_heart",
    "resonite_upgrade_smithing_template", "resonant_sigil", "soulfire_sigil",
    "echo_orb", "glowcap_stew", "sonic_scepter", "soulfire_staff",
    "echorite_helmet", "echorite_chestplate", "echorite_leggings", "echorite_boots",
    "resonite_helmet", "resonite_chestplate", "resonite_leggings", "resonite_boots"
]

for item in generated_items:
    dump({
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"echoingdepths:item/{item}"}
    }, os.path.join(IM_DIR, f"{item}.json"))

handheld_items = [
    "echorite_sword", "echorite_pickaxe", "echorite_axe", "echorite_shovel", "echorite_hoe",
    "resonite_sword", "resonite_pickaxe", "resonite_axe", "resonite_shovel", "resonite_hoe",
    "abyssal_greatsword"
]

for item in handheld_items:
    dump({
        "parent": "minecraft:item/handheld",
        "textures": {"layer0": f"echoingdepths:item/{item}"}
    }, os.path.join(IM_DIR, f"{item}.json"))

spawn_eggs = [
    "echo_stalker_spawn_egg", "sculk_crawler_spawn_egg", "soul_wisp_spawn_egg",
    "echo_colossus_spawn_egg", "soulfire_wraith_spawn_egg"
]

for egg in spawn_eggs:
    dump({"parent": "minecraft:item/template_spawn_egg"}, os.path.join(IM_DIR, f"{egg}.json"))

# =============================================================================
# 3. RECIPES
# =============================================================================

# Ingot <-> Block
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###", "###"],
    "key": {"#": {"item": "echoingdepths:echorite_ingot"}},
    "result": {"item": "echoingdepths:echorite_block"}
}, os.path.join(REC_DIR, "echorite_block.json"))

dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "echoingdepths:echorite_block"}],
    "result": {"item": "echoingdepths:echorite_ingot", "count": 9}
}, os.path.join(REC_DIR, "echorite_ingot_from_block.json"))

# Nugget <-> Ingot
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###", "###"],
    "key": {"#": {"item": "echoingdepths:echorite_nugget"}},
    "result": {"item": "echoingdepths:echorite_ingot"}
}, os.path.join(REC_DIR, "echorite_ingot_from_nuggets.json"))

dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "echoingdepths:echorite_ingot"}],
    "result": {"item": "echoingdepths:echorite_nugget", "count": 9}
}, os.path.join(REC_DIR, "echorite_nuggets_from_ingot.json"))

# Resonite Block <-> Gem
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###", "###"],
    "key": {"#": {"item": "echoingdepths:resonite_gem"}},
    "result": {"item": "echoingdepths:resonite_block"}
}, os.path.join(REC_DIR, "resonite_block.json"))

dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "echoingdepths:resonite_block"}],
    "result": {"item": "echoingdepths:resonite_gem", "count": 9}
}, os.path.join(REC_DIR, "resonite_gem_from_block.json"))

# Smelting & Blasting Echorite Ore
dump({
    "type": "minecraft:smelting",
    "ingredient": {"item": "echoingdepths:echorite_ore"},
    "result": "echoingdepths:echorite_ingot",
    "experience": 0.8,
    "cookingtime": 200
}, os.path.join(REC_DIR, "echorite_ingot_smelting.json"))

dump({
    "type": "minecraft:blasting",
    "ingredient": {"item": "echoingdepths:raw_echorite"},
    "result": "echoingdepths:echorite_ingot",
    "experience": 0.8,
    "cookingtime": 100
}, os.path.join(REC_DIR, "echorite_ingot_blasting.json"))

# Gloomwood Planks from Log
dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "echoingdepths:gloomwood_log"}],
    "result": {"item": "echoingdepths:gloomwood_planks", "count": 4}
}, os.path.join(REC_DIR, "gloomwood_planks.json"))

# Stone Bricks from Polished
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##"],
    "key": {"#": {"item": "echoingdepths:polished_echo_stone"}},
    "result": {"item": "echoingdepths:echo_stone_bricks", "count": 4}
}, os.path.join(REC_DIR, "echo_stone_bricks.json"))

# Echorite Tools
tool_patterns = {
    "echorite_sword": (["#", "#", "S"], "echoingdepths:echorite_sword"),
    "echorite_pickaxe": (["###", " S ", " S "], "echoingdepths:echorite_pickaxe"),
    "echorite_axe": (["## ", "#S ", " S "], "echoingdepths:echorite_axe"),
    "echorite_shovel": (["#", "S", "S"], "echoingdepths:echorite_shovel"),
    "echorite_hoe": (["## ", " S ", " S "], "echoingdepths:echorite_hoe")
}
for name, (pat, res) in tool_patterns.items():
    dump({
        "type": "minecraft:crafting_shaped",
        "pattern": pat,
        "key": {"#": {"item": "echoingdepths:echorite_ingot"}, "S": {"item": "minecraft:stick"}},
        "result": {"item": res}
    }, os.path.join(REC_DIR, f"{name}.json"))

# Echorite Armor
armor_patterns = {
    "echorite_helmet": (["###", "# #"], "echoingdepths:echorite_helmet"),
    "echorite_chestplate": (["# #", "###", "###"], "echoingdepths:echorite_chestplate"),
    "echorite_leggings": (["###", "# #", "# #"], "echoingdepths:echorite_leggings"),
    "echorite_boots": (["# #", "# #"], "echoingdepths:echorite_boots")
}
for name, (pat, res) in armor_patterns.items():
    dump({
        "type": "minecraft:crafting_shaped",
        "pattern": pat,
        "key": {"#": {"item": "echoingdepths:echorite_ingot"}},
        "result": {"item": res}
    }, os.path.join(REC_DIR, f"{name}.json"))

# Smithing Upgrades for Resonite Tier
resonite_smithing = [
    ("echorite_sword", "resonite_sword"),
    ("echorite_pickaxe", "resonite_pickaxe"),
    ("echorite_axe", "resonite_axe"),
    ("echorite_shovel", "resonite_shovel"),
    ("echorite_hoe", "resonite_hoe"),
    ("echorite_helmet", "resonite_helmet"),
    ("echorite_chestplate", "resonite_chestplate"),
    ("echorite_leggings", "resonite_leggings"),
    ("echorite_boots", "resonite_boots")
]

for base, result in resonite_smithing:
    dump({
        "type": "minecraft:smithing_transform",
        "template": {"item": "echoingdepths:resonite_upgrade_smithing_template"},
        "base": {"item": f"echoingdepths:{base}"},
        "addition": {"item": "echoingdepths:resonite_gem"},
        "result": {"item": f"echoingdepths:{result}"}
    }, os.path.join(REC_DIR, f"{result}_smithing.json"))

# Special Artifact Recipes
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": [" C ", " S ", " I "],
    "key": {
        "C": {"item": "echoingdepths:colossus_core"},
        "S": {"item": "echoingdepths:echo_crystal_shard"},
        "I": {"item": "echoingdepths:echorite_ingot"}
    },
    "result": {"item": "echoingdepths:sonic_scepter"}
}, os.path.join(REC_DIR, "sonic_scepter.json"))

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": [" H ", " S ", " G "],
    "key": {
        "H": {"item": "echoingdepths:wraith_heart"},
        "S": {"item": "echoingdepths:soulfire_dust"},
        "G": {"item": "echoingdepths:gloomwood_log"}
    },
    "result": {"item": "echoingdepths:soulfire_staff"}
}, os.path.join(REC_DIR, "soulfire_staff.json"))

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": [" F ", " R ", " S "],
    "key": {
        "F": {"item": "echoingdepths:stalker_fang"},
        "R": {"item": "echoingdepths:resonite_block"},
        "S": {"item": "echoingdepths:colossus_core"}
    },
    "result": {"item": "echoingdepths:abyssal_greatsword"}
}, os.path.join(REC_DIR, "abyssal_greatsword.json"))

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["CSC", "SES", "CSC"],
    "key": {
        "C": {"item": "echoingdepths:echo_crystal_shard"},
        "S": {"item": "echoingdepths:echo_stone"},
        "E": {"item": "echoingdepths:resonite_gem"}
    },
    "result": {"item": "echoingdepths:resonant_sigil"}
}, os.path.join(REC_DIR, "resonant_sigil.json"))

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["DWD", "WSW", "DWD"],
    "key": {
        "D": {"item": "echoingdepths:soulfire_dust"},
        "W": {"item": "echoingdepths:wisp_essence"},
        "S": {"item": "minecraft:soul_soil"}
    },
    "result": {"item": "echoingdepths:soulfire_sigil"}
}, os.path.join(REC_DIR, "soulfire_sigil.json"))

dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [
        {"item": "minecraft:bowl"},
        {"item": "echoingdepths:glowcap"},
        {"item": "echoingdepths:gloom_spore"}
    ],
    "result": {"item": "echoingdepths:glowcap_stew"}
}, os.path.join(REC_DIR, "glowcap_stew.json"))

# =============================================================================
# 4. LOOT TABLES
# =============================================================================

for block in simple_cubes + ["gloomwood_planks", "echo_moss_block", "echo_glass", "resonant_altar",
                             "gloomwood_log", "stripped_gloomwood_log", "gloomwood_wood", "stripped_gloomwood_wood",
                             "echo_stone_stairs", "echo_stone_slab", "echo_stone_wall",
                             "echo_brick_stairs", "echo_brick_slab", "echo_brick_wall",
                             "gloomwood_stairs", "gloomwood_slab", "gloomwood_fence", "gloomwood_fence_gate",
                             "gloomwood_door", "gloomwood_trapdoor", "gloomwood_button", "gloomwood_pressure_plate",
                             "echo_grass", "glowcap", "echo_lantern"]:
    dump({
        "type": "minecraft:block",
        "pools": [{
            "rolls": 1,
            "bonus_rolls": 0,
            "entries": [{"type": "minecraft:item", "name": f"echoingdepths:{block}"}],
            "conditions": [{"condition": "minecraft:survives_explosion"}]
        }]
    }, os.path.join(LT_BLOCK, f"{block}.json"))

# Ore drops
def make_ore_drop(ore_name, item_name):
    dump({
        "type": "minecraft:block",
        "pools": [{
            "rolls": 1,
            "entries": [{
                "type": "minecraft:alternatives",
                "children": [
                    {
                        "type": "minecraft:item",
                        "name": f"echoingdepths:{ore_name}",
                        "conditions": [{"condition": "minecraft:match_tool", "predicate": {"enchantments": [{"enchantment": "minecraft:silk_touch", "levels": {"min": 1}}]}}]
                    },
                    {
                        "type": "minecraft:item",
                        "name": f"echoingdepths:{item_name}",
                        "functions": [
                            {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"},
                            {"function": "minecraft:explosion_decay"}
                        ]
                    }
                ]
            }]
        }]
    }, os.path.join(LT_BLOCK, f"{ore_name}.json"))

make_ore_drop("echorite_ore", "raw_echorite")
make_ore_drop("resonite_ore", "resonite_gem")
make_ore_drop("soulfire_ore", "soulfire_dust")
make_ore_drop("echo_crystal_cluster", "echo_crystal_shard")

# Entity Loot Tables
dump({
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1,
        "entries": [{"type": "minecraft:item", "name": "echoingdepths:stalker_fang", "functions": [{"function": "minecraft:set_count", "count": {"min": 1, "max": 2}}]}]
    }]
}, os.path.join(LT_ENTITY, "echo_stalker.json"))

dump({
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1,
        "entries": [{"type": "minecraft:item", "name": "echoingdepths:gloom_spore", "functions": [{"function": "minecraft:set_count", "count": {"min": 1, "max": 3}}]}]
    }]
}, os.path.join(LT_ENTITY, "sculk_crawler.json"))

dump({
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1,
        "entries": [{"type": "minecraft:item", "name": "echoingdepths:wisp_essence", "functions": [{"function": "minecraft:set_count", "count": {"min": 1, "max": 2}}]}]
    }]
}, os.path.join(LT_ENTITY, "soul_wisp.json"))

dump({
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1,
        "entries": [
            {"type": "minecraft:item", "name": "echoingdepths:colossus_core"},
            {"type": "minecraft:item", "name": "echoingdepths:resonite_upgrade_smithing_template"}
        ]
    }]
}, os.path.join(LT_ENTITY, "echo_colossus.json"))

dump({
    "type": "minecraft:entity",
    "pools": [{
        "rolls": 1,
        "entries": [
            {"type": "minecraft:item", "name": "echoingdepths:wraith_heart"},
            {"type": "minecraft:item", "name": "echoingdepths:resonite_gem", "functions": [{"function": "minecraft:set_count", "count": {"min": 3, "max": 6}}]}
        ]
    }]
}, os.path.join(LT_ENTITY, "soulfire_wraith.json"))

# =============================================================================
# 5. WORLDGEN DATA (Dimension, Noise, Biomes, Features)
# =============================================================================

# Dimension Type
dump({
    "ultrawarm": False,
    "natural": False,
    "coordinate_scale": 1.0,
    "has_skylight": False,
    "has_ceiling": True,
    "ambient_light": 0.08,
    "fixed_time": 18000,
    "monster_spawn_light_level": 7,
    "monster_spawn_block_light_limit": 7,
    "piglin_safe": False,
    "bed_works": False,
    "respawn_anchor_works": True,
    "has_raids": False,
    "logical_height": 256,
    "min_y": 0,
    "height": 256,
    "infiniburn": "#minecraft:infiniburn_nether",
    "effects": "minecraft:the_nether"
}, os.path.join(DIMTYPE_DIR, "echoing_depths.json"))

# Noise Settings (Cavern world style)
dump({
    "sea_level": 32,
    "disable_mob_generation": False,
    "aquifers_enabled": False,
    "ore_veins_enabled": True,
    "legacy_random_source": False,
    "default_block": {"Name": "echoingdepths:echo_stone"},
    "default_fluid": {"Name": "minecraft:air"},
    "noise": {
        "min_y": 0,
        "height": 256,
        "size_horizontal": 1,
        "size_vertical": 2
    },
    "noise_router": {
        "barrier": 0,
        "fluid_level_floodedness": 0,
        "fluid_level_spread": 0,
        "lava": 0,
        "temperature": 0,
        "vegetation": 0,
        "continents": 0,
        "erosion": 0,
        "depth": 0,
        "ridges": 0,
        "initial_density_without_jaggedness": 0,
        "final_density": {
            "type": "minecraft:interpolated",
            "argument": {
                "type": "minecraft:add",
                "argument1": {
                    "type": "minecraft:y_clamped_gradient",
                    "from_y": 8,
                    "to_y": 240,
                    "from_value": 1.5,
                    "to_value": -1.5
                },
                "argument2": {
                    "type": "minecraft:noise",
                    "noise": "minecraft:cave_cheese",
                    "xz_scale": 1.0,
                    "y_scale": 1.0
                }
            }
        },
        "vein_toggle": 0,
        "vein_ridged": 0,
        "vein_gap": 0
    },
    "spawn_target": [],
    "surface_rule": {
        "type": "minecraft:sequence",
        "sequence": [
            {
                "type": "minecraft:condition",
                "if_true": {
                    "type": "minecraft:vertical_gradient",
                    "random_name": "minecraft:bedrock_floor",
                    "true_at_and_below": {"above_bottom": 0},
                    "false_at_and_above": {"above_bottom": 5}
                },
                "then_run": {"type": "minecraft:block", "result_state": {"Name": "minecraft:bedrock"}}
            },
            {
                "type": "minecraft:condition",
                "if_true": {
                    "type": "minecraft:vertical_gradient",
                    "random_name": "minecraft:bedrock_roof",
                    "true_at_and_below": {"below_top": 0},
                    "false_at_and_above": {"below_top": 5}
                },
                "then_run": {"type": "minecraft:block", "result_state": {"Name": "minecraft:bedrock"}}
            },
            {
                "type": "minecraft:condition",
                "if_true": {
                    "type": "minecraft:stone_depth",
                    "offset": 0,
                    "surface_type": "floor",
                    "add_surface_depth": False,
                    "secondary_depth_range": 0
                },
                "then_run": {"type": "minecraft:block", "result_state": {"Name": "echoingdepths:echo_moss_block"}}
            },
            {
                "type": "minecraft:condition",
                "if_true": {
                    "type": "minecraft:stone_depth",
                    "offset": 1,
                    "surface_type": "floor",
                    "add_surface_depth": False,
                    "secondary_depth_range": 0
                },
                "then_run": {"type": "minecraft:block", "result_state": {"Name": "echoingdepths:echo_soil"}}
            }
        ]
    }
}, os.path.join(NOISE_DIR, "echoing_depths.json"))

# Biomes definitions
biomes_data = {
    "echo_plains": {
        "sky_color": 0x050C1A,
        "fog_color": 0x081E36,
        "water_color": 0x1E548A,
        "water_fog_color": 0x0D2B4A,
        "foliage_color": 0x24C6C6,
        "grass_color": 0x24C6C6
    },
    "crystal_hollows": {
        "sky_color": 0x100524,
        "fog_color": 0x1D0F3B,
        "water_color": 0x582496,
        "water_fog_color": 0x2C0E52,
        "foliage_color": 0x9D4EDD,
        "grass_color": 0x9D4EDD
    },
    "soulfire_wastes": {
        "sky_color": 0x020B14,
        "fog_color": 0x092233,
        "water_color": 0x00A8E8,
        "water_fog_color": 0x003459,
        "foliage_color": 0x00A8E8,
        "grass_color": 0x00A8E8
    },
    "whispering_forest": {
        "sky_color": 0x040810,
        "fog_color": 0x0B1626,
        "water_color": 0x153A5B,
        "water_fog_color": 0x0B1F33,
        "foliage_color": 0x17A2B8,
        "grass_color": 0x17A2B8
    },
    "abyssal_depths": {
        "sky_color": 0x010308,
        "fog_color": 0x040A14,
        "water_color": 0x0D1B2A,
        "water_fog_color": 0x050D14,
        "foliage_color": 0x1D2D44,
        "grass_color": 0x1D2D44
    }
}

for bname, cols in biomes_data.items():
    dump({
        "has_precipitation": False,
        "temperature": 0.5,
        "downfall": 0.0,
        "effects": {
            "sky_color": cols["sky_color"],
            "fog_color": cols["fog_color"],
            "water_color": cols["water_color"],
            "water_fog_color": cols["water_fog_color"],
            "foliage_color": cols["foliage_color"],
            "grass_color": cols["grass_color"],
            "ambient_sound": "echoingdepths:block.echo_portal.ambient",
            "mood_sound": {
                "sound": "minecraft:ambient.soul_sand_valley.mood",
                "tick_delay": 6000,
                "block_search_extent": 8,
                "offset": 2.0
            }
        },
        "spawners": {
            "monster": [
                {"type": "echoingdepths:echo_stalker", "weight": 60, "minCount": 1, "maxCount": 3},
                {"type": "echoingdepths:sculk_crawler", "weight": 80, "minCount": 2, "maxCount": 4}
            ],
            "ambient": [
                {"type": "echoingdepths:soul_wisp", "weight": 50, "minCount": 1, "maxCount": 3}
            ]
        },
        "spawn_costs": {},
        "carvers": {},
        "features": []
    }, os.path.join(BIOME_DIR, f"{bname}.json"))

# Dimension (Multi-noise generator)
dump({
    "type": "echoingdepths:echoing_depths",
    "generator": {
        "type": "minecraft:noise",
        "settings": "echoingdepths:echoing_depths",
        "biome_source": {
            "type": "minecraft:multi_noise",
            "biomes": [
                {
                    "biome": "echoingdepths:echo_plains",
                    "parameters": {"temperature": 0.0, "humidity": 0.0, "continentalness": 0.0, "erosion": 0.0, "weirdness": 0.0, "depth": 0.0, "offset": 0.0}
                },
                {
                    "biome": "echoingdepths:crystal_hollows",
                    "parameters": {"temperature": -0.5, "humidity": 0.5, "continentalness": 0.0, "erosion": 0.2, "weirdness": 0.3, "depth": 0.0, "offset": 0.0}
                },
                {
                    "biome": "echoingdepths:soulfire_wastes",
                    "parameters": {"temperature": 0.8, "humidity": -0.5, "continentalness": 0.0, "erosion": -0.3, "weirdness": 0.0, "depth": 0.0, "offset": 0.0}
                },
                {
                    "biome": "echoingdepths:whispering_forest",
                    "parameters": {"temperature": 0.2, "humidity": 0.7, "continentalness": 0.3, "erosion": 0.0, "weirdness": -0.4, "depth": 0.0, "offset": 0.0}
                },
                {
                    "biome": "echoingdepths:abyssal_depths",
                    "parameters": {"temperature": -0.8, "humidity": -0.8, "continentalness": -0.5, "erosion": 0.5, "weirdness": 0.5, "depth": 0.0, "offset": 0.0}
                }
            ]
        }
    }
}, os.path.join(DIM_DIR, "echoing_depths.json"))

# =============================================================================
# 6. MINECRAFT TAGS
# =============================================================================

# Mineable with Pickaxe
dump({
    "replace": False,
    "values": [
        "echoingdepths:echo_stone", "echoingdepths:cobbled_echo_stone", "echoingdepths:polished_echo_stone",
        "echoingdepths:echo_stone_bricks", "echoingdepths:cracked_echo_stone_bricks", "echoingdepths:chiseled_echo_stone_bricks",
        "echoingdepths:echo_tiles", "echoingdepths:echo_stone_stairs", "echoingdepths:echo_stone_slab",
        "echoingdepths:echo_stone_wall", "echoingdepths:echo_brick_stairs", "echoingdepths:echo_brick_slab",
        "echoingdepths:echo_brick_wall", "echoingdepths:echorite_ore", "echoingdepths:resonite_ore",
        "echoingdepths:soulfire_ore", "echoingdepths:raw_echorite_block", "echoingdepths:echorite_block",
        "echoingdepths:resonite_block", "echoingdepths:echo_crystal_block", "echoingdepths:echo_crystal_cluster",
        "echoingdepths:resonant_lamp", "echoingdepths:echo_lantern", "echoingdepths:resonant_altar"
    ]
}, os.path.join(MC_TAGS_BLOCK, "mineable_pickaxe.json"))

# Mineable with Axe
dump({
    "replace": False,
    "values": [
        "echoingdepths:gloomwood_log", "echoingdepths:stripped_gloomwood_log",
        "echoingdepths:gloomwood_wood", "echoingdepths:stripped_gloomwood_wood",
        "echoingdepths:gloomwood_planks", "echoingdepths:gloomwood_stairs",
        "echoingdepths:gloomwood_slab", "echoingdepths:gloomwood_fence",
        "echoingdepths:gloomwood_fence_gate", "echoingdepths:gloomwood_door",
        "echoingdepths:gloomwood_trapdoor", "echoingdepths:gloomwood_button",
        "echoingdepths:gloomwood_pressure_plate"
    ]
}, os.path.join(MC_TAGS_BLOCK, "mineable_axe.json"))

# Needs Iron / Diamond tool
dump({
    "replace": False,
    "values": [
        "echoingdepths:echorite_ore", "echoingdepths:raw_echorite_block", "echoingdepths:echorite_block"
    ]
}, os.path.join(MC_TAGS_BLOCK, "needs_iron_tool.json"))

dump({
    "replace": False,
    "values": [
        "echoingdepths:resonite_ore", "echoingdepths:resonite_block", "echoingdepths:resonant_altar"
    ]
}, os.path.join(MC_TAGS_BLOCK, "needs_diamond_tool.json"))

# =============================================================================
# 7. LANGUAGE FILES (en_us and pt_br)
# =============================================================================

en_us = {
    "creativetab.echoingdepths": "The Echoing Depths",

    # Items
    "item.echoingdepths.blue_fireball": "Blue Fireball",
    "item.echoingdepths.raw_echorite": "Raw Echorite",
    "item.echoingdepths.echorite_ingot": "Echorite Ingot",
    "item.echoingdepths.echorite_nugget": "Echorite Nugget",
    "item.echoingdepths.resonite_gem": "Resonite Gem",
    "item.echoingdepths.soulfire_dust": "Soulfire Dust",
    "item.echoingdepths.echo_crystal_shard": "Echo Crystal Shard",
    "item.echoingdepths.stalker_fang": "Stalker Fang",
    "item.echoingdepths.gloom_spore": "Gloom Spore",
    "item.echoingdepths.wisp_essence": "Wisp Essence",
    "item.echoingdepths.colossus_core": "Colossus Core",
    "item.echoingdepths.wraith_heart": "Wraith Heart",
    "item.echoingdepths.resonite_upgrade_smithing_template": "Smithing Template: Resonite Upgrade",
    "item.echoingdepths.resonant_sigil": "Resonant Sigil",
    "item.echoingdepths.soulfire_sigil": "Soulfire Sigil",
    "item.echoingdepths.echo_orb": "Echo Orb",
    "item.echoingdepths.glowcap_stew": "Glowcap Stew",

    # Weapons & Tools
    "item.echoingdepths.sonic_scepter": "Sonic Scepter",
    "item.echoingdepths.soulfire_staff": "Soulfire Staff",
    "item.echoingdepths.abyssal_greatsword": "Abyssal Greatsword",

    "item.echoingdepths.echorite_sword": "Echorite Sword",
    "item.echoingdepths.echorite_pickaxe": "Echorite Pickaxe",
    "item.echoingdepths.echorite_axe": "Echorite Axe",
    "item.echoingdepths.echorite_shovel": "Echorite Shovel",
    "item.echoingdepths.echorite_hoe": "Echorite Hoe",

    "item.echoingdepths.resonite_sword": "Resonite Sword",
    "item.echoingdepths.resonite_pickaxe": "Resonite Pickaxe",
    "item.echoingdepths.resonite_axe": "Resonite Axe",
    "item.echoingdepths.resonite_shovel": "Resonite Shovel",
    "item.echoingdepths.resonite_hoe": "Resonite Hoe",

    # Armor
    "item.echoingdepths.echorite_helmet": "Echorite Helmet",
    "item.echoingdepths.echorite_chestplate": "Echorite Chestplate",
    "item.echoingdepths.echorite_leggings": "Echorite Leggings",
    "item.echoingdepths.echorite_boots": "Echorite Boots",

    "item.echoingdepths.resonite_helmet": "Resonite Helmet",
    "item.echoingdepths.resonite_chestplate": "Resonite Chestplate",
    "item.echoingdepths.resonite_leggings": "Resonite Leggings",
    "item.echoingdepths.resonite_boots": "Resonite Boots",

    # Blocks
    "block.echoingdepths.echo_stone": "Echo Stone",
    "block.echoingdepths.cobbled_echo_stone": "Cobbled Echo Stone",
    "block.echoingdepths.polished_echo_stone": "Polished Echo Stone",
    "block.echoingdepths.echo_stone_bricks": "Echo Stone Bricks",
    "block.echoingdepths.cracked_echo_stone_bricks": "Cracked Echo Stone Bricks",
    "block.echoingdepths.chiseled_echo_stone_bricks": "Chiseled Echo Stone Bricks",
    "block.echoingdepths.echo_tiles": "Echo Tiles",

    "block.echoingdepths.echo_stone_stairs": "Echo Stone Stairs",
    "block.echoingdepths.echo_stone_slab": "Echo Stone Slab",
    "block.echoingdepths.echo_stone_wall": "Echo Stone Wall",
    "block.echoingdepths.echo_brick_stairs": "Echo Brick Stairs",
    "block.echoingdepths.echo_brick_slab": "Echo Brick Slab",
    "block.echoingdepths.echo_brick_wall": "Echo Brick Wall",

    "block.echoingdepths.echo_soil": "Echo Soil",
    "block.echoingdepths.echo_moss_block": "Echo Moss Block",
    "block.echoingdepths.echorite_ore": "Echorite Ore",
    "block.echoingdepths.resonite_ore": "Resonite Ore",
    "block.echoingdepths.soulfire_ore": "Soulfire Ore",
    "block.echoingdepths.raw_echorite_block": "Block of Raw Echorite",
    "block.echoingdepths.echorite_block": "Block of Echorite",
    "block.echoingdepths.resonite_block": "Block of Resonite",
    "block.echoingdepths.echo_crystal_block": "Block of Echo Crystal",
    "block.echoingdepths.echo_crystal_cluster": "Echo Crystal Cluster",

    "block.echoingdepths.gloomwood_log": "Gloomwood Log",
    "block.echoingdepths.stripped_gloomwood_log": "Stripped Gloomwood Log",
    "block.echoingdepths.gloomwood_wood": "Gloomwood Wood",
    "block.echoingdepths.stripped_gloomwood_wood": "Stripped Gloomwood Wood",
    "block.echoingdepths.gloomwood_planks": "Gloomwood Planks",
    "block.echoingdepths.gloomwood_stairs": "Gloomwood Stairs",
    "block.echoingdepths.gloomwood_slab": "Gloomwood Slab",
    "block.echoingdepths.gloomwood_fence": "Gloomwood Fence",
    "block.echoingdepths.gloomwood_fence_gate": "Gloomwood Fence Gate",
    "block.echoingdepths.gloomwood_door": "Gloomwood Door",
    "block.echoingdepths.gloomwood_trapdoor": "Gloomwood Trapdoor",
    "block.echoingdepths.gloomwood_button": "Gloomwood Button",
    "block.echoingdepths.gloomwood_pressure_plate": "Gloomwood Pressure Plate",
    "block.echoingdepths.gloomwood_leaves": "Gloomwood Leaves",
    "block.echoingdepths.gloomwood_sapling": "Gloomwood Sapling",

    "block.echoingdepths.echo_grass": "Echo Grass",
    "block.echoingdepths.glowcap": "Glowcap",
    "block.echoingdepths.resonant_lamp": "Resonant Lamp",
    "block.echoingdepths.echo_glass": "Echo Glass",
    "block.echoingdepths.echo_lantern": "Echo Lantern",
    "block.echoingdepths.resonant_altar": "Resonant Altar",
    "block.echoingdepths.echo_portal": "Echo Portal",

    # Entities
    "entity.echoingdepths.echo_stalker": "Echo Stalker",
    "entity.echoingdepths.sculk_crawler": "Sculk Crawler",
    "entity.echoingdepths.soul_wisp": "Soul Wisp",
    "entity.echoingdepths.echo_colossus": "Echo Colossus",
    "entity.echoingdepths.soulfire_wraith": "Soulfire Wraith",
    "entity.echoingdepths.blue_fireball": "Blue Fireball",
    "entity.echoingdepths.resonant_pulse": "Resonant Pulse",

    # Spawn Eggs
    "item.echoingdepths.echo_stalker_spawn_egg": "Echo Stalker Spawn Egg",
    "item.echoingdepths.sculk_crawler_spawn_egg": "Sculk Crawler Spawn Egg",
    "item.echoingdepths.soul_wisp_spawn_egg": "Soul Wisp Spawn Egg",
    "item.echoingdepths.echo_colossus_spawn_egg": "Echo Colossus Spawn Egg",
    "item.echoingdepths.soulfire_wraith_spawn_egg": "Soulfire Wraith Spawn Egg",

    # Effects & Potions
    "effect.echoingdepths.echo_sight": "Echo Sight",
    "effect.echoingdepths.resonance": "Resonance",
    "effect.echoingdepths.soul_burn": "Soul Burn",
    "effect.echoingdepths.sculk_ward": "Sculk Ward",

    "item.minecraft.potion.effect.echo_sight": "Potion of Echo Sight",
    "item.minecraft.potion.effect.long_echo_sight": "Potion of Echo Sight (Extended)",
    "item.minecraft.potion.effect.resonance": "Potion of Resonance",
    "item.minecraft.potion.effect.soul_burn": "Potion of Soul Burn",
    "item.minecraft.potion.effect.sculk_ward": "Potion of Sculk Ward",

    # Enchantments
    "enchantment.echoingdepths.sonic_strike": "Sonic Strike",
    "enchantment.echoingdepths.soul_siphon": "Soul Siphon",
    "enchantment.echoingdepths.deep_sight": "Deep Sight",

    # Messages
    "message.echoingdepths.colossus_summoned": "The ground trembles... The Echo Colossus has awakened!",
    "message.echoingdepths.wraith_summoned": "A chilling screech pierces the air... The Soulfire Wraith descends!",

    # Subtitles
    "subtitles.echoingdepths.portal_ambient": "Echo Portal hums",
    "subtitles.echoingdepths.portal_travel": "Rushing through Echo Portal",
    "subtitles.echoingdepths.portal_ignite": "Echo Portal ignites",
    "subtitles.echoingdepths.sonic_pulse": "Sonic pulse fired",
    "subtitles.echoingdepths.soul_fireball": "Soul fireball roars",
    "subtitles.echoingdepths.colossus_roar": "Echo Colossus roars",
    "subtitles.echoingdepths.colossus_slam": "Echo Colossus slams ground",
    "subtitles.echoingdepths.wraith_scream": "Soulfire Wraith screeches"
}

pt_br = {
    "creativetab.echoingdepths": "The Echoing Depths",

    # Itens
    "item.echoingdepths.blue_fireball": "Bola de Fogo Azul",
    "item.echoingdepths.raw_echorite": "Ecorita Bruta",
    "item.echoingdepths.echorite_ingot": "Barra de Ecorita",
    "item.echoingdepths.echorite_nugget": "Pepita de Ecorita",
    "item.echoingdepths.resonite_gem": "Gema de Ressonita",
    "item.echoingdepths.soulfire_dust": "Pó de Fogo das Almas",
    "item.echoingdepths.echo_crystal_shard": "Fragmento de Cristal de Eco",
    "item.echoingdepths.stalker_fang": "Presa de Espreitador",
    "item.echoingdepths.gloom_spore": "Esporo da Penumbra",
    "item.echoingdepths.wisp_essence": "Essência de Fogo-Fátuo",
    "item.echoingdepths.colossus_core": "Núcleo de Colosso",
    "item.echoingdepths.wraith_heart": "Coração de Espectro",
    "item.echoingdepths.resonite_upgrade_smithing_template": "Molde de Ferraria: Aprimoramento de Ressonita",
    "item.echoingdepths.resonant_sigil": "Sigilo Ressonante",
    "item.echoingdepths.soulfire_sigil": "Sigilo de Fogo das Almas",
    "item.echoingdepths.echo_orb": "Orbe de Eco",
    "item.echoingdepths.glowcap_stew": "Ensopado de Cogumelo Brilhante",

    # Armas & Ferramentas
    "item.echoingdepths.sonic_scepter": "Cetro Sônico",
    "item.echoingdepths.soulfire_staff": "Cajado de Fogo das Almas",
    "item.echoingdepths.abyssal_greatsword": "Espadão Abissal",

    "item.echoingdepths.echorite_sword": "Espada de Ecorita",
    "item.echoingdepths.echorite_pickaxe": "Picareta de Ecorita",
    "item.echoingdepths.echorite_axe": "Machado de Ecorita",
    "item.echoingdepths.echorite_shovel": "Pá de Ecorita",
    "item.echoingdepths.echorite_hoe": "Enxada de Ecorita",

    "item.echoingdepths.resonite_sword": "Espada de Ressonita",
    "item.echoingdepths.resonite_pickaxe": "Picareta de Ressonita",
    "item.echoingdepths.resonite_axe": "Machado de Ressonita",
    "item.echoingdepths.resonite_shovel": "Pá de Ressonita",
    "item.echoingdepths.resonite_hoe": "Enxada de Ressonita",

    # Armaduras
    "item.echoingdepths.echorite_helmet": "Capacete de Ecorita",
    "item.echoingdepths.echorite_chestplate": "Peitoral de Ecorita",
    "item.echoingdepths.echorite_leggings": "Calças de Ecorita",
    "item.echoingdepths.echorite_boots": "Botas de Ecorita",

    "item.echoingdepths.resonite_helmet": "Capacete de Ressonita",
    "item.echoingdepths.resonite_chestplate": "Peitoral de Ressonita",
    "item.echoingdepths.resonite_leggings": "Calças de Ressonita",
    "item.echoingdepths.resonite_boots": "Botas de Ressonita",

    # Blocos
    "block.echoingdepths.echo_stone": "Pedra de Eco",
    "block.echoingdepths.cobbled_echo_stone": "Pedregulho de Eco",
    "block.echoingdepths.polished_echo_stone": "Pedra de Eco Polida",
    "block.echoingdepths.echo_stone_bricks": "Tijolos de Pedra de Eco",
    "block.echoingdepths.cracked_echo_stone_bricks": "Tijolos de Pedra de Eco Rachados",
    "block.echoingdepths.chiseled_echo_stone_bricks": "Tijolos de Pedra de Eco Talhados",
    "block.echoingdepths.echo_tiles": "Ladrilhos de Eco",

    "block.echoingdepths.echo_stone_stairs": "Escadas de Pedra de Eco",
    "block.echoingdepths.echo_stone_slab": "Degrau de Pedra de Eco",
    "block.echoingdepths.echo_stone_wall": "Muro de Pedra de Eco",
    "block.echoingdepths.echo_brick_stairs": "Escadas de Tijolos de Pedra de Eco",
    "block.echoingdepths.echo_brick_slab": "Degrau de Tijolos de Pedra de Eco",
    "block.echoingdepths.echo_brick_wall": "Muro de Tijolos de Pedra de Eco",

    "block.echoingdepths.echo_soil": "Terra de Eco",
    "block.echoingdepths.echo_moss_block": "Bloco de Musgo de Eco",
    "block.echoingdepths.echorite_ore": "Minério de Ecorita",
    "block.echoingdepths.resonite_ore": "Minério de Ressonita",
    "block.echoingdepths.soulfire_ore": "Minério de Fogo das Almas",
    "block.echoingdepths.raw_echorite_block": "Bloco de Ecorita Bruta",
    "block.echoingdepths.echorite_block": "Bloco de Ecorita",
    "block.echoingdepths.resonite_block": "Bloco de Ressonita",
    "block.echoingdepths.echo_crystal_block": "Bloco de Cristal de Eco",
    "block.echoingdepths.echo_crystal_cluster": "Aglomerado de Cristais de Eco",

    "block.echoingdepths.gloomwood_log": "Tronco de Madeira Sombria",
    "block.echoingdepths.stripped_gloomwood_log": "Tronco de Madeira Sombria Descascado",
    "block.echoingdepths.gloomwood_wood": "Madeira Sombria",
    "block.echoingdepths.stripped_gloomwood_wood": "Madeira Sombria Descascada",
    "block.echoingdepths.gloomwood_planks": "Tábuas de Madeira Sombria",
    "block.echoingdepths.gloomwood_stairs": "Escadas de Madeira Sombria",
    "block.echoingdepths.gloomwood_slab": "Degrau de Madeira Sombria",
    "block.echoingdepths.gloomwood_fence": "Cerca de Madeira Sombria",
    "block.echoingdepths.gloomwood_fence_gate": "Portão de Madeira Sombria",
    "block.echoingdepths.gloomwood_door": "Porta de Madeira Sombria",
    "block.echoingdepths.gloomwood_trapdoor": "Alçapão de Madeira Sombria",
    "block.echoingdepths.gloomwood_button": "Botão de Madeira Sombria",
    "block.echoingdepths.gloomwood_pressure_plate": "Placa de Pressão de Madeira Sombria",
    "block.echoingdepths.gloomwood_leaves": "Folhas de Madeira Sombria",
    "block.echoingdepths.gloomwood_sapling": "Muda de Madeira Sombria",

    "block.echoingdepths.echo_grass": "Grama de Eco",
    "block.echoingdepths.glowcap": "Cogumelo Brilhante",
    "block.echoingdepths.resonant_lamp": "Lâmpada Ressonante",
    "block.echoingdepths.echo_glass": "Vidro de Eco",
    "block.echoingdepths.echo_lantern": "Lampião de Eco",
    "block.echoingdepths.resonant_altar": "Altar Ressonante",
    "block.echoingdepths.echo_portal": "Portal de Eco",

    # Entidades
    "entity.echoingdepths.echo_stalker": "Espreitador de Eco",
    "entity.echoingdepths.sculk_crawler": "Rastejador de Sculk",
    "entity.echoingdepths.soul_wisp": "Fogo-Fátuo",
    "entity.echoingdepths.echo_colossus": "Colosso de Eco",
    "entity.echoingdepths.soulfire_wraith": "Espectro de Fogo das Almas",
    "entity.echoingdepths.blue_fireball": "Bola de Fogo Azul",
    "entity.echoingdepths.resonant_pulse": "Pulso Ressonante",

    # Ovos Geradores
    "item.echoingdepths.echo_stalker_spawn_egg": "Ovo Gerador de Espreitador de Eco",
    "item.echoingdepths.sculk_crawler_spawn_egg": "Ovo Gerador de Rastejador de Sculk",
    "item.echoingdepths.soul_wisp_spawn_egg": "Ovo Gerador de Fogo-Fátuo",
    "item.echoingdepths.echo_colossus_spawn_egg": "Ovo Gerador de Colosso de Eco",
    "item.echoingdepths.soulfire_wraith_spawn_egg": "Ovo Gerador de Espectro de Fogo das Almas",

    # Efeitos & Poções
    "effect.echoingdepths.echo_sight": "Visão de Eco",
    "effect.echoingdepths.resonance": "Ressonância",
    "effect.echoingdepths.soul_burn": "Queimação de Almas",
    "effect.echoingdepths.sculk_ward": "Proteção de Sculk",

    "item.minecraft.potion.effect.echo_sight": "Poção de Visão de Eco",
    "item.minecraft.potion.effect.long_echo_sight": "Poção de Visão de Eco Prolongada",
    "item.minecraft.potion.effect.resonance": "Poção de Ressonância",
    "item.minecraft.potion.effect.soul_burn": "Poção de Queimação de Almas",
    "item.minecraft.potion.effect.sculk_ward": "Poção de Proteção de Sculk",

    # Encantamentos
    "enchantment.echoingdepths.sonic_strike": "Golpe Sônico",
    "enchantment.echoingdepths.soul_siphon": "Sifão de Almas",
    "enchantment.echoingdepths.deep_sight": "Visão Profunda",

    # Mensagens
    "message.echoingdepths.colossus_summoned": "O chão estremece... O Colosso de Eco despertou!",
    "message.echoingdepths.wraith_summoned": "Um guincho gélido corta o ar... O Espectro de Fogo das Almas descende!",

    # Legendas
    "subtitles.echoingdepths.portal_ambient": "Portal de Eco sussurra",
    "subtitles.echoingdepths.portal_travel": "Atravessando o Portal de Eco",
    "subtitles.echoingdepths.portal_ignite": "Portal de Eco se acende",
    "subtitles.echoingdepths.sonic_pulse": "Pulso sônico disparado",
    "subtitles.echoingdepths.soul_fireball": "Bola de fogo das almas ruge",
    "subtitles.echoingdepths.colossus_roar": "Colosso de Eco ruge",
    "subtitles.echoingdepths.colossus_slam": "Colosso de Eco golpeia o solo",
    "subtitles.echoingdepths.wraith_scream": "Espectro de Fogo das Almas grita"
}

dump(en_us, os.path.join(LANG_DIR, "en_us.json"))
dump(pt_br, os.path.join(LANG_DIR, "pt_br.json"))

print("All assets, data, models, recipes, loot tables, worldgen, and languages generated successfully!")
