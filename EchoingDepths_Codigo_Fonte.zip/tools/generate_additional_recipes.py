import os
import json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REC_DIR = os.path.join(ROOT, "src", "main", "resources", "data", "echoingdepths", "recipes")
os.makedirs(REC_DIR, exist_ok=True)

def dump(data, name):
    path = os.path.join(REC_DIR, f"{name}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"Generated recipe: {name}")

# 1. Smelting cobbled echo stone to echo stone
dump({
    "type": "minecraft:smelting",
    "ingredient": {"item": "echoingdepths:cobbled_echo_stone"},
    "result": "echoingdepths:echo_stone",
    "experience": 0.1,
    "cookingtime": 200
}, "echo_stone_smelting")

# 2. Polished echo stone
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##"],
    "key": {"#": {"item": "echoingdepths:echo_stone"}},
    "result": {"item": "echoingdepths:polished_echo_stone", "count": 4}
}, "polished_echo_stone")

# 3. Echo stone stairs, slab, wall
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#  ", "## ", "###"],
    "key": {"#": {"item": "echoingdepths:echo_stone"}},
    "result": {"item": "echoingdepths:echo_stone_stairs", "count": 4}
}, "echo_stone_stairs")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###"],
    "key": {"#": {"item": "echoingdepths:echo_stone"}},
    "result": {"item": "echoingdepths:echo_stone_slab", "count": 6}
}, "echo_stone_slab")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###"],
    "key": {"#": {"item": "echoingdepths:echo_stone"}},
    "result": {"item": "echoingdepths:echo_stone_wall", "count": 6}
}, "echo_stone_wall")

# 4. Echo brick stairs, slab, wall
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#  ", "## ", "###"],
    "key": {"#": {"item": "echoingdepths:echo_stone_bricks"}},
    "result": {"item": "echoingdepths:echo_brick_stairs", "count": 4}
}, "echo_brick_stairs")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###"],
    "key": {"#": {"item": "echoingdepths:echo_stone_bricks"}},
    "result": {"item": "echoingdepths:echo_brick_slab", "count": 6}
}, "echo_brick_slab")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###"],
    "key": {"#": {"item": "echoingdepths:echo_stone_bricks"}},
    "result": {"item": "echoingdepths:echo_brick_wall", "count": 6}
}, "echo_brick_wall")

# 5. Cracked echo stone bricks
dump({
    "type": "minecraft:smelting",
    "ingredient": {"item": "echoingdepths:echo_stone_bricks"},
    "result": "echoingdepths:cracked_echo_stone_bricks",
    "experience": 0.1,
    "cookingtime": 200
}, "cracked_echo_stone_bricks")

# 6. Chiseled echo stone bricks
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#", "#"],
    "key": {"#": {"item": "echoingdepths:echo_brick_slab"}},
    "result": {"item": "echoingdepths:chiseled_echo_stone_bricks", "count": 1}
}, "chiseled_echo_stone_bricks")

# 7. Echo tiles
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##"],
    "key": {"#": {"item": "echoingdepths:echo_stone_bricks"}},
    "result": {"item": "echoingdepths:echo_tiles", "count": 4}
}, "echo_tiles")

# 8. Gloomwood Wood & Stripped Wood
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##"],
    "key": {"#": {"item": "echoingdepths:gloomwood_log"}},
    "result": {"item": "echoingdepths:gloomwood_wood", "count": 3}
}, "gloomwood_wood")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##"],
    "key": {"#": {"item": "echoingdepths:stripped_gloomwood_log"}},
    "result": {"item": "echoingdepths:stripped_gloomwood_wood", "count": 3}
}, "stripped_gloomwood_wood")

# 9. Gloomwood variants
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#  ", "## ", "###"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}},
    "result": {"item": "echoingdepths:gloomwood_stairs", "count": 4}
}, "gloomwood_stairs")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}},
    "result": {"item": "echoingdepths:gloomwood_slab", "count": 6}
}, "gloomwood_slab")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#S#", "#S#"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}, "S": {"item": "minecraft:stick"}},
    "result": {"item": "echoingdepths:gloomwood_fence", "count": 3}
}, "gloomwood_fence")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["S#S", "S#S"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}, "S": {"item": "minecraft:stick"}},
    "result": {"item": "echoingdepths:gloomwood_fence_gate", "count": 1}
}, "gloomwood_fence_gate")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##", "##", "##"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}},
    "result": {"item": "echoingdepths:gloomwood_door", "count": 3}
}, "gloomwood_door")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "###"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}},
    "result": {"item": "echoingdepths:gloomwood_trapdoor", "count": 2}
}, "gloomwood_trapdoor")

dump({
    "type": "minecraft:crafting_shapeless",
    "ingredients": [{"item": "echoingdepths:gloomwood_planks"}],
    "result": {"item": "echoingdepths:gloomwood_button", "count": 1}
}, "gloomwood_button")

dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["##"],
    "key": {"#": {"item": "echoingdepths:gloomwood_planks"}},
    "result": {"item": "echoingdepths:gloomwood_pressure_plate", "count": 1}
}, "gloomwood_pressure_plate")

# 10. Echo Lantern
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["###", "#C#", "###"],
    "key": {"#": {"item": "minecraft:iron_nugget"}, "C": {"item": "echoingdepths:echo_crystal_shard"}},
    "result": {"item": "echoingdepths:echo_lantern", "count": 1}
}, "echo_lantern")

# 11. Resonant Lamp
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": [" R ", "RGR", " R "],
    "key": {"R": {"item": "minecraft:redstone"}, "G": {"item": "echoingdepths:resonite_gem"}},
    "result": {"item": "echoingdepths:resonant_lamp", "count": 1}
}, "resonant_lamp")

# 12. Resonant Altar
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["RRR", " C ", "BBB"],
    "key": {
        "R": {"item": "echoingdepths:resonite_block"},
        "C": {"item": "echoingdepths:echo_crystal_block"},
        "B": {"item": "echoingdepths:echo_stone_bricks"}
    },
    "result": {"item": "echoingdepths:resonant_altar", "count": 1}
}, "resonant_altar")

# 13. Resonite Upgrade Template Duplication
dump({
    "type": "minecraft:crafting_shaped",
    "pattern": ["#T#", "#C#", "###"],
    "key": {
        "#": {"item": "minecraft:diamond"},
        "T": {"item": "echoingdepths:resonite_upgrade_smithing_template"},
        "C": {"item": "echoingdepths:echo_stone"}
    },
    "result": {"item": "echoingdepths:resonite_upgrade_smithing_template", "count": 2}
}, "resonite_upgrade_smithing_template_duplication")

print("All additional recipes generated!")
