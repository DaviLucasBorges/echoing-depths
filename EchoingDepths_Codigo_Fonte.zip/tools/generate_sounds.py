"""
Generates valid Vorbis .ogg sound files for The Echoing Depths using soundfile & numpy.
"""
import os
import math
import numpy as np
import soundfile as sf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOUNDS = os.path.join(ROOT, "src", "main", "resources", "assets", "echoingdepths", "sounds")
os.makedirs(SOUNDS, exist_ok=True)

SR = 44100

def envelope(t, attack, decay, sustain, release, duration):
    """ADSR envelope generator"""
    env = np.zeros_like(t)
    t_rel = duration - release
    for i, time in enumerate(t):
        if time < attack:
            env[i] = time / max(1e-4, attack)
        elif time < attack + decay:
            frac = (time - attack) / max(1e-4, decay)
            env[i] = 1.0 - (1.0 - sustain) * frac
        elif time < t_rel:
            env[i] = sustain
        elif time <= duration:
            frac = (time - t_rel) / max(1e-4, release)
            env[i] = sustain * (1.0 - frac)
    return np.clip(env, 0, 1)

def save_ogg(name, audio):
    audio = np.clip(audio, -1.0, 1.0).astype(np.float32)
    path = os.path.join(SOUNDS, f"{name}.ogg")
    sf.write(path, audio, SR, format="OGG", subtype="VORBIS")
    print(f"Generated {name}.ogg ({len(audio)/SR:.2f}s)")

# 1. Portal Ambient (3.5s looping eerie drone)
dur = 3.5
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
base = (
    0.35 * np.sin(2 * np.pi * 55.0 * t) +
    0.25 * np.sin(2 * np.pi * 110.0 * t + np.sin(2 * np.pi * 0.5 * t)) +
    0.15 * np.sin(2 * np.pi * 165.0 * t) +
    0.10 * np.sin(2 * np.pi * 220.0 * t + np.cos(2 * np.pi * 0.8 * t))
)
# Add subtle crystalline shimmer
shimmer = 0.08 * np.sin(2 * np.pi * 880.0 * t + 3 * np.sin(2 * np.pi * 2.0 * t)) * np.sin(2 * np.pi * 0.4 * t)
noise = 0.04 * np.random.normal(0, 1, len(t))
env = np.sin(np.pi * t / dur) ** 0.5
save_ogg("portal_ambient", (base + shimmer + noise) * env)

# 2. Portal Travel (2.5s whoosh & dimensional vacuum)
dur = 2.5
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
pitch_sweep = np.linspace(60, 420, len(t))
sweep = np.sin(2 * np.pi * np.cumsum(pitch_sweep) / SR)
noise = np.random.normal(0, 0.4, len(t)) * (np.sin(np.pi * t / dur) ** 2)
env = envelope(t, 0.4, 0.8, 0.5, 0.6, dur)
save_ogg("portal_travel", (0.5 * sweep + 0.5 * noise) * env)

# 3. Portal Ignite (2.0s soul flare & thunderous resonant chime)
dur = 2.0
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
chime = (
    0.4 * np.sin(2 * np.pi * 329.63 * t) * np.exp(-3.0 * t) +
    0.3 * np.sin(2 * np.pi * 440.0 * t) * np.exp(-2.5 * t) +
    0.2 * np.sin(2 * np.pi * 659.25 * t) * np.exp(-4.0 * t) +
    0.3 * np.sin(2 * np.pi * 70.0 * t) * np.exp(-1.5 * t)
)
flare_noise = np.random.normal(0, 0.35, len(t)) * np.exp(-4.0 * t)
save_ogg("portal_ignite", (chime + flare_noise))

# 4. Sonic Pulse (0.8s sharp warden sonic boom style crack + bass)
dur = 0.8
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
crack = np.random.normal(0, 0.6, len(t)) * np.exp(-15.0 * t)
freq = np.linspace(480, 40, len(t))
bass = 0.7 * np.sin(2 * np.pi * np.cumsum(freq) / SR) * np.exp(-4.0 * t)
save_ogg("sonic_pulse", crack + bass)

# 5. Soul Fireball (1.2s ghostly fireball roar)
dur = 1.2
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
roar = (
    0.3 * np.sin(2 * np.pi * 140.0 * t + 5 * np.sin(2 * np.pi * 30.0 * t)) +
    0.4 * np.random.normal(0, 0.5, len(t))
) * envelope(t, 0.05, 0.3, 0.4, 0.5, dur)
save_ogg("soul_fireball", roar)

# 6. Colossus Roar (3.0s subterranean monolith roar)
dur = 3.0
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
freq = 55.0 + 20.0 * np.sin(2 * np.pi * 1.5 * t)
sub = 0.6 * np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(2 * np.pi * (freq * 1.5) * t)
growl = np.random.normal(0, 0.25, len(t)) * (np.sin(2 * np.pi * 15.0 * t) ** 2)
env = envelope(t, 0.5, 1.0, 0.7, 0.8, dur)
save_ogg("colossus_roar", (sub + growl) * env)

# 7. Colossus Slam (1.5s massive seismic impact)
dur = 1.5
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
impact = np.random.normal(0, 0.8, len(t)) * np.exp(-12.0 * t)
rumble = 0.7 * np.sin(2 * np.pi * 45.0 * t) * np.exp(-3.0 * t)
save_ogg("colossus_slam", impact + rumble)

# 8. Wraith Scream (1.8s piercing spectral screech)
dur = 1.8
t = np.linspace(0, dur, int(SR * dur), endpoint=False)
f1 = 600.0 + 250.0 * np.sin(2 * np.pi * 4.0 * t)
f2 = 900.0 + 350.0 * np.sin(2 * np.pi * 5.0 * t)
screech = 0.4 * np.sin(2 * np.pi * f1 * t) + 0.3 * np.sin(2 * np.pi * f2 * t)
breath = np.random.normal(0, 0.25, len(t))
env = envelope(t, 0.15, 0.5, 0.6, 0.5, dur)
save_ogg("wraith_scream", (screech + breath) * env)

print("All sounds generated successfully!")
