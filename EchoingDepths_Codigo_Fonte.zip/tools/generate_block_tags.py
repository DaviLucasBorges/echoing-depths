import os
import json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TAG_DIR = os.path.join(ROOT, "src", "main", "resources", "data", "minecraft", "tags", "blocks")
os.makedirs(TAG_DIR, exist_ok=True)

def dump(values, name):
    path = os.path.join(TAG_DIR, f"{name}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"replace": False, "values": values}, f, indent=2)
    print(f"Generated block tag: {name}")

dump([
    "echoingdepths:gloomwood_log",
    "echoingdepths:stripped_gloomwood_log",
    "echoingdepths:gloomwood_wood",
    "echoingdepths:stripped_gloomwood_wood"
], "logs")

dump(["echoingdepths:gloomwood_planks"], "planks")
dump(["echoingdepths:gloomwood_leaves"], "leaves")
dump(["echoingdepths:gloomwood_fence"], "fences")
dump(["echoingdepths:gloomwood_fence_gate"], "fence_gates")
dump(["echoingdepths:gloomwood_door"], "doors")
dump(["echoingdepths:gloomwood_trapdoor"], "trapdoors")
dump(["echoingdepths:gloomwood_button"], "buttons")
dump(["echoingdepths:gloomwood_pressure_plate"], "pressure_plates")

dump([
    "echoingdepths:echo_stone_stairs",
    "echoingdepths:echo_brick_stairs",
    "echoingdepths:gloomwood_stairs"
], "stairs")

dump([
    "echoingdepths:echo_stone_slab",
    "echoingdepths:echo_brick_slab",
    "echoingdepths:gloomwood_slab"
], "slabs")

dump([
    "echoingdepths:echo_stone_wall",
    "echoingdepths:echo_brick_wall"
], "walls")

print("Block tags created!")
